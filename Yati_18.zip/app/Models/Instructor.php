<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Instructor extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'specialty',
        'bio',
        'certificate_name', // Nuevo
        'signature_url',    // Nuevo
        'avatar_url',
        'status',
    ];

    public function courses()
    {
        return $this->hasMany(Course::class);
    }
}