<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'slug',
        'description',
        'short_description',
        'price',
        'discount_price',
        'cover_image',
        'instructor_id',
        'level',
        'status',
        'featured',
        'duration', // Carga horaria
        'evaluation_config',   
        'certificate_template', 
        'attendance_config',
        'learning_outcomes',
        'metadata',
        'benefits',
        'resources'
    ];

    protected $casts = [
        'evaluation_config' => 'array',
        'certificate_template' => 'array',
        'attendance_config' => 'array',
        'learning_outcomes' => 'array',
        'metadata' => 'array',
        'resources' => 'array',
        'price' => 'decimal:2',
        'discount_price' => 'decimal:2',
        'featured' => 'boolean'
    ];

    // Relación con Categorías
    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }

    public function instructor()
    {
        return $this->belongsTo(Instructor::class);
    }

    // Usaremos "topics" como si fueran los módulos
    public function topics()
    {
        return $this->hasMany(CourseTopic::class)->orderBy('order_index');
    }

    // ALIAS: Definimos "modules" para que apunte a "topics" y no falle la vista
    public function modules()
    {
        return $this->hasMany(CourseTopic::class)->orderBy('order_index');
    }

    // Relación directa con todas las lecciones del curso
    public function lessons()
    {
        return $this->hasMany(CourseLesson::class);
    }

    // Atributo calculado para contar lecciones totales
    public function getLessonsCountAttribute()
    {
        return $this->lessons()->count();
    }

    // --- RELACIONES FALTANTES AGREGADAS ---

    // 1. Relación con Inscripciones (Enrollments)
    public function enrollments()
    {
        return $this->hasMany(Enrollment::class);
    }

    // 2. Relación con Entregas de Proyecto (Para que funcione el contador de pendientes)
    public function projectSubmissions()
    {
        return $this->hasMany(ProjectSubmission::class);
    }
}