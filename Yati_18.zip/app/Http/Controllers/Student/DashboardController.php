<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\LessonProgress;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $student = Auth::guard('student')->user();
        
        // 1. Cargar inscripciones con relaciones necesarias
        // AGREGADO: 'course.categories' para poder mostrar las etiquetas en la vista
        $enrollments = $student->enrollments()
            ->with(['course.instructor', 'course.lessons', 'course.categories']) 
            ->orderBy('created_at', 'desc')
            ->get();

        // 2. Obtener TODOS los IDs de lecciones completadas
        $completedLessonIds = LessonProgress::where('student_id', $student->id)
            ->where('completed', true)
            ->pluck('lesson_id')
            ->toArray();

        // 3. Calcular métricas
        $inProgressCount = 0;
        $completedCount = 0;

        foreach ($enrollments as $enrollment) {
            $totalLessons = $enrollment->course->lessons->count();
            
            $completedInCourse = $enrollment->course->lessons->whereIn('id', $completedLessonIds)->count();
            
            $percent = $totalLessons > 0 ? round(($completedInCourse / $totalLessons) * 100) : 0;
            
            $enrollment->calculated_progress = $percent;
            $enrollment->completed_lessons_count = $completedInCourse;
            $enrollment->total_lessons_count = $totalLessons;

            if ($percent >= 100) {
                $completedCount++;
            } else {
                $inProgressCount++;
            }
        }

        return view('student.dashboard', compact(
            'student', 
            'enrollments', 
            'inProgressCount', 
            'completedCount'
        ));
    }
}