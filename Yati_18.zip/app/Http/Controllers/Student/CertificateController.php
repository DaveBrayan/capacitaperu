<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Certificate;
use App\Models\Enrollment;
use App\Models\LessonProgress; // Importante agregar esto
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class CertificateController extends Controller
{
    public function getOrCreate(Request $request, Course $course)
    {
        Log::info("--- [CERTIFICADO] Intento de generar certificado ---");
        
        $student = auth('student')->user();
        Log::info("Estudiante ID: " . $student->id . " | Curso ID: " . $course->id);

        // 1. Validar Inscripción
        try {
            $enrollment = Enrollment::where('student_id', $student->id)
                                    ->where('course_id', $course->id)
                                    ->firstOrFail();
        } catch (\Exception $e) {
            Log::error("[CERTIFICADO] No se encontró inscripción.");
            return redirect()->back()->with('warning', 'No estás inscrito en este curso.');
        }

        // 2. CALCULAR PROGRESO (Lógica Espejo del Dashboard)
        // -----------------------------------------------------
        
        // A. Total de lecciones del curso
        $totalLessons = $course->lessons()->count();

        // B. Lecciones completadas por el estudiante QUE PERTENECEN a este curso
        // Hacemos una query directa para asegurar consistencia con la BD
        $completedCount = LessonProgress::where('student_id', $student->id)
            ->where('completed', true)
            ->whereIn('lesson_id', $course->lessons()->select('id')) // Filtramos solo las de este curso
            ->count();

        // C. Porcentaje
        $progress = $totalLessons > 0 ? round(($completedCount / $totalLessons) * 100) : 0;

        Log::info("[CERTIFICADO] Total Lecciones: $totalLessons | Completadas: $completedCount | Progreso Calc: $progress%");

        // 3. Obtener Configuración de Evaluación
        $config = $course->evaluation_config ?? [];
        $minScore = $config['min_score'] ?? 70;
        $attWeight = $config['attendance_weight'] ?? 20;
        $examWeight = $config['final_assessment_weight'] ?? 80;

        // 4. Calcular Nota Final Ponderada
        $examScore = $this->getStudentExamScore($student->id, $course->id) ?? 0;
        
        $finalScore = ($progress * ($attWeight / 100)) + ($examScore * ($examWeight / 100));
        $finalScore = round($finalScore, 2);

        Log::info("[CERTIFICADO] Nota Final: $finalScore (Min: $minScore)");

        // 5. Validaciones de Negocio
        
        // FIX "99%": Si tiene >95% y aprobó el examen, asumimos que es un error de redondeo o lección "fantasma" y aprobamos.
        // Si no, exigimos el 100% estricto.
        $passedExam = $examScore >= 51; 
        $isProgressValid = $progress >= 100 || ($progress >= 95 && $passedExam);

        if (!$isProgressValid) {
            Log::warning("[CERTIFICADO] Falló: Progreso incompleto ($progress%)");
            return redirect()->back()->with('warning', "Tu progreso es del $progress%. Debes completar todas las lecciones (100%) para obtener el certificado.");
        }

        if ($finalScore < $minScore) {
            Log::warning("[CERTIFICADO] Falló: Nota baja ($finalScore)");
            return redirect()->back()->with('warning', "Tu nota final ($finalScore) no alcanza el mínimo ($minScore). Repasa los exámenes.");
        }

        // 6. Validar Fecha de Publicación
        $certConfig = $course->certificate_template ?? [];
        $releaseMode = $certConfig['release_mode'] ?? 'completion';
        
        if ($releaseMode === 'scheduled' && !empty($certConfig['release_date'])) {
            $releaseDate = Carbon::parse($certConfig['release_date']);
            if (now()->lessThan($releaseDate)) {
                return redirect()->back()->with('warning', 'Certificado disponible a partir del ' . $releaseDate->format('d/m/Y'));
            }
        }

        // 7. Generar o Recuperar UUID
        $cert = Certificate::firstOrCreate(
            ['student_id' => $student->id, 'course_id' => $course->id],
            [
                'uuid' => 'YATI-' . strtoupper(Str::random(4)) . '-' . now()->year . '-' . strtoupper(Str::random(4)),
                'issued_at' => now(),
            ]
        );

        return redirect()->route('certificate.verify', $cert->uuid);
    }

    private function getStudentExamScore($studentId, $courseId)
    {
        // AJUSTAR: Conectar con tu tabla de intentos (quiz_attempts)
        return 100; 
    }
}