<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Course;
use App\Models\Enrollment;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AdminDashboardController extends Controller
{
    public function index(Request $request)
    {
        // Filtro por defecto: month
        $filter = $request->input('filter', 'month');
        $now = Carbon::now();
        
        // Configurar rangos de fecha
        if ($filter === 'today') {
            $startDate = $now->copy()->startOfDay();
            $endDate = $now->copy()->endOfDay();
            $prevStartDate = $now->copy()->subDay()->startOfDay();
            $prevEndDate = $now->copy()->subDay()->endOfDay();
            $periodLabel = 'Hoy';
            $chartInterval = 'PT1H'; // Por horas
            $chartFormat = 'H:00';
            $dbFormat = 'H';
        } elseif ($filter === '7_days') {
            $startDate = $now->copy()->subDays(6)->startOfDay(); // Últimos 7 días incluyendo hoy
            $endDate = $now->copy()->endOfDay();
            $prevStartDate = $now->copy()->subDays(13)->startOfDay();
            $prevEndDate = $now->copy()->subDays(7)->endOfDay();
            $periodLabel = 'Últimos 7 días';
            $chartInterval = 'P1D'; // Por días
            $chartFormat = 'd M';
            $dbFormat = 'Y-m-d';
        } else { // month
            $startDate = $now->copy()->startOfMonth();
            $endDate = $now->copy()->endOfMonth();
            $prevStartDate = $now->copy()->subMonth()->startOfMonth();
            $prevEndDate = $now->copy()->subMonth()->endOfMonth();
            $periodLabel = 'Este Mes';
            $chartInterval = 'P1D'; // Por días
            $chartFormat = 'd';
            $dbFormat = 'Y-m-d';
        }

        // 1. ESTUDIANTES (Nuevos en el periodo)
        $totalStudents = Student::count(); // Histórico total para mostrar
        $newStudentsCurrent = Student::whereBetween('created_at', [$startDate, $endDate])->count();
        $newStudentsPrev = Student::whereBetween('created_at', [$prevStartDate, $prevEndDate])->count();
        
        $studentGrowth = 0;
        if ($newStudentsPrev > 0) {
            $studentGrowth = (($newStudentsCurrent - $newStudentsPrev) / $newStudentsPrev) * 100;
        } else {
            $studentGrowth = $newStudentsCurrent > 0 ? 100 : 0;
        }

        // 2. CURSOS ACTIVOS
        $activeCourses = Course::where('status', 'published')->count();
        $newCoursesPeriod = Course::where('status', 'published')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->count();

        // 3. INGRESOS (En el periodo)
        $currentRevenue = Enrollment::whereBetween('created_at', [$startDate, $endDate])->sum('price_paid');
        $prevRevenue = Enrollment::whereBetween('created_at', [$prevStartDate, $prevEndDate])->sum('price_paid');

        $revenueGrowth = 0;
        if ($prevRevenue > 0) {
            $revenueGrowth = (($currentRevenue - $prevRevenue) / $prevRevenue) * 100;
        } else {
            $revenueGrowth = $currentRevenue > 0 ? 100 : 0;
        }

        // 4. TASA DE FINALIZACIÓN (Histórico General)
        $totalEnrollments = Enrollment::count();
        $completedEnrollments = Enrollment::where('is_completed', true)->count();
        $completionRate = $totalEnrollments > 0 ? round(($completedEnrollments / $totalEnrollments) * 100) : 0;

        // 5. INSCRIPCIONES RECIENTES (Filtradas por el periodo, o últimas 5 si es muy corto)
        $recentQuery = Enrollment::with(['student', 'course'])
            ->orderBy('created_at', 'desc');
        
        // Si el filtro es "hoy" y hay pocas, mostramos las de hoy. Si no hay de hoy, muestra vacío o las últimas históricas según prefieras.
        // Aquí forzaremos a mostrar las últimas 5 generales para que la tabla no se vea vacía si no hubo ventas hoy.
        $recentEnrollments = $recentQuery->take(5)->get();

        // 6. DATOS PARA GRÁFICO
        $chartLabels = [];
        $chartData = [];

        // Obtener ventas brutas del periodo
        $rawSales = Enrollment::whereBetween('created_at', [$startDate, $endDate])
            ->select('created_at', 'price_paid')
            ->get();

        // Generar periodo de fechas/horas para llenar huecos en 0
        $period = new \DatePeriod($startDate, new \DateInterval($chartInterval), $endDate);

        foreach ($period as $dt) {
            $label = $dt->format($chartFormat);
            $chartLabels[] = $label;

            // Filtrar y sumar ventas para este punto específico (hora o día)
            if ($filter === 'today') {
                $sum = $rawSales->filter(function ($sale) use ($dt) {
                    return $sale->created_at->format('H') == $dt->format('H');
                })->sum('price_paid');
            } else {
                $sum = $rawSales->filter(function ($sale) use ($dt) {
                    return $sale->created_at->format('Y-m-d') == $dt->format('Y-m-d');
                })->sum('price_paid');
            }
            $chartData[] = $sum;
        }

        return view('admin.dashboard', compact(
            'filter',
            'periodLabel',
            'totalStudents', 
            'newStudentsCurrent', 
            'studentGrowth',
            'activeCourses',
            'newCoursesPeriod',
            'currentRevenue',
            'revenueGrowth',
            'completionRate',
            'recentEnrollments',
            'chartLabels',
            'chartData'
        ));
    }
}