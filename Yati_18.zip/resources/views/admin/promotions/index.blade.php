<x-layouts.admin>
    <x-slot name="title">Promociones - Gestión</x-slot>
    <x-slot name="header">Campañas y Promociones</x-slot>

    <!-- ESTILOS EXTRA -->
    <style>
        .select-multiple option { padding: 8px; border-bottom: 1px solid #f3f4f6; }
        .select-multiple option:checked { background-color: #0AD1C8; color: white; }
        .select-multiple option:hover { background-color: #f0fdfa; }
        /* Ocultar visualmente pero mantener en DOM */
        .logic-hidden { display: none; }
    </style>

    <!-- BARRA SUPERIOR -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <div class="relative w-full md:w-80">
            <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="text" placeholder="Buscar promoción..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
        </div>
        
        <!-- SOLO SI TIENE PERMISO DE CREAR -->
        @if(Auth::user()->hasPermission('promotions.create'))
        <button onclick="openPromoModal()" class="flex items-center gap-2 px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm font-bold">
            <i class="ph-bold ph-tag"></i> Nueva Promoción
        </button>
        @endif
    </div>

    <!-- TABLA -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.2s">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/50 text-[10px] font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4">Campaña</th>
                        <th class="px-6 py-4">Descuento</th>
                        <th class="px-6 py-4">Alcance</th>
                        <th class="px-6 py-4">Vigencia</th>
                        <th class="px-6 py-4 text-center">Estado</th>
                        <th class="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    @forelse($promotions as $promo)
                    <tr class="hover:bg-[#F0FDFD]/50 transition-colors group">
                        <td class="px-6 py-4"><p class="font-bold text-[#213A57]">{{ $promo->name }}</p></td>
                        <td class="px-6 py-4">
                            <span class="text-lg font-black text-[#0AD1C8]">
                                {{ $promo->discount_type == 'percent' ? '-' . intval($promo->value) . '%' : '- Bs ' . number_format($promo->value, 0) }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            @php
                                $tIds = $promo->target_ids;
                                if(is_string($tIds)) { $tIds = json_decode($tIds, true); }
                                $tIds = is_array($tIds) ? $tIds : [];

                                $eIds = $promo->exception_ids;
                                if(is_string($eIds)) { $eIds = json_decode($eIds, true); }
                                $eIds = is_array($eIds) ? $eIds : [];
                            @endphp

                            @if($promo->target_type == 'all')
                                <span class="text-xs font-bold text-purple-600 bg-purple-50 px-2 py-1 rounded-lg">Todo el Catálogo</span>
                            @elseif($promo->target_type == 'category')
                                <div class="flex flex-col gap-1">
                                    <div class="flex items-center gap-1 text-xs text-gray-600">
                                        <i class="ph-bold ph-squares-four"></i>
                                        {{ count($tIds) }} Categorías
                                    </div>
                                    @if(count($eIds) > 0)
                                        <span class="text-[10px] text-red-400 flex items-center gap-1">
                                            <i class="ph-bold ph-prohibit"></i> {{ count($eIds) }} Excluidos
                                        </span>
                                    @endif
                                </div>
                            @elseif($promo->target_type == 'course')
                                <div class="flex items-center gap-1 text-xs text-gray-600">
                                    <i class="ph-bold ph-graduation-cap"></i>
                                    {{ count($tIds) }} Cursos
                                </div>
                            @endif
                        </td>
                        <td class="px-6 py-4 min-w-[200px]">
                            <div class="flex justify-between text-[10px] text-gray-500 mb-1 capitalize">
                                <span>{{ $promo->start_date->locale('es')->translatedFormat('d M') }}</span>
                                <span>{{ $promo->end_date->locale('es')->translatedFormat('d M') }}</span>
                            </div>
                            <div class="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mt-1">
                                <div class="h-full bg-blue-400" style="width: 100%"></div>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase bg-gray-100 text-gray-500">{{ $promo->status_label }}</span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="flex items-center justify-end gap-1">
                                <!-- SOLO SI TIENE PERMISO DE EDITAR -->
                                @if(Auth::user()->hasPermission('promotions.edit'))
                                <button onclick='editPromo(@json($promo))' class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-amber-500 hover:bg-amber-50 transition-colors"><i class="ph-bold ph-pencil-simple text-lg"></i></button>
                                @endif
                                
                                <!-- SOLO SI TIENE PERMISO DE ELIMINAR -->
                                @if(Auth::user()->hasPermission('promotions.delete'))
                                <form action="{{ route('admin.promotions.destroy', $promo->id) }}" method="POST" onsubmit="return confirm('¿Eliminar?')">
                                    @csrf @method('DELETE')
                                    <button class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"><i class="ph-bold ph-trash text-lg"></i></button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="px-6 py-12 text-center text-gray-400">No hay promociones.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-4 border-t border-gray-100 bg-gray-50/50">{{ $promotions->links() }}</div>
    </div>

    <!-- MODAL (Mismo código de antes) -->
    <div id="promo-modal" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closePromoModal()"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <form id="promoForm" action="{{ route('admin.promotions.store') }}" method="POST" class="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]">
                @csrf
                <div id="method-field"></div> 

                <div class="bg-[#213A57] p-6 text-white flex justify-between items-center shrink-0">
                    <h3 class="text-xl font-bold" id="modal-title">Nueva Promoción</h3>
                    <button type="button" onclick="closePromoModal()" class="hover:opacity-70"><i class="ph-bold ph-x text-xl"></i></button>
                </div>

                <div class="p-8 overflow-y-auto space-y-6">
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Nombre Campaña</label>
                        <input type="text" name="name" id="name" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm font-bold text-[#213A57]" placeholder="Ej: Black Friday">
                    </div>

                    <div class="p-4 bg-gray-50 rounded-xl border border-gray-100">
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-3">Configuración del Descuento</label>
                        <div class="flex gap-4">
                            <div class="w-1/3">
                                <select name="discount_type" id="discount_type" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-white">
                                    <option value="percent">Porcentaje (%)</option>
                                    <option value="fixed">Monto Fijo (Bs)</option>
                                </select>
                            </div>
                            <div class="flex-1 relative">
                                <input type="number" name="value" id="value" required min="0" step="0.01" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm font-bold text-[#0AD1C8] pl-10">
                                <i class="ph-bold ph-tag absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            </div>
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Aplicar a:</label>
                        <select name="target_type" id="target_type" onchange="toggleTargets()" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-white mb-3">
                            <option value="all">Todo el Catálogo</option>
                            <option value="category">Categorías Específicas</option>
                            <option value="course">Cursos Específicos</option>
                        </select>

                        <div id="target-courses" class="hidden">
                            <label class="text-xs text-gray-500 mb-1 block">Selecciona los cursos:</label>
                            <div class="relative mb-2">
                                <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
                                <input type="text" id="search-courses" onkeyup="filterOptions('search-courses', 'courses-select')" placeholder="Buscar curso..." class="w-full pl-8 pr-3 py-2 rounded-lg border border-gray-200 text-xs focus:border-[#0AD1C8] outline-none">
                            </div>
                            <select id="courses-select" name="target_ids[]" multiple class="w-full px-2 py-2 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50 h-40 select-multiple custom-scrollbar">
                                @foreach($courses as $course)
                                    <option value="{{ $course->id }}" data-categories="{{ json_encode($course->categories->pluck('id')) }}">{{ $course->title }}</option>
                                @endforeach
                            </select>
                            <p class="text-[10px] text-gray-400 mt-1">Mantén presionada la tecla Ctrl (o Cmd) para seleccionar varios.</p>
                        </div>

                        <div id="target-categories" class="hidden space-y-4">
                            <div>
                                <label class="text-xs text-gray-500 mb-1 block">Selecciona las categorías:</label>
                                <div class="relative mb-2">
                                    <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs"></i>
                                    <input type="text" id="search-categories" onkeyup="filterOptions('search-categories', 'categories-select')" placeholder="Buscar categoría..." class="w-full pl-8 pr-3 py-2 rounded-lg border border-gray-200 text-xs focus:border-[#0AD1C8] outline-none">
                                </div>
                                <select id="categories-select" name="target_ids[]" multiple disabled onchange="updateExclusions()" class="w-full px-2 py-2 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50 h-40 select-multiple custom-scrollbar">
                                    @foreach($categories as $cat)
                                        <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div id="target-exclusions" class="hidden">
                                <label class="text-xs text-red-500 font-bold mb-1 flex items-center gap-1">
                                    <i class="ph-bold ph-prohibit"></i> Excluir Cursos Específicos:
                                </label>
                                <p class="text-[10px] text-gray-400 mb-2">Selecciona los cursos de estas categorías que <b>NO</b> tendrán descuento.</p>
                                <select id="exclusions-select" name="exception_ids[]" multiple class="w-full px-2 py-2 rounded-xl border border-red-100 focus:border-red-400 outline-none text-sm bg-red-50/30 h-32 select-multiple custom-scrollbar">
                                    @foreach($courses as $course)
                                        <option value="{{ $course->id }}" data-categories="{{ json_encode($course->categories->pluck('id')) }}" class="hidden logic-hidden">
                                            {{ $course->title }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Inicio</label>
                            <input type="datetime-local" name="start_date" id="start_date" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Fin</label>
                            <input type="datetime-local" name="end_date" id="end_date" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                        </div>
                    </div>
                </div>

                <div class="p-6 border-t border-gray-100 flex justify-end gap-3 shrink-0 bg-white">
                    <button type="button" onclick="closePromoModal()" class="px-6 py-2.5 text-gray-500 font-bold hover:bg-gray-50 rounded-xl transition-colors">Cancelar</button>
                    <button type="submit" class="px-8 py-2.5 bg-[#213A57] text-white font-bold rounded-xl shadow-lg hover:bg-[#0B6477] transition-colors">Guardar Promoción</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // FILTRO VISUAL DE BUSCADOR
        function filterOptions(inputId, selectId) {
            const input = document.getElementById(inputId);
            const filter = input.value.toLowerCase();
            const select = document.getElementById(selectId);
            const options = select.getElementsByTagName('option');
            for (let i = 0; i < options.length; i++) {
                const txtValue = options[i].textContent || options[i].innerText;
                if(!options[i].classList.contains('logic-hidden')) {
                    options[i].style.display = txtValue.toLowerCase().indexOf(filter) > -1 ? "" : "none";
                }
            }
        }

        // CONTROL DE VISTAS (CURSO/CATEGORIA)
        function toggleTargets() {
            const type = document.getElementById('target_type').value;
            const coursesDiv = document.getElementById('target-courses');
            const catsDiv = document.getElementById('target-categories');
            const exclusionsDiv = document.getElementById('target-exclusions');
            const coursesSelect = document.getElementById('courses-select');
            const catsSelect = document.getElementById('categories-select');
            const excSelect = document.getElementById('exclusions-select');

            coursesDiv.classList.add('hidden');
            catsDiv.classList.add('hidden');
            exclusionsDiv.classList.add('hidden');
            coursesSelect.disabled = true;
            catsSelect.disabled = true;
            excSelect.disabled = true;

            if (type === 'course') {
                coursesDiv.classList.remove('hidden');
                coursesSelect.disabled = false;
                catsSelect.name = ''; 
                coursesSelect.name = 'target_ids[]';
            } else if (type === 'category') {
                catsDiv.classList.remove('hidden');
                exclusionsDiv.classList.remove('hidden');
                catsSelect.disabled = false;
                excSelect.disabled = false;
                coursesSelect.name = '';
                catsSelect.name = 'target_ids[]';
                updateExclusions();
            }
        }

        // LÓGICA DE EXCLUSIONES (Mostrar solo cursos de categorías seleccionadas)
        function updateExclusions() {
            const catsSelect = document.getElementById('categories-select');
            const selectedCatIds = Array.from(catsSelect.selectedOptions).map(opt => parseInt(opt.value));
            const excOptions = document.querySelectorAll('#exclusions-select option');

            excOptions.forEach(opt => {
                const courseCats = JSON.parse(opt.getAttribute('data-categories') || '[]');
                const hasMatch = courseCats.some(catId => selectedCatIds.includes(catId));
                
                if (hasMatch) {
                    opt.classList.remove('hidden', 'logic-hidden');
                    opt.style.display = "";
                } else {
                    opt.classList.add('hidden', 'logic-hidden');
                    opt.style.display = "none";
                    opt.selected = false; // Deseleccionar si ya no aplica
                }
            });
        }

        // RESETEAR MODAL
        function openPromoModal() {
            document.getElementById('promoForm').reset();
            document.getElementById('promoForm').action = "{{ route('admin.promotions.store') }}";
            document.getElementById('method-field').innerHTML = '';
            document.getElementById('modal-title').innerText = 'Nueva Promoción';
            document.querySelectorAll('#exclusions-select option').forEach(o => { o.selected = false; o.classList.add('hidden', 'logic-hidden'); });
            toggleTargets();
            document.getElementById('promo-modal').classList.remove('hidden');
        }

        // CARGAR DATOS PARA EDICIÓN
        function editPromo(promo) {
            console.log("Editando promo:", promo);
            
            const form = document.getElementById('promoForm');
            form.action = `/admin/promociones/${promo.id}`;
            document.getElementById('method-field').innerHTML = '<input type="hidden" name="_method" value="PUT">';
            document.getElementById('modal-title').innerText = 'Editar Promoción';

            document.getElementById('name').value = promo.name;
            document.getElementById('discount_type').value = promo.discount_type;
            document.getElementById('value').value = promo.value;
            document.getElementById('target_type').value = promo.target_type;
            
            // FECHAS: Convertir UTC BD a Local Bolivia (UTC-4)
            if(promo.start_date) {
                let start = new Date(promo.start_date);
                start.setHours(start.getHours() - 4);
                document.getElementById('start_date').value = start.toISOString().substring(0, 16);
            }
            if(promo.end_date) {
                let end = new Date(promo.end_date);
                end.setHours(end.getHours() - 4);
                document.getElementById('end_date').value = end.toISOString().substring(0, 16);
            }

            toggleTargets();

            // ASEGURAR QUE LOS IDS SEAN STRINGS (para comparación)
            const parseToArr = (val) => {
                if (!val) return [];
                if (Array.isArray(val)) return val.map(String);
                try { 
                    const parsed = JSON.parse(val); 
                    return Array.isArray(parsed) ? parsed.map(String) : [];
                } catch(e) { return []; }
            };

            const targetIds = parseToArr(promo.target_ids);
            const exceptionIds = parseToArr(promo.exception_ids);

            if (promo.target_type === 'course') {
                const select = document.getElementById('courses-select');
                Array.from(select.options).forEach(opt => {
                    opt.selected = targetIds.includes(String(opt.value));
                });
                sortSelectOptions(select); 

            } else if (promo.target_type === 'category') {
                const select = document.getElementById('categories-select');
                Array.from(select.options).forEach(opt => {
                    opt.selected = targetIds.includes(String(opt.value));
                });
                
                updateExclusions();

                const excSelect = document.getElementById('exclusions-select');
                Array.from(excSelect.options).forEach(opt => {
                    if (exceptionIds.includes(String(opt.value))) {
                        opt.selected = true;
                    }
                });
            }

            document.getElementById('promo-modal').classList.remove('hidden');
        }

        // MOVER SELECCIONADOS AL INICIO
        function sortSelectOptions(select) {
            const options = Array.from(select.options);
            options.sort((a, b) => {
                if (a.selected && !b.selected) return -1;
                if (!a.selected && b.selected) return 1;
                return 0;
            });
            options.forEach(opt => select.add(opt));
        }

        function closePromoModal() {
            document.getElementById('promo-modal').classList.add('hidden');
        }
    </script>
</x-layouts.admin>