<x-layouts.admin>
    <x-slot name="title">Creador de Cursos</x-slot>
    <x-slot name="header">{{ $course->exists ? 'Editar Curso' : 'Crear Nuevo Curso' }}</x-slot>

    <!-- TOAST NOTIFICATION (Flotante) -->
    <div id="toast-notification" class="fixed top-24 right-5 z-[100] transform transition-all duration-500 translate-x-full opacity-0 pointer-events-none">
        <div class="bg-[#213A57] text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-4 border-l-4 border-[#0AD1C8] min-w-[300px]">
            <div class="bg-white/10 p-2 rounded-full">
                <i class="ph-fill ph-check-circle text-2xl text-[#0AD1C8]"></i>
            </div>
            <div>
                <h4 class="font-bold text-sm tracking-wide">¡Operación Exitosa!</h4>
                <p class="text-xs text-gray-200 mt-1" id="toast-message">El curso se ha guardado correctamente.</p>
            </div>
            <button onclick="hideToast()" class="ml-auto text-gray-400 hover:text-white transition-colors">
                <i class="ph-bold ph-x text-lg"></i>
            </button>
        </div>
    </div>

    <!-- FORMULARIO -->
    <form id="courseForm" action="{{ $course->exists ? route('admin.courses.update', $course->id) : route('admin.courses.store') }}" method="POST" enctype="multipart/form-data" class="relative pb-32">
        @csrf
        @if($course->exists) @method('PUT') @endif

        <!-- Inputs Ocultos -->
        <input type="hidden" name="builder_data" id="builder_data">
        
        <!-- NAVEGACIÓN DE PASOS (PESTAÑAS) -->
        <div class="bg-white rounded-t-2xl shadow-sm border-b border-gray-200 mb-0">
            <div class="flex overflow-x-auto no-scrollbar">
                <button type="button" onclick="showTab('info')" id="tab-btn-info" class="flex-1 py-4 px-6 text-center border-b-4 border-[#213A57] text-[#213A57] font-bold bg-blue-50 transition-all flex items-center justify-center gap-2 whitespace-nowrap min-w-[140px]">
                    <div class="w-6 h-6 rounded-full bg-[#213A57] text-white text-xs flex items-center justify-center shrink-0">1</div> Info
                </button>
                <button type="button" onclick="showTab('attendance')" id="tab-btn-attendance" class="flex-1 py-4 px-6 text-center border-b-4 border-transparent text-gray-500 font-medium hover:bg-gray-50 transition-all flex items-center justify-center gap-2 whitespace-nowrap min-w-[140px]">
                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center shrink-0">2</div> Asistencia
                </button>
                <button type="button" onclick="showTab('builder')" id="tab-btn-builder" class="flex-1 py-4 px-6 text-center border-b-4 border-transparent text-gray-500 font-medium hover:bg-gray-50 transition-all flex items-center justify-center gap-2 whitespace-nowrap min-w-[140px]">
                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center shrink-0">3</div> Contenido
                </button>
                <button type="button" onclick="showTab('evaluation')" id="tab-btn-evaluation" class="flex-1 py-4 px-6 text-center border-b-4 border-transparent text-gray-500 font-medium hover:bg-gray-50 transition-all flex items-center justify-center gap-2 whitespace-nowrap min-w-[140px]">
                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center shrink-0">4</div> Evaluación
                </button>
                <button type="button" onclick="showTab('certificate')" id="tab-btn-certificate" class="flex-1 py-4 px-6 text-center border-b-4 border-transparent text-gray-500 font-medium hover:bg-gray-50 transition-all flex items-center justify-center gap-2 whitespace-nowrap min-w-[140px]">
                    <div class="w-6 h-6 rounded-full bg-gray-200 text-gray-500 text-xs flex items-center justify-center shrink-0">5</div> Certificado
                </button>
            </div>
        </div>

        <!-- CONTENIDO DE LOS PASOS -->
        <div class="bg-white rounded-b-2xl shadow-sm border border-gray-100 border-t-0 p-6 min-h-[500px]">
            <div id="tab-info" class="tab-content">@include('admin.courses.partials.info')</div>
            <div id="tab-attendance" class="tab-content hidden">@include('admin.courses.partials.attendance')</div>
            <div id="tab-builder" class="tab-content hidden">@include('admin.courses.partials.builder')</div>
            <div id="tab-evaluation" class="tab-content hidden">@include('admin.courses.partials.evaluation')</div>
            
            <!-- CORRECCIÓN AQUÍ: Solo cargar el parcial si el curso existe y tiene instructor -->
            <div id="tab-certificate" class="tab-content hidden">
                @if($course->exists && $course->instructor)
                    @include('admin.courses.partials.certificate')
                @else
                    <div class="flex flex-col items-center justify-center py-20 text-gray-400">
                        <i class="ph-duotone ph-seal-warning text-6xl mb-4 text-yellow-500"></i>
                        <h3 class="text-lg font-bold text-[#213A57]">Configuración de Certificado no disponible</h3>
                        <p class="max-w-md text-center text-sm mt-2">
                            Para configurar el certificado, primero debes <b>Guardar</b> el curso y asegurarte de asignar un <b>Docente</b> en la pestaña "Info".
                        </p>
                    </div>
                @endif
            </div>
        </div>

        <!-- BARRA DE ACCIÓN FLOTANTE -->
        <div class="fixed bottom-0 right-0 left-0 lg:left-72 bg-white/95 backdrop-blur border-t border-gray-200 p-4 z-50 flex justify-end gap-4 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
            <button type="button" onclick="submitCourseAll()" class="px-8 py-2 bg-[#213A57] text-white font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-lg flex items-center gap-2 transform hover:-translate-y-0.5">
                <i class="ph-bold ph-floppy-disk"></i> Guardar Curso
            </button>
        </div>

    </form>

    <script>
        // --- LÓGICA DE INICIALIZACIÓN ---
        document.addEventListener('DOMContentLoaded', () => {
            @if(session('success'))
                showToast("{{ session('success') }}");
            @endif

            let activeTab = 'info';
            const hash = window.location.hash.substring(1); 
            
            if (hash && document.getElementById('tab-' + hash)) {
                activeTab = hash;
            } else if (localStorage.getItem('activeCourseTab') && document.getElementById('tab-' + localStorage.getItem('activeCourseTab'))) {
                activeTab = localStorage.getItem('activeCourseTab');
            }

            @if(session('success'))
                if (localStorage.getItem('activeCourseTab')) {
                    activeTab = localStorage.getItem('activeCourseTab');
                }
            @endif

            showTab(activeTab, false);
        });

        // --- FUNCIONES DE PESTAÑAS ---
        function showTab(tabId, shouldScroll = true) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            
            const content = document.getElementById('tab-' + tabId);
            if(content) content.classList.remove('hidden');
            
            document.querySelectorAll('.overflow-x-auto button').forEach(btn => {
                btn.classList.remove('border-[#213A57]', 'bg-blue-50', 'text-[#213A57]');
                btn.classList.add('border-transparent', 'text-gray-500');
                btn.querySelector('div').classList.remove('bg-[#213A57]', 'text-white');
                btn.querySelector('div').classList.add('bg-gray-200', 'text-gray-500');
            });

            const activeBtn = document.getElementById('tab-btn-' + tabId);
            if(activeBtn) {
                activeBtn.classList.remove('border-transparent', 'text-gray-500');
                activeBtn.classList.add('border-[#213A57]', 'bg-blue-50', 'text-[#213A57]');
                activeBtn.querySelector('div').classList.remove('bg-gray-200', 'text-gray-500');
                activeBtn.querySelector('div').classList.add('bg-[#213A57]', 'text-white');
            }

            history.replaceState(null, null, '#' + tabId); 
            localStorage.setItem('activeCourseTab', tabId); 

            if (shouldScroll) {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }

        // --- FUNCIONES TOAST ---
        function showToast(message) {
            const toast = document.getElementById('toast-notification');
            const msgEl = document.getElementById('toast-message');
            msgEl.innerText = message;
            toast.classList.remove('translate-x-full', 'opacity-0', 'pointer-events-none');
            setTimeout(() => { hideToast(); }, 5000);
        }

        function hideToast() {
            const toast = document.getElementById('toast-notification');
            toast.classList.add('translate-x-full', 'opacity-0', 'pointer-events-none');
        }

        // --- SUBMIT DEL FORMULARIO ---
        function submitCourseAll() {
            const form = document.getElementById('courseForm');

            if (!form.checkValidity()) {
                showTab('info');
                setTimeout(() => form.reportValidity(), 100); 
                showToast("Por favor completa los campos obligatorios en la pestaña 'Info'.");
                return; 
            }

            try {
                if (typeof modules !== 'undefined') {
                    document.getElementById('builder_data').value = JSON.stringify(modules);
                }
            } catch(e) { console.warn('Builder:', e); }
            
            try { if (typeof updateEvaluationInput === 'function') updateEvaluationInput(); } catch(e) {}
            try { if (typeof syncAttendanceInput === 'function') syncAttendanceInput(); } catch(e) {}
            
            try { 
                if (typeof updateCertificateInput === 'function') {
                    updateCertificateInput(); 
                } else if (typeof window.updateCertificateInput === 'function') {
                    window.updateCertificateInput();
                }
            } catch(e) { console.error('Error sync certificado:', e); }

            const currentHash = window.location.hash.substring(1) || 'info';
            localStorage.setItem('activeCourseTab', currentHash);

            form.submit();
        }
    </script>
</x-layouts.admin>