<!-- LIBRERÍAS "MINIWORD" (QUILL) -->
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

<!-- INPUT OCULTO -->
<input type="hidden" name="certificate_data" id="certificate_data_input" value="{{ json_encode($course->certificate_template ?? []) }}">

<style>
    /* =========================================
       ESTILOS DEL EDITOR (ADMIN)
       ========================================= */
    
    #cert-canvas {
        width: 1123px;
        height: 794px;
        background-color: white;
        position: relative;
        box-shadow: 0 0 40px rgba(0,0,0,0.1);
        overflow: hidden;
        margin: 0 auto;
        
        /* RESETEO ESTILOS */
        line-height: 1.15 !important;
        text-align: left;
        color: black;
        font-size: 16px;
        transform-origin: top center;
    }

    #cert-canvas * {
        box-sizing: border-box !important;
        margin: 0 !important;
        padding: 0 !important;
        border: 0 !important;
    }

    .cert-element {
        position: absolute;
        user-select: none;
        cursor: grab;
        display: flex;
        flex-direction: column;
        z-index: 10;
        
        /* Borde siempre visible pero sutil */
        border: 1px dashed rgba(0, 0, 0, 0.15) !important;
        min-width: 50px; 
    }

    .cert-element:hover { 
        border-color: #0AD1C8 !important; 
        background-color: rgba(10, 209, 200, 0.05); 
    }
    .cert-element.selected { 
        border: 2px solid #213A57 !important; 
        background-color: rgba(33, 58, 87, 0.05);
        z-index: 100; 
        cursor: grabbing; /* Mover */
        box-shadow: 0 0 0 4px rgba(33, 58, 87, 0.1);
    }

    /* ESTILOS PARA LOS PUNTOS DE REDIMENSIÓN */
    .resize-handle {
        position: absolute;
        width: 12px;
        height: 12px;
        background-color: #0AD1C8; /* Color visible */
        border: 2px solid white;
        border-radius: 50%;
        z-index: 110; /* Encima del elemento */
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        display: none; /* Oculto por defecto */
    }
    
    /* Mostrar solo cuando el padre está seleccionado */
    .cert-element.selected .resize-handle {
        display: block;
    }

    /* Posiciones de los handles */
    .handle-nw { top: -6px; left: -6px; cursor: nw-resize; }
    .handle-ne { top: -6px; right: -6px; cursor: ne-resize; }
    .handle-sw { bottom: -6px; left: -6px; cursor: sw-resize; }
    .handle-se { bottom: -6px; right: -6px; cursor: se-resize; }

    .cert-element img {
        display: block;
        pointer-events: none;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    /* ESTILOS QUILL (MINIWORD) PERSONALIZADOS */
    .ql-toolbar.ql-snow { border: 1px solid #e5e7eb; border-radius: 8px 8px 0 0; background: #f9fafb; }
    .ql-container.ql-snow { border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; background: white; font-family: inherit; font-size: 13px; }
    .ql-editor { min-height: 120px; }

    /* Fuentes */
    @import url('https://fonts.googleapis.com/css2?family=Great+Vibes&family=Lato:wght@400;700;900&family=Merriweather:wght@400;700&family=Pinyon+Script&family=Montserrat:wght@400;700&family=Open+Sans:wght@400;700&display=swap');
    
    .font-lato { font-family: 'Lato', sans-serif; }
    .font-merriweather { font-family: 'Merriweather', serif; }
    .font-pinyon { font-family: 'Pinyon Script', cursive; }
    .font-greatvibes { font-family: 'Great Vibes', cursive; }
    .font-montserrat { font-family: 'Montserrat', sans-serif; }
    .font-opensans { font-family: 'Open Sans', sans-serif; }
    
    /* Botones Alineación Activos */
    .align-btn.active {
        background-color: #e0f2fe;
        color: #0284c7;
        border-color: #0284c7;
    }
</style>

<script>
    window.courseMeta = {
        title: @json($course->title),
        instructor: {
            name: @json($course->instructor->certificate_name ?? $course->instructor->name ?? 'Instructor'),
            role: "CAPACITADOR",
            signature: "{{ $course->instructor->signature_url ? asset($course->instructor->signature_url) : null }}" 
        },
        manager: {
            name: "Ing. Fanny Apaza",
            role: "GERENTE GENERAL",
            signature: null 
        },
        studentExample: "JUAN PÉREZ DE LA CRUZ"
    };

    const mediaRoutes = {
        list: "{{ route('admin.media.list') }}",
        upload: "{{ route('admin.media.upload') }}",
        delete: "{{ route('admin.media.delete') }}"
    };
</script>

<div class="flex flex-col lg:flex-row h-[800px] border border-gray-200 rounded-2xl overflow-hidden bg-gray-100">
    
    <!-- BARRA LATERAL -->
    <div class="w-full lg:w-72 bg-white border-r border-gray-200 flex flex-col z-30 shadow-lg relative transition-all duration-300">
        <!-- HEADER PANEL -->
        <div class="p-4 bg-[#213A57] text-white font-bold flex justify-between items-center shrink-0">
            <span id="sidebar-title">Agregar Elementos</span>
            <div class="flex gap-1">
                <button type="button" onclick="zoomCanvas(-0.1)" class="text-xs bg-white/20 px-2 py-1 rounded hover:bg-white/30"><i class="ph-bold ph-minus"></i></button>
                <button type="button" onclick="zoomCanvas(0.1)" class="text-xs bg-white/20 px-2 py-1 rounded hover:bg-white/30"><i class="ph-bold ph-plus"></i></button>
            </div>
        </div>
        
        <!-- PANEL 1: CATALOGO DE ELEMENTOS -->
        <div id="panel-add" class="flex-1 overflow-y-auto p-3 space-y-2">
            <!-- BOTONES -->
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Textos Dinámicos</p>
            <button type="button" onclick="addElement('student_name')" class="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex items-center gap-3 hover:border-blue-400 transition-all text-left group">
                <i class="ph-bold ph-student text-lg text-gray-400 group-hover:text-blue-500"></i><span class="text-xs font-bold text-gray-600">Nombre Estudiante</span>
            </button>
            <button type="button" onclick="addElement('course_title')" class="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex items-center gap-3 hover:border-blue-400 transition-all text-left group">
                <i class="ph-bold ph-graduation-cap text-lg text-gray-400 group-hover:text-blue-500"></i><span class="text-xs font-bold text-gray-600">Título Curso</span>
            </button>
            <button type="button" onclick="addElement('text')" class="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex items-center gap-3 hover:border-blue-400 transition-all text-left group">
                <i class="ph-bold ph-text-t text-lg text-gray-400 group-hover:text-blue-500"></i><span class="text-xs font-bold text-gray-600">Texto Libre</span>
            </button>
            
            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-4 mb-2">Gráficos</p>
            <div class="grid grid-cols-2 gap-2">
                <button type="button" onclick="addElement('qr')" class="p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex flex-col items-center gap-1 hover:border-blue-400 transition-all">
                    <i class="ph-bold ph-qr-code text-xl text-gray-400"></i><span class="text-[10px] font-bold text-gray-600">QR</span>
                </button>
                <button type="button" onclick="openMediaManager('seal')" class="p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex flex-col items-center gap-1 hover:border-blue-400 transition-all">
                    <i class="ph-bold ph-image text-xl text-gray-400"></i><span class="text-[10px] font-bold text-gray-600">Imagen</span>
                </button>
            </div>

            <p class="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-4 mb-2">Firmas (Autoajustables)</p>
            <button type="button" onclick="addElement('signature')" class="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex items-center gap-3 hover:border-purple-400 transition-all text-left">
                <i class="ph-bold ph-pen-nib text-lg text-purple-400"></i><span class="text-xs font-bold text-gray-600">Instructor</span>
            </button>
            <button type="button" onclick="addElement('manager_signature')" class="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg flex items-center gap-3 hover:border-purple-400 transition-all text-left">
                <i class="ph-bold ph-briefcase text-lg text-purple-400"></i><span class="text-xs font-bold text-gray-600">Gerente</span>
            </button>

            <div class="mt-6 pt-4 border-t border-gray-200">
                <button type="button" onclick="openMediaManager('background')" class="w-full py-2 bg-[#E0F9F6] border border-[#0AD1C8] text-[#0B6477] rounded-lg font-bold text-xs flex items-center justify-center gap-2">
                    <i class="ph-bold ph-image-square"></i> Cambiar Fondo
                </button>
            </div>
        </div>

        <!-- PANEL 2: PROPIEDADES (ELEMENTOR STYLE) -->
        <div id="panel-edit" class="hidden flex-col h-full bg-gray-50 absolute inset-0 z-40">
            <div class="px-4 py-3 bg-white border-b border-gray-200 flex items-center gap-2 shrink-0">
                <button onclick="deselectAll()" class="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500"><i class="ph-bold ph-arrow-left"></i></button>
                <span class="text-xs font-bold text-gray-700 uppercase tracking-wide">Editar Elemento</span>
            </div>

            <div class="flex-1 overflow-y-auto p-4 space-y-6">
                
                <!-- SECCION: TEXTO (CON MINIWORD QUILL) -->
                <div id="group-content" class="hidden space-y-2">
                    <label class="text-[10px] font-bold text-gray-400 uppercase">Contenido del Texto</label>
                    <div id="cert-text-editor"></div> <!-- AQUÍ ESTÁ EL MINIWORD -->
                </div>

                <!-- SECCION: TIPOGRAFÍA -->
                <div id="group-typography" class="space-y-4 hidden">
                    <label class="text-[10px] font-bold text-gray-400 uppercase border-b border-gray-200 pb-1 block">Tipografía</label>
                    
                    <div class="space-y-2">
                        <label class="text-xs text-gray-500 font-medium">Fuente</label>
                        <select id="prop-font-family" class="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs outline-none" onchange="updateSelectedProp('fontFamily', this.value)">
                            <option value="font-lato">Lato (Sans)</option>
                            <option value="font-montserrat">Montserrat (Geo)</option>
                            <option value="font-opensans">Open Sans (Clean)</option>
                            <option value="font-merriweather">Merriweather (Serif)</option>
                            <option value="font-pinyon">Pinyon Script (Cursiva)</option>
                            <option value="font-greatvibes">Great Vibes (Elegante)</option>
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="space-y-1">
                            <label class="text-xs text-gray-500 font-medium">Tamaño (px)</label>
                            <input type="number" id="prop-font-size" class="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs" oninput="updateSelectedProp('fontSize', this.value)">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs text-gray-500 font-medium">Color</label>
                            <div class="flex items-center gap-2 bg-white border border-gray-300 rounded-lg p-1">
                                <input type="color" id="prop-color" class="w-6 h-6 border-none p-0 bg-transparent cursor-pointer" oninput="updateSelectedProp('color', this.value)">
                                <span class="text-[10px] text-gray-400">PICK</span>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-2">
                        <button type="button" onclick="toggleStyle('fontWeight')" id="btn-bold" class="flex-1 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 text-xs font-bold">B</button>
                        <button type="button" onclick="toggleStyle('fontStyle')" id="btn-italic" class="flex-1 py-2 bg-white border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 text-xs italic">I</button>
                    </div>

                    <div class="space-y-2">
                        <label class="text-xs text-gray-500 font-medium">Alineación</label>
                        <div class="flex bg-gray-200 p-1 rounded-lg">
                            <button type="button" onclick="updateSelectedProp('textAlign', 'left')" id="align-left" class="align-btn flex-1 py-1 rounded text-gray-600 text-xs transition-colors"><i class="ph-bold ph-text-align-left"></i></button>
                            <button type="button" onclick="updateSelectedProp('textAlign', 'center')" id="align-center" class="align-btn flex-1 py-1 rounded text-gray-600 text-xs transition-colors"><i class="ph-bold ph-text-align-center"></i></button>
                            <button type="button" onclick="updateSelectedProp('textAlign', 'right')" id="align-right" class="align-btn flex-1 py-1 rounded text-gray-600 text-xs transition-colors"><i class="ph-bold ph-text-align-right"></i></button>
                        </div>
                    </div>
                </div>

                <!-- SECCION: DIMENSIONES (Caja de Texto) -->
                <div id="group-dimensions" class="space-y-4 hidden">
                    <label class="text-[10px] font-bold text-gray-400 uppercase border-b border-gray-200 pb-1 block">Dimensiones de Caja</label>
                    <div class="space-y-2">
                        <div class="flex justify-between">
                            <label class="text-xs text-gray-500 font-medium">Ancho Horizontal</label>
                            <span class="text-[10px] text-blue-500 cursor-pointer" onclick="updateSelectedProp('width', 'auto'); document.getElementById('prop-width').value='';">Resetear a Auto</span>
                        </div>
                        <input type="range" id="prop-width-range" min="100" max="1100" step="10" class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#213A57]" oninput="updateSelectedProp('width', this.value)">
                        <div class="flex items-center gap-2">
                            <input type="number" id="prop-width" class="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs" placeholder="Auto" oninput="updateSelectedProp('width', this.value)">
                            <span class="text-xs text-gray-400">px</span>
                        </div>
                    </div>
                </div>

                <!-- SECCION: IMAGEN (Solo QR/Imagen) -->
                <div id="group-image" class="space-y-4 hidden">
                    <label class="text-[10px] font-bold text-gray-400 uppercase border-b border-gray-200 pb-1 block">Imagen</label>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="space-y-1">
                            <label class="text-xs text-gray-500 font-medium">Ancho (px)</label>
                            <input type="number" id="prop-img-w" class="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs" oninput="updateSelectedProp('width', this.value)">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs text-gray-500 font-medium">Alto (px)</label>
                            <input type="number" id="prop-img-h" class="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs" oninput="updateSelectedProp('height', this.value)">
                        </div>
                    </div>
                    <button type="button" id="btn-change-img" onclick="openMediaManager('seal')" class="w-full py-2 bg-blue-50 text-blue-600 border border-blue-200 rounded-lg text-xs font-bold mt-2">Cambiar Imagen</button>
                </div>

                <!-- SECCION: FIRMA GERENTE (NUEVO) -->
                <div id="group-manager-sig" class="hidden space-y-4">
                    <label class="text-[10px] font-bold text-gray-400 uppercase border-b border-gray-200 pb-1 block">Firma Gerente</label>
                    <p class="text-xs text-gray-500">Sube la imagen de la firma (PNG transparente recomendado).</p>
                    <button type="button" onclick="openMediaManager('manager_signature')" class="w-full py-2 bg-blue-50 text-blue-600 border border-blue-200 rounded-lg text-xs font-bold mt-2">
                        <i class="ph-bold ph-upload-simple"></i> Seleccionar Firma
                    </button>
                </div>

                <!-- Acciones -->
                <div class="pt-6 border-t border-gray-200">
                    <button type="button" onclick="removeSelectedElement()" class="w-full py-2.5 bg-red-50 text-red-600 border border-red-200 rounded-xl text-xs font-bold hover:bg-red-100 flex items-center justify-center gap-2">
                        <i class="ph-bold ph-trash"></i> Eliminar Elemento
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- AREA DE TRABAJO -->
    <div class="flex-1 overflow-hidden relative bg-slate-200 flex" id="workspace-container">
        <div class="w-full h-full overflow-auto flex items-start justify-center p-10" id="scroll-area">
            
            <div id="cert-canvas" onclick="if(event.target === this) deselectAll()">
                <img id="cert-background" src="" class="absolute inset-0 w-full h-full object-fill pointer-events-none z-0 hidden">
                
                <div id="cert-background-placeholder" class="absolute inset-0 flex items-center justify-center text-gray-400 z-0 border-2 border-dashed border-gray-300 m-8 rounded-2xl pointer-events-none bg-white">
                    <div class="text-center">
                        <i class="ph-duotone ph-image text-6xl mb-3 text-slate-300"></i>
                        <p class="text-sm font-bold text-slate-400">Sin Fondo</p>
                    </div>
                </div>

                <div id="elements-layer" class="absolute inset-0 z-10 w-full h-full"></div>
            </div>

        </div>
        <div class="absolute bottom-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold shadow border border-gray-200 z-50 text-gray-600">
            <span id="zoom-level-indicator">100%</span>
        </div>
    </div>
</div>

<!-- ============================================== -->
<!-- MODAL GESTOR DE MEDIOS                         -->
<!-- ============================================== -->
<div id="media-modal" class="fixed inset-0 z-[100] hidden" role="dialog" aria-modal="true">
    <div class="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onclick="closeMediaManager()"></div>
    
    <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-xl transition-all w-full max-w-3xl flex flex-col h-[600px]">
                
                <!-- Header Modal -->
                <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center shrink-0">
                    <div>
                        <h3 class="text-lg font-bold text-[#213A57]">Biblioteca de Medios</h3>
                        <p class="text-xs text-gray-500">Selecciona una imagen o sube una nueva.</p>
                    </div>
                    <button type="button" onclick="closeMediaManager()" class="text-gray-400 hover:text-red-500 rounded-full p-1"><i class="ph-bold ph-x text-xl"></i></button>
                </div>

                <!-- Toolbar de Subida -->
                <div class="p-4 border-b border-gray-100 flex justify-between items-center bg-white shrink-0">
                    <label class="px-4 py-2 bg-[#213A57] text-white rounded-lg text-sm font-bold cursor-pointer hover:bg-[#0B6477] transition-colors flex items-center gap-2" id="upload-btn-label">
                        <i class="ph-bold ph-upload-simple"></i> Subir Imagen
                        <input type="file" class="hidden" accept="image/*" onchange="uploadMediaFile(this)">
                    </label>
                    <button type="button" onclick="loadMediaLibrary()" class="text-gray-400 hover:text-[#213A57]"><i class="ph-bold ph-arrow-clockwise text-xl"></i></button>
                </div>

                <!-- Grid de Imágenes -->
                <div class="flex-1 overflow-y-auto p-4 bg-gray-50">
                    <div id="media-grid" class="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                        <!-- Se llena vía JS -->
                        <div class="col-span-full text-center py-10 text-gray-400">Cargando imágenes...</div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script>
    let certState = { background: null, elements: [] };
    let selectedElementId = null;
    let currentZoom = 1;
    let isDragging = false;
    let dragOffset = { x: 0, y: 0 };
    let dragElId = null;
    
    // VARIABLES REDIMENSIÓN
    let isResizing = false;
    let resizeData = { startX: 0, startY: 0, startW: 0, startH: 0, handle: '' };
    
    // VARIABLES MEDIA MANAGER
    let mediaContext = null; 
    
    // VARIABLES MINIWORD
    let quillEditor = null;

    document.addEventListener("DOMContentLoaded", function() {
        // Inicializar Quill para el Miniword
        quillEditor = new Quill('#cert-text-editor', {
            theme: 'snow',
            modules: {
                toolbar: [
                    ['bold', 'italic', 'underline'], // Formato básico
                    [{ 'color': [] }, { 'background': [] }], // Colores
                    ['clean'] // Limpiar
                ]
            }
        });
        
        // Escuchar cambios en el editor para actualizar el canvas en vivo
        quillEditor.on('text-change', function() {
            updateSelectedProp('content', quillEditor.root.innerHTML);
        });

        const saved = @json($course->certificate_template ?? null);
        if (saved) {
            certState = {
                background: fixUrl(saved.background),
                elements: saved.elements || []
            };
        }
        renderCanvas();
        setTimeout(fitCanvas, 100);
    });

    // --- FUNCIONES SELECCION Y EDICION ---
    function selectElement(id) {
        selectedElementId = id;
        renderCanvas(); 
        showEditPanel(); 
    }

    function deselectAll() {
        selectedElementId = null;
        renderCanvas();
        showAddPanel(); 
    }

    function showAddPanel() {
        document.getElementById('panel-add').classList.remove('hidden');
        document.getElementById('panel-edit').classList.add('hidden');
        document.getElementById('sidebar-title').innerText = "Agregar Elementos";
    }

    function showEditPanel() {
        const el = certState.elements.find(e => e.id === selectedElementId);
        if (!el) return;

        document.getElementById('panel-add').classList.add('hidden');
        document.getElementById('panel-edit').classList.remove('hidden');
        document.getElementById('sidebar-title').innerText = "Editar Elemento";

        // Ocultar todos los grupos primero
        ['group-content', 'group-typography', 'group-dimensions', 'group-image', 'group-manager-sig'].forEach(id => {
            const grp = document.getElementById(id);
            if(grp) grp.classList.add('hidden');
        });

        // Llenar datos y mostrar grupos según tipo
        if (['text', 'student_name', 'course_title'].includes(el.type)) {
            document.getElementById('group-typography').classList.remove('hidden');
            document.getElementById('group-dimensions').classList.remove('hidden');
            
            // Llenar Valores
            setValue('prop-font-family', el.style.fontFamily || 'font-lato');
            setValue('prop-font-size', parseInt(el.style.fontSize) || 18);
            setValue('prop-color', el.style.color || '#000000');
            setValue('prop-width', (el.style.width === 'auto' ? '' : parseInt(el.style.width)));
            setValue('prop-width-range', (el.style.width === 'auto' ? 100 : parseInt(el.style.width)));
            
            // Botones Estilo
            toggleBtnClass('btn-bold', el.style.fontWeight === 'bold');
            toggleBtnClass('btn-italic', el.style.fontStyle === 'italic');
            
            // Botones Alineación
            document.querySelectorAll('.align-btn').forEach(b => b.classList.remove('active'));
            const align = el.style.textAlign || 'left';
            const alignBtn = document.getElementById('align-' + align);
            if(alignBtn) alignBtn.classList.add('active');

            // NUEVO: Mostrar editor "MiniWord" para 'text' Y 'course_title'
            if (['text', 'course_title'].includes(el.type)) {
                document.getElementById('group-content').classList.remove('hidden');
                
                // Si es course_title y no tiene contenido propio (viene del default object vacío), usar título real
                let val = el.content;
                if(el.type === 'course_title' && (typeof val !== 'string' || !val)) val = window.courseMeta.title;
                
                // Cargar valor en Quill
                quillEditor.root.innerHTML = val || '';
            }
        } 
        else if (['qr', 'seal', 'image'].includes(el.type)) {
            document.getElementById('group-image').classList.remove('hidden');
            setValue('prop-img-w', parseInt(el.style.width));
            setValue('prop-img-h', parseInt(el.style.height));
            
            const btnChange = document.getElementById('btn-change-img');
            btnChange.style.display = (el.type === 'qr') ? 'none' : 'block';
        }
        // NUEVO: Mostrar panel de firma gerente
        else if (el.type === 'manager_signature') {
             document.getElementById('group-manager-sig').classList.remove('hidden');
        }
    }

    function updateSelectedProp(prop, value) {
        if (!selectedElementId) return;
        const idx = certState.elements.findIndex(e => e.id === selectedElementId);
        if (idx === -1) return;

        if (prop === 'width' || prop === 'height') {
            if (value === 'auto' || value === '') {
                certState.elements[idx].style[prop] = 'auto';
            } else {
                certState.elements[idx].style[prop] = value + 'px';
            }
            if(prop === 'width') {
                if(document.getElementById('prop-width').value != value) document.getElementById('prop-width').value = value;
                if(document.getElementById('prop-width-range').value != value) document.getElementById('prop-width-range').value = value;
            }
        } 
        else if (prop === 'fontSize') {
            certState.elements[idx].style[prop] = value + 'px';
        }
        else if (prop === 'content') {
            certState.elements[idx].content = value;
        }
        else {
            certState.elements[idx].style[prop] = value;
        }

        if (prop === 'textAlign') showEditPanel(); 

        renderCanvas();
    }

    function toggleStyle(prop) {
        if (!selectedElementId) return;
        const idx = certState.elements.findIndex(e => e.id === selectedElementId);
        const el = certState.elements[idx];
        
        let newVal;
        if (prop === 'fontWeight') newVal = (el.style.fontWeight === 'bold') ? 'normal' : 'bold';
        if (prop === 'fontStyle') newVal = (el.style.fontStyle === 'italic') ? 'normal' : 'italic';
        
        el.style[prop] = newVal;
        renderCanvas();
        showEditPanel(); 
    }

    // --- FUNCIONES MEDIA MANAGER ---
    function openMediaManager(context) {
        mediaContext = context;
        document.getElementById('media-modal').classList.remove('hidden');
        loadMediaLibrary();
    }

    function closeMediaManager() {
        document.getElementById('media-modal').classList.add('hidden');
    }

    function loadMediaLibrary() {
        const grid = document.getElementById('media-grid');
        grid.innerHTML = '<div class="col-span-full text-center py-10 text-gray-400 flex flex-col items-center"><i class="ph-duotone ph-spinner animate-spin text-2xl mb-2"></i> Cargando...</div>';

        fetch(mediaRoutes.list)
            .then(res => res.json())
            .then(files => {
                grid.innerHTML = '';
                if(files.length === 0) {
                    grid.innerHTML = '<div class="col-span-full text-center py-10 text-gray-400 italic">No hay imágenes. Sube una para comenzar.</div>';
                    return;
                }
                
                files.forEach(file => {
                    const url = typeof file === 'string' ? file : (file.url || '');
                    const div = document.createElement('div');
                    div.className = 'aspect-square bg-white rounded-xl overflow-hidden border border-gray-200 cursor-pointer hover:border-[#0AD1C8] hover:ring-2 hover:ring-[#0AD1C8]/20 relative group transition-all';
                    div.onclick = () => selectMediaItem(url);
                    div.innerHTML = `
                        <img src="${url}" class="w-full h-full object-contain p-2">
                        <div class="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                    `;
                    grid.appendChild(div);
                });
            })
            .catch(err => {
                console.error(err);
                grid.innerHTML = '<div class="col-span-full text-center text-red-400">Error al cargar galería.</div>';
            });
    }

    function uploadMediaFile(input) {
        if(!input.files || !input.files[0]) return;
        const formData = new FormData();
        formData.append('file', input.files[0]);
        formData.append('_token', '{{ csrf_token() }}'); 

        const btn = document.getElementById('upload-btn-label');
        const originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="ph-bold ph-spinner animate-spin"></i> Subiendo...';
        btn.classList.add('opacity-75', 'cursor-wait');

        fetch(mediaRoutes.upload, { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
            if(data.success || data.url) loadMediaLibrary();
            else alert('Error: ' + (data.message || 'Desconocido'));
        })
        .catch(err => { console.error(err); alert('Error de conexión.'); })
        .finally(() => {
            btn.innerHTML = originalContent;
            btn.classList.remove('opacity-75', 'cursor-wait');
            input.value = '';
        });
    }

    function selectMediaItem(url) {
        if (mediaContext === 'background') {
            certState.background = url;
        } else if (mediaContext === 'manager_signature') {
            // Update currently selected element
            if (selectedElementId) {
                const idx = certState.elements.findIndex(e => e.id === selectedElementId);
                if (idx > -1) {
                    // Ensure content object exists
                    if(!certState.elements[idx].content) certState.elements[idx].content = {};
                    certState.elements[idx].content.signature_img = url;
                }
            }
        } else {
            const id = 'el_' + Date.now();
            const newEl = { 
                id, 
                type: 'image', 
                x: 400, 
                y: 300, 
                style: { width: '150px', height: '150px' }, 
                src: url, 
                content: {} 
            };
            certState.elements.push(newEl);
            selectElement(id);
        }
        renderCanvas();
        closeMediaManager();
        document.getElementById('certificate_data_input').value = JSON.stringify(certState);
    }

    // --- FUNCIONES EDITOR ---

    function fixUrl(url) {
        if (!url || url.startsWith('data:')) return url;
        if (url.includes('/storage/')) {
            const parts = url.split('/storage/');
            return "{{ asset('storage') }}/" + parts[1];
        }
        if (url.startsWith('http')) return url;
        return "{{ asset('storage') }}/" + url.replace(/^\//, '');
    }

    function renderCanvas() {
        const bgImg = document.getElementById('cert-background');
        const placeholder = document.getElementById('cert-background-placeholder');
        const layer = document.getElementById('elements-layer');

        if (certState.background) {
            bgImg.src = certState.background;
            bgImg.classList.remove('hidden');
            placeholder.classList.add('hidden');
        } else {
            bgImg.classList.add('hidden');
            placeholder.classList.remove('hidden');
        }

        layer.innerHTML = '';

        certState.elements.forEach(el => {
            const div = document.createElement('div');
            div.id = el.id;
            div.className = `cert-element ${selectedElementId === el.id ? 'selected' : ''}`;
            
            div.style.left = el.x + 'px';
            div.style.top = el.y + 'px';
            
            if (el.style) {
                div.style.fontFamily = getFontFamily(el.style.fontFamily);
                div.style.fontSize = el.style.fontSize;
                div.style.color = el.style.color;
                div.style.fontWeight = el.style.fontWeight;
                if (el.style.textAlign === 'center') div.style.alignItems = 'center';
                else if (el.style.textAlign === 'right') div.style.alignItems = 'flex-end';
                else div.style.alignItems = 'flex-start';

                if (el.style.width && el.style.width !== 'auto') {
                    div.style.width = el.style.width;
                    div.style.whiteSpace = 'normal';
                    div.style.justifyContent = 'center'; 
                    if(el.style.height) div.style.height = el.style.height;
                } else {
                    div.style.width = 'auto';
                    div.style.whiteSpace = 'nowrap';
                }
            }

            div.onmousedown = (e) => startDrag(e, el.id);

            let html = '';
            
            if (el.type === 'student_name') html = window.courseMeta.studentExample;
            else if (el.type === 'course_title') {
                // NUEVO: Usar contenido si es string, sino título por defecto
                html = (typeof el.content === 'string' && el.content) ? el.content : window.courseMeta.title;
            }
            else if (el.type === 'text') {
                html = (typeof el.content === 'string' && el.content) ? el.content : 'Texto';
            }
            
            else if (el.type === 'qr') {
                html = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=PREVIEW" style="display:block;">`;
                if(!el.style.width || el.style.width === 'auto') { 
                    el.style.width = '120px'; el.style.height = '120px'; 
                    div.style.width = '120px'; div.style.height = '120px';
                }
            }
            
            else if (el.type === 'signature' || el.type === 'manager_signature') {
                if (!el.style.width || el.style.width === 'auto') {
                    div.style.width = 'auto'; 
                    div.style.whiteSpace = 'nowrap';
                } else {
                    div.style.width = el.style.width;
                    if(el.style.height) div.style.height = el.style.height;
                    div.style.whiteSpace = 'normal';
                }
                
                div.style.justifyContent = 'flex-end'; 
                div.style.alignItems = 'center'; 
                
                let sigUrl = null;
                if (el.type === 'signature') sigUrl = window.courseMeta.instructor.signature;
                else if (el.content?.signature_img) sigUrl = fixUrl(el.content.signature_img);

                const size = el.content.size || 100;
                const imgHtml = sigUrl 
                    ? `<img src="${sigUrl}" style="height:${size}px; max-width:200px; object-fit:contain; margin-bottom:0;">`
                    : `<div style="height:${size}px; width:100px; border:1px dashed #ccc; display:flex; align-items:center; justify-content:center; font-size:10px; color:#aaa;">Firma</div>`;

                const ns = el.content.nameStyle || {};
                const rs = el.content.roleStyle || {};
                const dName = (el.type === 'signature') ? window.courseMeta.instructor.name : (el.content.name || 'Nombre');
                const dRole = el.content.role || 'Cargo';

                const nsStr = `font-family:${getFontFamily(ns.fontFamily)}; font-size:${ns.fontSize}; color:${ns.color}; font-weight:${ns.fontWeight}; margin-top:4px; line-height:1.2; text-align:center;`;
                const rsStr = `font-family:${getFontFamily(rs.fontFamily)}; font-size:${rs.fontSize}; color:${rs.color}; line-height:1.2; text-align:center;`;

                html = `
                    ${imgHtml}
                    <div style="border-top:1px solid ${ns.color}; width:100%; height:0; margin:2px 0;"></div>
                    <div style="${nsStr}">${dName}</div>
                    <div style="${rsStr}">${dRole}</div>
                `;
            }
            else if (['image', 'seal'].includes(el.type)) {
                const src = fixUrl(el.src);
                html = `<img src="${src}" style="object-fit:contain;">`;
            }

            div.innerHTML = html;

            if (selectedElementId === el.id) {
                const handles = ['nw', 'ne', 'sw', 'se'];
                handles.forEach(h => {
                    const handle = document.createElement('div');
                    handle.className = `resize-handle handle-${h}`;
                    handle.onmousedown = (e) => { e.stopPropagation(); startResize(e, h, el.id); };
                    div.appendChild(handle);
                });
            }

            layer.appendChild(div);
        });

        document.getElementById('certificate_data_input').value = JSON.stringify(certState);
    }

    // --- LÓGICA DE REDIMENSIÓN ---
    function startResize(e, handle, id) {
        e.preventDefault();
        isResizing = true;
        
        const el = certState.elements.find(x => x.id === id);
        const div = document.getElementById(id);
        
        resizeData = {
            handle: handle,
            startX: e.clientX,
            startY: e.clientY,
            startW: div.offsetWidth,
            startH: div.offsetHeight,
            el: el
        };

        document.addEventListener('mousemove', onDragMove);
        document.addEventListener('mouseup', onDragEnd);
    }

    function startDrag(e, id) {
        e.preventDefault(); e.stopPropagation();
        selectElement(id); // Asegura seleccionar al hacer clic
        dragElId = id;
        isDragging = true;
        const el = document.getElementById(id);
        dragOffset.mouseX = e.clientX;
        dragOffset.mouseY = e.clientY;
        dragOffset.elX = parseFloat(el.style.left);
        dragOffset.elY = parseFloat(el.style.top);
        document.addEventListener('mousemove', onDragMove);
        document.addEventListener('mouseup', onDragEnd);
    }

    function onDragMove(e) {
        if (isResizing) {
            const deltaX = (e.clientX - resizeData.startX) / currentZoom;
            const deltaY = (e.clientY - resizeData.startY) / currentZoom;
            
            let newW = resizeData.startW;
            let newH = resizeData.startH;

            if (resizeData.handle.includes('e')) newW = resizeData.startW + deltaX;
            if (resizeData.handle.includes('s')) newH = resizeData.startH + deltaY;
            if (resizeData.handle.includes('w')) newW = resizeData.startW - deltaX;
            if (resizeData.handle.includes('n')) newH = resizeData.startH - deltaY;
            
            if (newW < 20) newW = 20;
            if (newH < 20) newH = 20;

            resizeData.el.style.width = newW + 'px';
            resizeData.el.style.height = newH + 'px';
            
            const div = document.getElementById(resizeData.el.id);
            div.style.width = newW + 'px';
            div.style.height = newH + 'px';
            
            // Actualizar input de ancho si está visible
            if(document.getElementById('prop-width')) document.getElementById('prop-width').value = Math.round(newW);
            
            return;
        }

        if (!isDragging) return;
        const deltaX = e.clientX - dragOffset.mouseX;
        const deltaY = e.clientY - dragOffset.mouseY;
        const moveX = deltaX / currentZoom;
        const moveY = deltaY / currentZoom;
        let nx = dragOffset.elX + moveX;
        let ny = dragOffset.elY + moveY;
        
        const el = document.getElementById(dragElId);
        el.style.left = nx + 'px';
        el.style.top = ny + 'px';

        const idx = certState.elements.findIndex(x => x.id === dragElId);
        if (idx > -1) { certState.elements[idx].x = nx; certState.elements[idx].y = ny; }
    }

    function onDragEnd() {
        isDragging = false;
        isResizing = false;
        document.removeEventListener('mousemove', onDragMove);
        document.removeEventListener('mouseup', onDragEnd);
        document.getElementById('certificate_data_input').value = JSON.stringify(certState);
        renderCanvas(); 
    }

    function addElement(type) {
        const id = 'el_' + Date.now();
        let style = { fontSize: '18px', color: '#000000', fontFamily: 'font-lato', fontWeight: 'normal', textAlign: 'left', width: 'auto' };
        
        if (type === 'student_name') { style.fontSize = '30px'; style.textAlign = 'center'; }
        if (type === 'course_title') { style.fontSize = '25px'; style.fontWeight = 'bold'; style.textAlign = 'center'; }
        
        if (type === 'qr') { style.width = '120px'; style.height = '120px'; }
        
        if (type === 'signature' || type === 'manager_signature') style.width = 'auto';

        // NUEVO: Inicializar con contenido para que sea editable de inmediato
        let initialContent = {};
        if (type === 'course_title') initialContent = window.courseMeta.title;
        if (type === 'text') initialContent = 'Texto';

        const newEl = { id, type, x: 450, y: 300, style, content: initialContent };
        
        if (type === 'signature' || type === 'manager_signature') {
            newEl.content = { 
                size: 100,
                name: type === 'signature' ? window.courseMeta.instructor.name : window.courseMeta.manager.name,
                role: type === 'signature' ? window.courseMeta.instructor.role : window.courseMeta.manager.role,
                nameStyle: { fontSize: '18px', color: '#000000', fontFamily: 'font-lato', fontWeight: 'bold' },
                roleStyle: { fontSize: '14px', color: '#555555', fontFamily: 'font-lato', fontWeight: 'normal' }
            };
        }

        certState.elements.push(newEl);
        selectElement(id); // Seleccionar automáticamente al crear
    }

    function removeSelectedElement() {
        if(selectedElementId) {
            certState.elements = certState.elements.filter(e => e.id !== selectedElementId);
            selectedElementId = null;
            renderCanvas();
            showAddPanel();
        }
    }

    // Helper DOM
    function setValue(id, v) { const el = document.getElementById(id); if(el) el.value = v; }
    function toggleBtnClass(id, active) { 
        const el = document.getElementById(id);
        if(el) {
            if(active) { el.classList.add('bg-blue-100', 'text-blue-700', 'border-blue-300'); el.classList.remove('bg-white', 'text-gray-600', 'border-gray-300'); }
            else { el.classList.remove('bg-blue-100', 'text-blue-700', 'border-blue-300'); el.classList.add('bg-white', 'text-gray-600', 'border-gray-300'); }
        }
    }

    function zoomCanvas(delta) {
        currentZoom += delta;
        if (currentZoom < 0.2) currentZoom = 0.2;
        if (currentZoom > 2) currentZoom = 2;
        applyZoom();
    }

    function fitCanvas() {
        const container = document.getElementById('scroll-area');
        const availableW = container.clientWidth - 80; 
        const scale = Math.min(1, availableW / 1123);
        currentZoom = scale;
        applyZoom();
    }

    function applyZoom() {
        const canvas = document.getElementById('cert-canvas');
        canvas.style.transform = `scale(${currentZoom})`;
        document.getElementById('zoom-level-indicator').innerText = Math.round(currentZoom * 100) + '%';
    }

    function getFontFamily(k) {
        const f = {
            'font-lato': "'Lato', sans-serif",
            'font-merriweather': "'Merriweather', serif",
            'font-pinyon': "'Pinyon Script', cursive",
            'font-greatvibes': "'Great Vibes', cursive",
            'font-montserrat': "'Montserrat', sans-serif",
            'font-opensans': "'Open Sans', sans-serif"
        };
        return f[k] || 'sans-serif';
    }
</script>