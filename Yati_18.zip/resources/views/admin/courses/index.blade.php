<x-layouts.admin>
    <x-slot name="title">Cursos - Gestión</x-slot>
    <x-slot name="header">Gestión de Cursos</x-slot>

    <!-- MENSAJES FLASH -->
    @if(session('success'))
        <div class="mb-6 p-4 rounded-xl bg-green-50 border border-green-200 text-green-700 flex items-center gap-2 animate-bounce-in">
            <i class="ph-bold ph-check-circle text-xl"></i>
            {{ session('success') }}
        </div>
    @endif

    <!-- BARRA DE HERRAMIENTAS -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up" style="animation-delay: 0.1s">
        
        <!-- Buscador y Filtros -->
        <div class="flex gap-3 w-full md:w-auto">
            <div class="relative w-full md:w-80">
                <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" placeholder="Buscar curso, instructor..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
            </div>
            <select class="px-4 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-600 text-sm focus:border-[#0AD1C8] outline-none cursor-pointer">
                <option>Todas las Categorías</option>
            </select>
            <select class="px-4 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-600 text-sm focus:border-[#0AD1C8] outline-none cursor-pointer">
                <option>Estado</option>
                <option>Publicado</option>
                <option>Borrador</option>
            </select>
        </div>

        <!-- Botones de Acción Global -->
        <div class="flex gap-3">
            <button class="flex items-center gap-2 px-4 py-2.5 bg-white border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-colors text-sm font-medium">
                <i class="ph-bold ph-export"></i> Reporte
            </button>
            
            <!-- PROTECCIÓN: CREAR CURSO -->
            @if(Auth::user()->hasPermission('courses.create'))
            <a href="{{ route('admin.courses.create') }}" class="flex items-center gap-2 px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm font-bold">
                <i class="ph-bold ph-plus"></i> Crear Curso
            </a>
            @endif
        </div>
    </div>

    <!-- TABLA DE CURSOS -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.2s">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/50 text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 w-16 text-center">#</th>
                        <th class="px-6 py-4">Curso</th>
                        <th class="px-6 py-4">Instructor</th>
                        <th class="px-6 py-4">Categoría / Estado</th>
                        <th class="px-6 py-4 text-center">Inscritos</th>
                        <th class="px-6 py-4">Precio</th>
                        <th class="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    
                    @forelse($courses as $course)
                    <tr class="hover:bg-[#F0FDFD] transition-colors group">
                        <!-- NUMERACIÓN -->
                        <td class="px-6 py-4 text-center font-bold text-gray-400">
                            {{ $loop->iteration + ($courses->currentPage() - 1) * $courses->perPage() }}
                        </td>

                        <!-- CURSO -->
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-16 h-12 rounded-lg bg-gray-200 overflow-hidden shrink-0 border border-gray-100 relative">
                                    @if($course->cover_image)
                                        <img src="{{ asset($course->cover_image) }}" class="w-full h-full object-cover">
                                    @else
                                        <div class="w-full h-full flex items-center justify-center bg-gray-100 text-gray-400">
                                            <i class="ph-bold ph-image text-xl"></i>
                                        </div>
                                    @endif
                                </div>
                                <div class="max-w-[200px]">
                                    <p class="font-bold text-[#213A57] line-clamp-1" title="{{ $course->title }}">{{ $course->title }}</p>
                                    <p class="text-[10px] text-gray-500 uppercase tracking-wide">{{ $course->level }}</p>
                                </div>
                            </div>
                        </td>
                        
                        <!-- INSTRUCTOR -->
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                @if($course->instructor)
                                    <img src="{{ $course->instructor->avatar_url ? asset($course->instructor->avatar_url) : 'https://ui-avatars.com/api/?name='.urlencode($course->instructor->name).'&background=random' }}" class="w-6 h-6 rounded-full border border-gray-100 object-cover">
                                    <span class="text-gray-600 font-medium text-xs">{{ $course->instructor->name }}</span>
                                @else
                                    <div class="w-6 h-6 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center">
                                        <i class="ph-bold ph-user-minus text-xs text-gray-400"></i>
                                    </div>
                                    <span class="text-gray-400 font-medium text-xs italic">Sin Asignar</span>
                                @endif
                            </div>
                        </td>

                        <!-- CATEGORÍA / ESTADO -->
                        <td class="px-6 py-4">
                            <div class="space-y-2">
                                <div class="flex flex-wrap gap-1">
                                    @forelse($course->categories as $cat)
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#E0F9F6] text-[#0B6477] border border-[#0AD1C8]/20">
                                            <i class="ph-bold {{ $cat->icon ?? 'ph-tag' }}"></i> {{ $cat->name }}
                                        </span>
                                    @empty
                                        <span class="text-[10px] text-gray-400 italic">Sin Categoría</span>
                                    @endforelse
                                </div>
                                <div class="flex items-center gap-1.5 text-xs">
                                    <span class="w-2 h-2 rounded-full {{ $course->status === 'published' ? 'bg-green-500' : 'bg-amber-400' }}"></span>
                                    <span class="font-medium {{ $course->status === 'published' ? 'text-green-600' : 'text-amber-600' }} capitalize">
                                        {{ $course->status === 'published' ? 'Publicado' : 'Borrador' }}
                                    </span>
                                </div>
                            </div>
                        </td>

                        <!-- ESTUDIANTES (CONTEO REAL) -->
                        <td class="px-6 py-4 text-center">
                            <div class="inline-flex flex-col items-center">
                                <span class="font-bold text-[#213A57] text-base">{{ $course->enrollments_count }}</span>
                                <span class="text-[10px] text-gray-400">Inscritos</span>
                            </div>
                        </td>

                        <!-- PRECIO (MODIFICADO PARA MOSTRAR DESCUENTO) -->
                        <td class="px-6 py-4">
                            @if($course->discount_price > 0 && $course->discount_price < $course->price)
                                <div class="flex flex-col">
                                    <span class="font-bold text-[#0AD1C8]">Bs {{ number_format($course->discount_price, 2) }}</span>
                                    <span class="text-xs text-gray-400 line-through">Bs {{ number_format($course->price, 2) }}</span>
                                </div>
                            @else
                                <span class="font-bold text-[#213A57]">Bs {{ number_format($course->price, 2) }}</span>
                            @endif
                        </td>

                        <!-- ACCIONES -->
                        <td class="px-6 py-4 text-right">
                            <div class="flex items-center justify-end gap-1">
                                <!-- Botón VER (Modal) -->
                                <button type="button" onclick="showCourseDetails({{ $course->id }})" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-[#0AD1C8] hover:bg-[#E0F9F6] transition-colors" title="Ver Detalles">
                                    <i class="ph-bold ph-eye text-lg"></i>
                                </button>
                                
                                <!-- Botón CALIFICAR (Modal de Trabajos) -->
                                @if(Auth::user()->hasPermission('courses.grade'))
                                <button type="button" onclick="showGradeModal({{ $course->id }})" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-purple-500 hover:bg-purple-50 transition-colors relative" title="Revisar Trabajos">
                                    <i class="ph-bold ph-list-checks text-lg"></i>
                                    @if($course->pending_projects_count > 0)
                                        <span class="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
                                    @endif
                                </button>
                                @endif

                                @if(Auth::user()->hasPermission('courses.create'))
                                <a href="{{ route('admin.courses.edit', $course->id) }}" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-amber-500 hover:bg-amber-50 transition-colors" title="Editar">
                                    <i class="ph-bold ph-pencil-simple text-lg"></i>
                                </a>
                                
                                <form action="{{ route('admin.courses.destroy', $course->id) }}" method="POST" onsubmit="return confirm('¿Eliminar curso?');" style="display:inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Eliminar">
                                        <i class="ph-bold ph-trash text-lg"></i>
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="px-6 py-12 text-center text-gray-400">
                            <div class="flex flex-col items-center justify-center">
                                <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                                    <i class="ph-duotone ph-books text-3xl text-gray-400"></i>
                                </div>
                                <h3 class="text-lg font-bold text-gray-600">No hay cursos creados</h3>
                                <p class="text-sm text-gray-400 mb-6">Comienza creando tu primer curso ahora mismo.</p>
                                @if(Auth::user()->hasPermission('courses.create'))
                                <a href="{{ route('admin.courses.create') }}" class="px-6 py-2 bg-[#213A57] text-white rounded-lg font-bold hover:bg-[#0B6477] transition-all text-sm">Crear mi primer curso</a>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @endforelse

                </tbody>
            </table>
        </div>
        
        <!-- PAGINACIÓN -->
        <div class="p-4 border-t border-gray-100">
            {{ $courses->links() }}
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MODAL DETALLES DEL CURSO (SOLO LECTURA)       -->
    <!-- ============================================= -->
    <div id="course-details-modal" class="fixed inset-0 z-[100] hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/80 backdrop-blur-sm transition-opacity" onclick="closeDetailsModal()"></div>
        <div class="fixed inset-0 z-[110] w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all w-full max-w-2xl border border-white/10 flex flex-col">
                    <div class="relative h-40 bg-gray-100">
                        <img id="modal-cover" src="" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
                            <h3 id="modal-title" class="text-xl font-bold text-white shadow-sm">Titulo del Curso</h3>
                        </div>
                        <button onclick="closeDetailsModal()" class="absolute top-4 right-4 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 transition-colors">
                            <i class="ph-bold ph-x"></i>
                        </button>
                    </div>
                    <div class="p-6 space-y-4">
                        <div class="flex justify-between items-center text-sm text-gray-500 border-b border-gray-100 pb-4">
                            <span class="flex items-center gap-1"><i class="ph-bold ph-user"></i> <span id="modal-instructor"></span></span>
                            <span class="flex items-center gap-1"><i class="ph-bold ph-users"></i> <span id="modal-students"></span> Estudiantes</span>
                            <span class="font-bold text-[#0AD1C8] text-lg">Bs <span id="modal-price"></span></span>
                        </div>
                        <p id="modal-desc" class="text-sm text-gray-600 leading-relaxed"></p>
                        <div class="grid grid-cols-2 gap-4 pt-2">
                            <div class="p-3 bg-gray-50 rounded-lg text-center">
                                <span class="block text-xl font-bold text-[#213A57]" id="modal-modules">0</span>
                                <span class="text-[10px] text-gray-400 uppercase font-bold">Módulos</span>
                            </div>
                            <div class="p-3 bg-gray-50 rounded-lg text-center">
                                <span class="block text-xl font-bold text-[#213A57]" id="modal-lessons">0</span>
                                <span class="text-[10px] text-gray-400 uppercase font-bold">Clases</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================= -->
    <!-- MODAL DE CALIFICACIÓN DE TRABAJOS (TABLA)     -->
    <!-- ============================================= -->
    <div id="grading-modal" class="fixed inset-0 z-[100] hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeGradingModal()"></div>
        <div class="fixed inset-0 z-[110] w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all w-full max-w-6xl border border-white/10 flex flex-col max-h-[85vh]">
                    
                    <div class="bg-purple-600 px-6 py-4 flex justify-between items-center shrink-0">
                        <div>
                            <h3 class="text-lg font-bold text-white"><i class="ph-bold ph-checks"></i> Revisión de Trabajos</h3>
                            <p class="text-purple-200 text-xs">Lista de proyectos finales entregados.</p>
                        </div>
                        <button onclick="closeGradingModal()" class="text-white hover:bg-white/20 p-2 rounded-full"><i class="ph-bold ph-x text-xl"></i></button>
                    </div>

                    <div class="flex-1 overflow-y-auto p-6 bg-gray-50" id="submissions-container">
                        <!-- Aquí se inyecta la tabla de trabajos via JS -->
                        <div class="text-center py-12 text-gray-400">
                            <i class="ph-duotone ph-spinner-gap text-4xl animate-spin mb-2"></i>
                            <p>Cargando trabajos...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SCRIPTS PARA MODALES Y AJAX -->
    <script>
        // --- DETALLES DEL CURSO ---
        function showCourseDetails(id) {
            // Petición AJAX para obtener datos
            fetch(`/admin/cursos/${id}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('modal-title').innerText = data.title;
                    document.getElementById('modal-cover').src = data.cover || 'https://via.placeholder.com/800x400?text=No+Cover';
                    document.getElementById('modal-instructor').innerText = data.instructor;
                    document.getElementById('modal-students').innerText = data.students_count;
                    document.getElementById('modal-price').innerText = data.price;
                    document.getElementById('modal-desc').innerText = data.description;
                    document.getElementById('modal-modules').innerText = data.modules_count;
                    document.getElementById('modal-lessons').innerText = data.lessons_count;
                    
                    document.getElementById('course-details-modal').classList.remove('hidden');
                });
        }

        function closeDetailsModal() {
            document.getElementById('course-details-modal').classList.add('hidden');
        }

        // --- CALIFICACIÓN DE TRABAJOS ---
        function showGradeModal(courseId) {
            document.getElementById('grading-modal').classList.remove('hidden');
            loadSubmissions(courseId);
        }

        function closeGradingModal() {
            document.getElementById('grading-modal').classList.add('hidden');
        }

        function loadSubmissions(courseId) {
            const container = document.getElementById('submissions-container');
            container.innerHTML = '<div class="text-center py-12 text-gray-400"><i class="ph-duotone ph-spinner-gap text-4xl animate-spin mb-2"></i><p>Cargando...</p></div>';

            fetch(`/admin/cursos/${courseId}/trabajos`)
                .then(res => res.json())
                .then(data => {
                    if(data.length === 0) {
                        container.innerHTML = '<div class="text-center py-12 text-gray-400 bg-white rounded-xl border border-dashed border-gray-300"><i class="ph-duotone ph-folder-open text-4xl mb-2"></i><p>No hay trabajos entregados aún.</p></div>';
                        return;
                    }

                    // CONSTRUCCIÓN DE LA TABLA
                    let html = `
                        <div class="overflow-x-auto rounded-xl border border-gray-200 shadow-sm bg-white">
                            <table class="w-full text-sm text-left">
                                <thead class="bg-gray-50 text-gray-500 font-bold uppercase text-[10px] tracking-wider border-b border-gray-200">
                                    <tr>
                                        <th class="px-6 py-4">Estudiante</th>
                                        <th class="px-6 py-4">Archivos</th>
                                        <th class="px-6 py-4 text-center">Estado</th>
                                        <th class="px-6 py-4 w-[350px]">Calificación y Feedback</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100 bg-white">
                    `;

                    data.forEach(sub => {
                        const statusColor = sub.status === 'approved' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-amber-100 text-amber-700 border border-amber-200';
                        const statusText = sub.status === 'approved' ? 'Calificado' : 'Pendiente';
                        
                        let filesHtml = '';
                        sub.files.forEach((f, idx) => {
                            const name = f.split('/').pop(); 
                            const url = sub.file_urls[idx];
                            filesHtml += `
                                <a href="${url}" target="_blank" class="flex items-center gap-2 text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors py-1">
                                    <i class="ph-bold ph-file-arrow-down text-lg"></i>
                                    <span class="truncate max-w-[150px]" title="${name}">${name}</span>
                                </a>
                            `;
                        });

                        html += `
                            <tr class="hover:bg-gray-50/80 transition-colors">
                                <td class="px-6 py-4 align-top">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center font-bold text-purple-600 text-sm border border-purple-200">
                                            ${sub.student_name.charAt(0)}
                                        </div>
                                        <div>
                                            <div class="font-bold text-[#213A57]">${sub.student_name}</div>
                                            <div class="text-xs text-gray-400">${sub.student_email}</div>
                                            <div class="text-[10px] text-gray-400 mt-1 flex items-center gap-1">
                                                <i class="ph-bold ph-calendar-blank"></i> ${sub.date}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 align-top">
                                    <div class="flex flex-col gap-1">
                                        ${filesHtml}
                                    </div>
                                </td>
                                <td class="px-6 py-4 align-top text-center">
                                    <span class="inline-flex items-center px-2.5 py-1 text-[10px] uppercase font-bold rounded-full ${statusColor}">
                                        ${statusText}
                                    </span>
                                </td>
                                <td class="px-6 py-4 align-top">
                                    <form onsubmit="submitGrade(event, ${sub.id})" class="flex flex-col gap-3">
                                        <div class="flex gap-2">
                                            <div class="w-24 relative">
                                                <input type="number" name="score" value="${sub.score || ''}" min="0" max="100" placeholder="0-100" class="w-full px-3 py-2 rounded-lg border border-gray-300 text-sm focus:border-purple-500 outline-none font-bold text-purple-700 text-center" required>
                                                <span class="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-gray-400 font-bold pointer-events-none">PTS</span>
                                            </div>
                                            <button type="submit" class="flex-1 px-4 py-2 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700 transition-colors shadow-md shadow-purple-500/20">
                                                Guardar Nota
                                            </button>
                                        </div>
                                        <textarea name="feedback" rows="2" class="w-full px-3 py-2 rounded-lg border border-gray-300 text-xs focus:border-purple-500 outline-none resize-none bg-gray-50 focus:bg-white transition-colors" placeholder="Escribe un comentario o feedback para el estudiante...">${sub.feedback || ''}</textarea>
                                    </form>
                                </td>
                            </tr>
                        `;
                    });

                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;
                    container.innerHTML = html;
                });
        }

        function submitGrade(e, subId) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            const btn = form.querySelector('button');
            const originalText = btn.innerText;
            
            btn.innerText = '...';
            btn.disabled = true;
            btn.classList.add('opacity-70', 'cursor-not-allowed');

            fetch(`/admin/trabajos/${subId}/calificar`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(Object.fromEntries(formData))
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    // Feedback visual sutil sin alerta intrusiva
                    const row = form.closest('tr');
                    const badge = row.querySelector('td:nth-child(3) span');
                    
                    // Actualizar badge visualmente
                    badge.className = 'inline-flex items-center px-2.5 py-1 text-[10px] uppercase font-bold rounded-full bg-green-100 text-green-700 border border-green-200';
                    badge.innerText = 'Calificado';
                    
                    // Mostrar toast temporal
                    btn.innerText = '¡Guardado!';
                    btn.classList.remove('bg-purple-600', 'hover:bg-purple-700');
                    btn.classList.add('bg-green-600', 'hover:bg-green-700');
                    
                    setTimeout(() => {
                        btn.innerText = 'Guardar Nota';
                        btn.disabled = false;
                        btn.classList.remove('opacity-70', 'cursor-not-allowed', 'bg-green-600', 'hover:bg-green-700');
                        btn.classList.add('bg-purple-600', 'hover:bg-purple-700');
                    }, 2000);
                } else {
                    alert('Error al guardar: ' + data.message);
                    btn.innerText = originalText;
                    btn.disabled = false;
                    btn.classList.remove('opacity-70', 'cursor-not-allowed');
                }
            })
            .catch(err => {
                console.error(err);
                alert('Error de conexión');
                btn.innerText = originalText;
                btn.disabled = false;
                btn.classList.remove('opacity-70', 'cursor-not-allowed');
            });
        }
    </script>
</x-layouts.admin>