<x-layouts.admin>
    <x-slot name="title">Gestión de Docentes</x-slot>
    <x-slot name="header">Docentes</x-slot>

    <!-- Header Actions -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <div class="relative w-full md:w-72">
            <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="text" placeholder="Buscar docente..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm transition-all">
        </div>
        
        <!-- PROTECCIÓN: CREAR DOCENTE -->
        @if(Auth::user()->hasPermission('instructors.manage'))
        <button onclick="openModal()" class="w-full md:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm font-bold">
            <i class="ph-bold ph-plus"></i> Nuevo Docente
        </button>
        @endif
    </div>

    <!-- Lista de Docentes -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 fade-in-up" style="animation-delay: 0.1s">
        @forelse($instructors as $instructor)
        <div class="bg-white rounded-2xl border border-gray-100 p-6 hover:shadow-md transition-shadow group relative flex flex-col h-full">
            
            <!-- Acciones Flotantes (Solo si tiene permiso de gestión) -->
            @if(Auth::user()->hasPermission('instructors.manage'))
            <div class="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <button onclick="editModal({{ json_encode($instructor) }})" class="p-2 bg-white/90 backdrop-blur rounded-lg text-gray-600 hover:text-[#0AD1C8] shadow-sm border border-gray-100"><i class="ph-bold ph-pencil-simple"></i></button>
                <form action="{{ route('admin.instructors.destroy', $instructor->id) }}" method="POST" onsubmit="return confirm('¿Eliminar docente?');">
                    @csrf @method('DELETE')
                    <button type="submit" class="p-2 bg-white/90 backdrop-blur rounded-lg text-gray-600 hover:text-red-500 shadow-sm border border-gray-100"><i class="ph-bold ph-trash"></i></button>
                </form>
            </div>
            @endif

            <div class="flex flex-col items-center text-center mb-4">
                <div class="relative mb-4">
                    <img src="{{ $instructor->avatar_url ? asset($instructor->avatar_url) : 'https://ui-avatars.com/api/?name='.urlencode($instructor->name).'&background=random&size=128' }}" 
                         class="w-24 h-24 rounded-full object-cover border-4 border-gray-50 shadow-sm">
                    <span class="absolute bottom-1 right-1 w-4 h-4 rounded-full border-2 border-white {{ $instructor->status === 'active' ? 'bg-green-500' : 'bg-gray-400' }}"></span>
                </div>
                
                <h3 class="font-bold text-[#213A57] text-lg leading-tight mb-1">{{ $instructor->name }}</h3>
                <p class="text-[#0AD1C8] text-xs font-bold uppercase tracking-wider mb-3">{{ $instructor->specialty ?? 'General' }}</p>
                
                <div class="flex items-center gap-4 text-xs text-gray-500 mb-4">
                    <span class="flex items-center gap-1"><i class="ph-bold ph-envelope"></i> {{ $instructor->email }}</span>
                </div>

                <!-- Indicador de Firma -->
                @if($instructor->signature_url)
                    <div class="mb-3 px-3 py-1 bg-green-50 text-green-700 text-[10px] font-bold rounded-full border border-green-100 flex items-center gap-1">
                        <i class="ph-bold ph-pen-nib"></i> Firma Digital Activa
                    </div>
                @endif

                <p class="text-sm text-gray-500 line-clamp-2 leading-relaxed">{{ $instructor->bio ?? 'Sin biografía.' }}</p>
            </div>
            
            <div class="mt-auto pt-4 border-t border-gray-100 flex justify-between items-center text-xs text-gray-400">
                <span class="bg-gray-100 px-2 py-1 rounded-md text-gray-600"><i class="ph-bold ph-chalkboard-teacher"></i> {{ $instructor->courses_count ?? 0 }} Cursos</span>
                <span>Reg: {{ $instructor->created_at->format('d M, Y') }}</span>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-16 bg-white rounded-3xl border border-gray-100 border-dashed">
            <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <i class="ph-duotone ph-users text-4xl text-gray-300"></i>
            </div>
            <h3 class="text-lg font-bold text-gray-600">No hay docentes registrados</h3>
            <p class="text-sm text-gray-400 mb-6">Comienza agregando al primer instructor de la plataforma.</p>
            
            @if(Auth::user()->hasPermission('instructors.manage'))
            <button onclick="openModal()" class="px-6 py-2 bg-[#213A57] text-white rounded-lg font-bold hover:bg-[#0B6477] transition-all text-sm">
                Crear Docente
            </button>
            @endif
        </div>
        @endforelse
    </div>

    <!-- Paginación -->
    <div class="mt-8">
        {{ $instructors->links() }}
    </div>

    <!-- MODAL (CREAR / EDITAR) -->
    <div id="instructor-modal" class="fixed inset-0 z-50 hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/80 backdrop-blur-sm transition-opacity" onclick="closeModal()"></div>
        
        <div class="fixed inset-0 z-10 overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4 text-center sm:p-0">
                <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-2xl border border-gray-100">
                    
                    <div class="bg-[#F8FAFC] px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="text-lg font-bold text-[#213A57] flex items-center gap-2">
                            <i class="ph-fill ph-user-circle text-[#0AD1C8]"></i> 
                            <span id="modal-title">Nuevo Docente</span>
                        </h3>
                        <button onclick="closeModal()" class="text-gray-400 hover:text-red-500 transition-colors rounded-full p-1 hover:bg-red-50">
                            <i class="ph-bold ph-x text-xl"></i>
                        </button>
                    </div>

                    <form id="instructor-form" method="POST" enctype="multipart/form-data" action="{{ route('admin.instructors.store') }}">
                        @csrf
                        <input type="hidden" name="_method" id="form-method" value="POST">
                        
                        <div class="p-6 space-y-6 max-h-[75vh] overflow-y-auto custom-scrollbar">
                            
                            <!-- Sección Personal -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="col-span-2">
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Nombre Completo <span class="text-red-500">*</span></label>
                                    <input type="text" name="name" id="input_name" required 
                                           class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm font-medium text-[#213A57]">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Correo Electrónico <span class="text-red-500">*</span></label>
                                    <input type="email" name="email" id="input_email" required 
                                           class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Contraseña <span id="pass-required" class="text-red-500">*</span></label>
                                    <input type="password" name="password" id="input_password" 
                                           class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm"
                                           placeholder="Mínimo 8 caracteres">
                                    <p class="text-[10px] text-gray-400 mt-1 hidden" id="pass-hint">Dejar vacío para mantener la actual.</p>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Teléfono</label>
                                    <input type="text" name="phone" id="input_phone" 
                                           class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Especialidad</label>
                                    <input type="text" name="specialty" id="input_specialty" placeholder="Ej: Ing. Industrial"
                                           class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
                                </div>
                            </div>

                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Biografía</label>
                                <textarea name="bio" id="input_bio" rows="3"
                                          class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm resize-none placeholder-gray-400"></textarea>
                            </div>

                            <!-- Sección Certificados -->
                            <div class="bg-blue-50 rounded-xl p-5 border border-blue-100">
                                <h4 class="text-sm font-bold text-[#213A57] mb-4 flex items-center gap-2">
                                    <i class="ph-bold ph-certificate text-[#0AD1C8]"></i> Datos para Certificados
                                </h4>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div class="col-span-2">
                                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Mención + Nombre</label>
                                        <input type="text" name="certificate_name" id="input_certificate_name" placeholder="Ej: Ing. Reynaldo Sirpa"
                                               class="w-full px-4 py-2.5 rounded-xl border border-blue-200 bg-white focus:border-[#0AD1C8] outline-none text-sm">
                                        <p class="text-[10px] text-gray-500 mt-1">Este nombre aparecerá tal cual en la firma del certificado.</p>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Firma Digital (PNG)</label>
                                        <input type="file" name="signature" id="input_signature" accept="image/png" onchange="previewFileSignature(this)" 
                                               class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200 transition-all cursor-pointer">
                                        <p class="text-[10px] text-gray-500 mt-1">Fondo transparente recomendado.</p>
                                    </div>

                                    <div>
                                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Vista Previa Firma</label>
                                        <div class="h-16 border border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50 overflow-hidden relative">
                                            <img id="signature-preview" src="" class="h-full object-contain hidden">
                                            <span id="signature-placeholder" class="text-xs text-gray-400 italic absolute">Sin firma</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Foto y Estado -->
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Fotografía Perfil</label>
                                    <input type="file" name="avatar" class="block w-full text-sm text-gray-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-[#E0F9F6] file:text-[#0B6477] hover:file:bg-[#0AD1C8] hover:file:text-white transition-all cursor-pointer">
                                </div>
                                
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Estado</label>
                                    <select name="status" id="input_status" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-white">
                                        <option value="active">Activo</option>
                                        <option value="inactive">Inactivo</option>
                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="bg-gray-50 px-6 py-4 flex justify-end gap-3 border-t border-gray-200 rounded-b-2xl">
                            <button type="button" onclick="closeModal()" class="px-5 py-2.5 bg-white border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 text-sm font-bold transition-colors">Cancelar</button>
                            <button type="submit" class="px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] text-sm font-bold shadow-lg shadow-[#213A57]/20 transition-all transform hover:-translate-y-0.5">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const modal = document.getElementById('instructor-modal');
        const form = document.getElementById('instructor-form');
        const title = document.getElementById('modal-title');
        const methodInput = document.getElementById('form-method');
        
        const passHint = document.getElementById('pass-hint');
        const passReq = document.getElementById('pass-required');
        const inputPass = document.getElementById('input_password');

        function openModal() {
            form.action = "{{ route('admin.instructors.store') }}";
            methodInput.value = "POST";
            title.innerText = "Nuevo Docente";
            form.reset(); // Limpia inputs incluyendo files
            
            passHint.classList.add('hidden');
            passReq.classList.remove('hidden');
            inputPass.required = true;
            
            // Reset firma explícito por seguridad
            const sigPreview = document.getElementById('signature-preview');
            const sigPlace = document.getElementById('signature-placeholder');
            sigPreview.src = "";
            sigPreview.classList.add('hidden');
            sigPlace.classList.remove('hidden');
            
            modal.classList.remove('hidden');
        }

        function editModal(instructor) {
            let url = "{{ route('admin.instructors.update', ':id') }}";
            form.action = url.replace(':id', instructor.id);
            methodInput.value = "PUT";
            title.innerText = "Editar Docente";
            
            // IMPORTANTE: Resetear form antes de llenar para limpiar archivos previos
            form.reset();

            document.getElementById('input_name').value = instructor.name;
            document.getElementById('input_email').value = instructor.email;
            document.getElementById('input_phone').value = instructor.phone || '';
            document.getElementById('input_specialty').value = instructor.specialty || '';
            document.getElementById('input_bio').value = instructor.bio || '';
            document.getElementById('input_status').value = instructor.status;
            
            document.getElementById('input_certificate_name').value = instructor.certificate_name || '';
            
            // Lógica de Preview Firma
            const sigPreview = document.getElementById('signature-preview');
            const sigPlace = document.getElementById('signature-placeholder');

            if (instructor.signature_url) {
                let sigSrc = instructor.signature_url.startsWith('http') 
                             ? instructor.signature_url 
                             : "{{ asset('') }}" + instructor.signature_url;
                
                sigPreview.src = sigSrc;
                sigPreview.classList.remove('hidden');
                sigPlace.classList.add('hidden');
            } else {
                sigPreview.src = "";
                sigPreview.classList.add('hidden');
                sigPlace.classList.remove('hidden');
            }

            passHint.classList.remove('hidden');
            passReq.classList.add('hidden');
            inputPass.required = false;
            
            modal.classList.remove('hidden');
        }

        function closeModal() {
            modal.classList.add('hidden');
        }

        function previewFileSignature(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('signature-preview');
                    const placeholder = document.getElementById('signature-placeholder');
                    
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                    placeholder.classList.add('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</x-layouts.admin>