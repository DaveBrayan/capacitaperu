<x-layouts.admin>
    <x-slot name="title">Usuarios del Sistema - Gestión</x-slot>
    <x-slot name="header">Usuarios del Sistema</x-slot>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    @if($errors->any())
        <div class="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700">
            <ul class="list-disc list-inside text-sm">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- BARRA DE HERRAMIENTAS -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <div class="relative w-full md:w-96">
            <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="text" placeholder="Buscar usuario..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
        </div>

        @if(Auth::user()->hasPermission('users.create'))
        <button type="button" onclick="openCreateModal()" class="flex items-center gap-2 px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm font-bold group transform hover:-translate-y-0.5">
            <i class="ph-bold ph-user-plus text-lg group-hover:scale-110 transition-transform"></i>
            Nuevo Usuario
        </button>
        @endif
    </div>

    <!-- TABLA DE USUARIOS -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.2s">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/50 text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4">Usuario</th>
                        <th class="px-6 py-4">Rol Base</th>
                        <th class="px-6 py-4">Permisos</th>
                        <th class="px-6 py-4">Estado</th>
                        <th class="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    @forelse($users as $user)
                    <tr class="hover:bg-[#F0FDFD] transition-colors group">
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden border-2 border-transparent group-hover:border-[#0AD1C8] shadow-sm">
                                    @if($user->avatar_url && Str::startsWith($user->avatar_url, 'http'))
                                        <img src="{{ $user->avatar_url }}" class="w-full h-full object-cover">
                                    @elseif($user->avatar_url)
                                        <img src="{{ asset($user->avatar_url) }}" class="w-full h-full object-cover">
                                    @else
                                        <img src="https://ui-avatars.com/api/?name={{ $user->name }}&background=213A57&color=fff" class="w-full h-full object-cover">
                                    @endif
                                </div>
                                <div>
                                    <p class="font-bold text-[#213A57]">{{ $user->name }}</p>
                                    <p class="text-xs text-gray-500">{{ $user->email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            @php
                                $badgeColor = match($user->role) {
                                    'superadmin' => 'bg-[#213A57] text-white',
                                    'admin' => 'bg-purple-100 text-purple-700 border-purple-200',
                                    'moderator' => 'bg-blue-100 text-blue-700 border-blue-200',
                                    default => 'bg-gray-100 text-gray-600'
                                };
                            @endphp
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border {{ $badgeColor }}">
                                {{ ucfirst($user->role) }}
                            </span>
                        </td>
                        <td class="px-6 py-4">
                             <!-- Enlace rápido para configurar permisos -->
                            @if(Auth::user()->hasPermission('users.permissions'))
                            <button onclick="openPermissionsModal({{ $user->id }}, '{{ $user->name }}')" class="text-xs font-bold text-[#0AD1C8] hover:text-[#213A57] hover:underline flex items-center gap-1 transition-colors">
                                <i class="ph-bold ph-sliders-horizontal"></i> Configurar
                            </button>
                            @endif
                        </td>
                        <td class="px-6 py-4">
                            <span class="inline-flex items-center gap-1.5 text-xs font-bold {{ $user->status === 'active' ? 'text-green-600' : 'text-red-500' }}">
                                <span class="w-2 h-2 rounded-full {{ $user->status === 'active' ? 'bg-green-500' : 'bg-red-500' }} animate-pulse"></span> 
                                {{ ucfirst($user->status) }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="flex items-center justify-end gap-1">
                                <!-- BOTÓN GESTIÓN DE PERMISOS -->
                                @if(Auth::user()->hasPermission('users.permissions'))
                                <button type="button" onclick="openPermissionsModal({{ $user->id }}, '{{ $user->name }}')" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-[#213A57] hover:bg-gray-100 transition-colors" title="Gestionar Permisos">
                                    <i class="ph-bold ph-shield-check text-lg"></i>
                                </button>
                                @endif

                                @if(Auth::user()->hasPermission('users.edit'))
                                <button type="button" onclick='openEditModal(@json($user))' class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-amber-500 hover:bg-amber-50 transition-colors" title="Editar">
                                    <i class="ph-bold ph-pencil-simple text-lg"></i>
                                </button>
                                @endif
                                
                                @if(Auth::user()->hasPermission('users.edit'))
                                <form id="form-reset-pass-{{ $user->id }}" action="{{ route('admin.staff.reset_password', $user->id) }}" method="POST" style="display:inline;">
                                    @csrf @method('PUT')
                                    <button type="button" onclick="confirmAction('form-reset-pass-{{ $user->id }}', '¿Restablecer Contraseña?', 'Se generará una nueva contraseña y podrás copiarla.', 'warning')" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-blue-500 hover:bg-blue-50 transition-colors" title="Restablecer Contraseña">
                                        <i class="ph-bold ph-key text-lg"></i>
                                    </button>
                                </form>

                                <form id="form-reset-pin-{{ $user->id }}" action="{{ route('admin.staff.reset_pin', $user->id) }}" method="POST" style="display:inline;">
                                    @csrf @method('PUT')
                                    <button type="button" onclick="confirmAction('form-reset-pin-{{ $user->id }}', '¿Eliminar PIN?', 'El usuario deberá configurar uno nuevo.', 'warning')" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-purple-500 hover:bg-purple-50 transition-colors" title="Restablecer PIN">
                                        <i class="ph-bold ph-numpad text-lg"></i>
                                    </button>
                                </form>
                                @endif
                                
                                @if(Auth::user()->hasPermission('users.delete'))
                                <form id="form-delete-{{ $user->id }}" action="{{ route('admin.staff.destroy', $user->id) }}" method="POST" style="display:inline;">
                                    @csrf @method('DELETE')
                                    <button type="button" onclick="confirmAction('form-delete-{{ $user->id }}', '¿Eliminar Usuario?', 'Esta acción no se puede deshacer.', 'error')" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Eliminar">
                                        <i class="ph-bold ph-trash text-lg"></i>
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-400">
                            <i class="ph-duotone ph-users-three text-4xl mb-2"></i>
                            <p>No hay usuarios registrados.</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- =========================================================================
         NUEVO MODAL: GESTIÓN DE PERMISOS
         ========================================================================= -->
    <div id="modal-permissions" class="fixed inset-0 z-50 hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closePermissionsModal()"></div>
        <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                
                <div class="relative bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col h-[70vh] border border-white/20">
                    
                    <!-- HEADER DEL MODAL -->
                    <div class="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                        <div>
                            <h2 class="text-xl font-bold text-[#213A57] flex items-center gap-2">
                                <i class="ph-fill ph-shield-check text-[#0AD1C8]"></i>
                                Permisos de Acceso
                            </h2>
                            <p class="text-sm text-gray-500">Configurando para: <span class="font-bold text-[#213A57]" id="perm-username">Usuario</span></p>
                        </div>
                        <button onclick="closePermissionsModal()" class="w-8 h-8 rounded-full bg-white flex items-center justify-center text-gray-400 hover:text-red-500 shadow-sm border border-gray-100 transition-colors">
                            <i class="ph-bold ph-x"></i>
                        </button>
                    </div>

                    <!-- CONTENIDO DE PERMISOS (GRID) -->
                    <div class="flex-1 overflow-y-auto p-8 relative bg-white">
                        <!-- Estado de Carga -->
                        <div id="permissions-loading" class="absolute inset-0 flex flex-col items-center justify-center bg-white z-10">
                            <i class="ph-bold ph-spinner animate-spin text-4xl text-[#0AD1C8] mb-3"></i>
                            <p class="text-sm text-gray-400 font-medium">Cargando permisos...</p>
                        </div>

                        <form id="permissions-form">
                            @csrf
                            <input type="hidden" id="current-perm-user-id">
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="permissions-grid">
                                <!-- Aquí se inyectan los permisos mediante JS -->
                            </div>
                        </form>
                    </div>

                    <!-- FOOTER ACCIONES -->
                    <div class="p-6 border-t border-gray-100 flex justify-end gap-3 bg-gray-50/30">
                        <button type="button" onclick="closePermissionsModal()" class="px-6 py-3 text-gray-500 font-bold text-sm hover:bg-gray-100 rounded-xl transition-colors">Cancelar</button>
                        <button type="button" onclick="savePermissions()" class="px-8 py-3 bg-[#213A57] text-white font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm flex items-center gap-2 transform hover:-translate-y-0.5">
                            <i class="ph-bold ph-floppy-disk"></i> Guardar Cambios
                        </button>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- MODAL DE USUARIO (EXISTENTE) -->
    <div id="modal-user" class="fixed inset-0 z-50 hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeModal()"></div>
        <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                
                <form id="userForm" action="{{ route('admin.staff.store') }}" method="POST" class="relative transform overflow-hidden rounded-3xl bg-white text-left shadow-2xl transition-all w-full max-w-4xl border border-white/10">
                    @csrf
                    <input type="hidden" name="_method" id="methodField" value="POST">
                    
                    <div class="bg-gradient-to-r from-[#213A57] to-[#0B6477] px-8 py-5 flex justify-between items-center">
                        <div>
                            <h3 class="text-xl font-bold text-white" id="modalTitle">Nuevo Miembro del Staff</h3>
                            <p class="text-xs text-[#80ED99]">Gestión de credenciales</p>
                        </div>
                        <button type="button" onclick="closeModal()" class="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors">
                            <i class="ph-bold ph-x"></i>
                        </button>
                    </div>

                    <div class="flex flex-col lg:flex-row">
                        <!-- SELECCIÓN DE AVATAR -->
                        <div class="lg:w-1/3 bg-gray-50/50 p-8 border-r border-gray-100 flex flex-col items-center">
                            <p class="text-sm font-bold text-[#213A57] mb-6 uppercase tracking-wider text-center">Imagen de Perfil</p>
                            <div class="relative group mb-8">
                                <div class="w-40 h-40 rounded-full border-4 border-white shadow-xl overflow-hidden bg-gray-200">
                                    <img id="avatar-preview-large" src="https://ui-avatars.com/api/?name=New+User&background=213A57&color=fff&size=256" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
                                </div>
                                <div class="absolute bottom-2 right-2 bg-[#0AD1C8] text-white p-2 rounded-full shadow-lg ring-4 ring-white pointer-events-none">
                                    <i class="ph-bold ph-camera text-xl"></i>
                                </div>
                            </div>
                            <input type="hidden" name="avatar_url" id="selected_avatar" required>
                            <div class="grid grid-cols-4 gap-3 max-h-64 overflow-y-auto p-2 w-full">
                                @foreach($avatars as $avatar)
                                    <div onclick="selectAvatar('{{ Str::startsWith($avatar, 'http') ? $avatar : asset($avatar) }}', this)" 
                                         class="avatar-option cursor-pointer rounded-full border-2 border-transparent hover:border-[#0AD1C8] hover:scale-110 transition-all p-0.5 relative group/avatar">
                                        <img src="{{ Str::startsWith($avatar, 'http') ? $avatar : asset($avatar) }}" class="w-full h-full rounded-full object-cover shadow-sm bg-white">
                                        <div class="check-icon absolute -top-1 -right-1 bg-[#0AD1C8] text-white rounded-full p-0.5 shadow-sm transform scale-0 transition-transform">
                                            <i class="ph-bold ph-check text-[10px]"></i>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <p id="avatar-helper" class="text-xs text-red-400 mt-3 text-center hidden animate-pulse">Debes seleccionar una imagen.</p>
                        </div>

                        <!-- DATOS DEL USUARIO (SIN PIN) -->
                        <div class="lg:w-2/3 p-8">
                            <p class="text-sm font-bold text-[#213A57] mb-6 uppercase tracking-wider">Información de la Cuenta</p>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Nombre</label>
                                    <input type="text" id="name" name="name" required class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm transition-all" placeholder="Ej: Juan">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Apellido</label>
                                    <input type="text" id="lastname" name="lastname" class="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm transition-all" placeholder="Ej: Pérez">
                                </div>
                                <div class="md:col-span-2">
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Correo Electrónico</label>
                                    <div class="relative">
                                        <i class="ph-bold ph-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                        <input type="email" id="email" name="email" required class="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm transition-all" placeholder="usuario@yati.bo">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Usuario</label>
                                    <div class="relative">
                                        <span class="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">@</span>
                                        <input type="text" id="username" name="username" required class="w-full pl-8 pr-4 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm transition-all" placeholder="username">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Rol Base</label>
                                    <div class="relative">
                                        <i class="ph-bold ph-shield-check absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                        <select id="role" name="role" class="w-full pl-10 pr-8 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm appearance-none cursor-pointer">
                                            <option value="moderator">Moderador</option>
                                            <option value="admin">Administrador</option>
                                            <option value="superadmin">Super Admin</option>
                                        </select>
                                        <i class="ph-bold ph-caret-down absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"></i>
                                    </div>
                                </div>
                                <div class="md:col-span-2">
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Contraseña Inicial</label>
                                    <div class="relative">
                                        <i class="ph-bold ph-lock-key absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                        <input type="text" id="password" name="password" required class="w-full pl-10 pr-10 py-3 rounded-xl border border-gray-200 bg-gray-50/30 focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none text-sm transition-all" placeholder="••••••••">
                                        <button type="button" onclick="generatePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-[#0AD1C8] hover:text-[#213A57] transition-colors" title="Generar Contraseña">
                                            <i class="ph-bold ph-arrows-clockwise"></i>
                                        </button>
                                    </div>
                                    <p class="text-[10px] text-gray-400 mt-1 hidden" id="pass-hint">Dejar en blanco para no cambiar</p>
                                </div>
                            </div>
                            <div class="mt-8 flex gap-3 pt-6 border-t border-gray-100">
                                <button type="button" onclick="closeModal()" class="flex-1 px-6 py-3 bg-white text-gray-600 font-bold rounded-xl border border-gray-200 hover:bg-gray-50 transition-all text-sm">Cancelar</button>
                                <button type="button" onclick="handleSave()" class="flex-[2] px-6 py-3 bg-[#213A57] text-white font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm flex items-center justify-center gap-2 transform hover:-translate-y-0.5">
                                    <i class="ph-bold ph-check"></i> Guardar
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- MODAL DE CREDENCIALES (EXISTENTE) -->
    <div id="modal-credentials" class="fixed inset-0 z-[60] hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#0B6477]/90 backdrop-blur-md transition-opacity"></div>
        <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center relative border-4 border-white/20">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                        <i class="ph-fill ph-check-circle text-3xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-[#213A57] mb-2" id="cred-title">¡Usuario Creado!</h3>
                    <p class="text-gray-500 mb-6 text-sm" id="cred-subtitle">Copia los datos y envíalos al usuario.</p>
                    <div class="bg-gray-50 rounded-xl p-4 text-left border border-gray-200 mb-6 space-y-3 font-mono text-sm">
                        <div class="flex justify-between"><span class="text-gray-400">Correo:</span><span class="text-[#213A57] font-bold" id="cred-email">...</span></div>
                        <div class="flex justify-between"><span class="text-gray-400">Contraseña:</span><span class="text-[#213A57] font-bold" id="cred-pass">...</span></div>
                    </div>
                    <div class="flex flex-col gap-3">
                        <button onclick="copyToClipboard()" class="w-full py-3 bg-[#25D366] hover:bg-[#128C7E] text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-green-500/30">
                            <i class="ph-fill ph-whatsapp-logo text-xl"></i> Copiar Datos
                        </button>
                        <button onclick="submitRealForm()" class="w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold rounded-xl transition-all">Cerrar y Finalizar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SCRIPTS -->
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });

        @if(session('success'))
            Toast.fire({
                icon: 'success',
                title: '{{ session('success') }}'
            });
        @endif

        @if(session('credentials_modal'))
            document.addEventListener('DOMContentLoaded', function() {
                const data = @json(session('credentials_modal'));
                document.getElementById('cred-email').innerText = data.email;
                document.getElementById('cred-pass').innerText = data.password;
                window.tempCredentialName = data.name;
                document.getElementById('cred-title').innerText = "Credenciales Restablecidas";
                document.getElementById('cred-subtitle').innerText = "La contraseña ha sido cambiada.";
                document.getElementById('modal-credentials').classList.remove('hidden');
            });
        @endif

        function confirmAction(formId, title, text, iconType = 'warning') {
            Swal.fire({
                title: title,
                text: text,
                icon: iconType,
                showCancelButton: true,
                confirmButtonColor: '#213A57',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, confirmar',
                cancelButtonText: 'Cancelar',
                background: '#fff',
                color: '#213A57',
                iconColor: iconType === 'error' ? '#EF4444' : '#0AD1C8'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById(formId).submit();
                }
            });
        }

        // --- LÓGICA DE USUARIOS ---
        let isEditMode = false;

        function selectAvatar(url, element) {
            document.getElementById('selected_avatar').value = url;
            let previewUrl = url;
            if (!url.startsWith('http')) {
                 previewUrl = element.querySelector('img').src;
            }
            document.getElementById('avatar-preview-large').src = previewUrl;

            document.querySelectorAll('.avatar-option').forEach(el => {
                el.classList.remove('border-[#0AD1C8]', 'ring-2', 'ring-[#0AD1C8]/30', 'bg-[#E0F9F6]');
                el.querySelector('.check-icon').classList.add('scale-0');
            });
            element.classList.add('border-[#0AD1C8]', 'ring-2', 'ring-[#0AD1C8]/30', 'bg-[#E0F9F6]');
            element.querySelector('.check-icon').classList.remove('scale-0');
            
            document.getElementById('avatar-helper').classList.add('hidden');
        }

        function generatePassword() {
            const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            let pass = "";
            for(let i=0; i<8; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
            document.getElementById('password').value = pass;
        }

        function openCreateModal() {
            isEditMode = false;
            document.getElementById('modalTitle').innerText = "Nuevo Miembro del Staff";
            document.getElementById('userForm').action = "{{ route('admin.staff.store') }}";
            document.getElementById('methodField').value = "POST";
            
            document.getElementById('userForm').reset();
            generatePassword();
            
            document.getElementById('password').required = true;
            document.getElementById('pass-hint').classList.add('hidden');
            
            document.getElementById('selected_avatar').value = "";
            document.getElementById('avatar-preview-large').src = "https://ui-avatars.com/api/?name=New+User&background=213A57&color=fff&size=256";
            
            document.getElementById('modal-user').classList.remove('hidden');
        }

        function openEditModal(user) {
            isEditMode = true;
            document.getElementById('modalTitle').innerText = "Editar Usuario";
            
            let baseUrl = "{{ route('admin.staff.index') }}"; 
            document.getElementById('userForm').action = baseUrl + '/' + user.id;
            document.getElementById('methodField').value = "PUT";

            let parts = (user.name || '').split(' ');
            document.getElementById('name').value = parts[0] || '';
            document.getElementById('lastname').value = parts.slice(1).join(' ') || '';
            document.getElementById('username').value = user.username || '';
            document.getElementById('email').value = user.email || '';
            document.getElementById('role').value = user.role || 'moderator';
            
            let avatarPath = user.avatar_url || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user.name || 'User') + '&background=213A57&color=fff';
            document.getElementById('selected_avatar').value = avatarPath;
            
            let avatarSrc = avatarPath;
            if (!avatarPath.startsWith('http')) {
                 avatarSrc = "{{ asset('') }}" + avatarPath;
            }
            document.getElementById('avatar-preview-large').src = avatarSrc;

            document.getElementById('password').value = "";
            document.getElementById('password').required = false;
            document.getElementById('pass-hint').classList.remove('hidden');

            document.getElementById('modal-user').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('modal-user').classList.add('hidden');
        }

        function handleSave() {
            const form = document.getElementById('userForm');
            
            if (!document.getElementById('selected_avatar').value) {
                document.getElementById('avatar-helper').classList.remove('hidden');
                return;
            }

            if (form.checkValidity()) {
                if (!isEditMode) {
                    document.getElementById('cred-email').innerText = document.getElementById('email').value;
                    document.getElementById('cred-pass').innerText = document.getElementById('password').value;
                    
                    document.getElementById('modal-user').classList.add('hidden');
                    document.getElementById('modal-credentials').classList.remove('hidden');
                } else {
                    form.submit();
                }
            } else {
                form.reportValidity();
            }
        }

        function copyToClipboard() {
            const nameInput = document.getElementById('name').value;
            const name = nameInput || window.tempCredentialName || 'Usuario';
            
            const email = document.getElementById('cred-email').innerText;
            const pass = document.getElementById('cred-pass').innerText;
            const loginUrl = "{{ route('login') }}";
            
            const text = `Hola ${name}, bienvenido a YATI.\n\nAquí tienes tus credenciales de acceso:\n📧 Correo: ${email}\n🔑 Contraseña: ${pass}\n\nIngresa aquí: ${loginUrl}\n\n*Por favor, configura tu PIN de seguridad al ingresar.*`;
            
            navigator.clipboard.writeText(text).then(() => {
                Toast.fire({
                    icon: 'success',
                    title: '¡Datos copiados al portapapeles!'
                });
            });
        }

        function submitRealForm() {
            if(window.tempCredentialName) {
                document.getElementById('modal-credentials').classList.add('hidden');
            } else {
                document.getElementById('userForm').submit();
            }
        }

        // ==========================================
        // LÓGICA DE PERMISOS POR USUARIO (NUEVO)
        // ==========================================
        function openPermissionsModal(userId, userName) {
            document.getElementById('modal-permissions').classList.remove('hidden');
            document.getElementById('perm-username').innerText = userName;
            document.getElementById('current-perm-user-id').value = userId;
            
            // Limpiar y mostrar carga
            document.getElementById('permissions-grid').innerHTML = '';
            document.getElementById('permissions-loading').classList.remove('hidden');

            // Cargar permisos vía AJAX
            fetch(`/admin/usuarios/${userId}/permissions`)
                .then(res => res.json())
                .then(data => {
                    renderPermissionsGrid(data.grouped_permissions, data.user_permissions);
                    document.getElementById('permissions-loading').classList.add('hidden');
                })
                .catch(err => {
                    console.error(err);
                    Toast.fire({ icon: 'error', title: 'Error al cargar permisos' });
                    closePermissionsModal();
                });
        }

        function closePermissionsModal() {
            document.getElementById('modal-permissions').classList.add('hidden');
        }

        function renderPermissionsGrid(groupedPermissions, userPermissions) {
            const grid = document.getElementById('permissions-grid');
            grid.innerHTML = '';

            for (const [groupName, perms] of Object.entries(groupedPermissions)) {
                // Crear tarjeta de grupo
                const card = document.createElement('div');
                card.className = "bg-gray-50 rounded-2xl p-5 border border-gray-100 hover:shadow-md transition-shadow duration-300";

                let checkboxes = '';
                perms.forEach(perm => {
                    // Verificar si el usuario tiene este permiso
                    const isChecked = userPermissions.includes(perm.id) ? 'checked' : '';
                    
                    checkboxes += `
                        <label class="flex items-start gap-3 cursor-pointer hover:bg-white p-2 rounded-xl transition-all group/check">
                            <div class="relative flex items-center mt-0.5">
                                <input type="checkbox" name="permissions[]" value="${perm.id}" ${isChecked} 
                                    class="peer appearance-none w-5 h-5 border-2 border-gray-300 rounded-md checked:bg-[#0AD1C8] checked:border-[#0AD1C8] transition-all">
                                <i class="ph-bold ph-check absolute inset-0 m-auto text-white text-xs opacity-0 peer-checked:opacity-100 pointer-events-none"></i>
                            </div>
                            <div class="flex-1">
                                <span class="text-xs font-bold text-gray-700 block group-hover/check:text-[#213A57]">${perm.label}</span>
                                <span class="text-[10px] text-gray-400 font-mono">${perm.key}</span>
                            </div>
                        </label>
                    `;
                });

                card.innerHTML = `
                    <h4 class="font-bold text-[#213A57] text-sm mb-4 pb-2 border-b border-gray-200 flex items-center gap-2">
                        <i class="ph-duotone ph-squares-four text-[#0AD1C8]"></i> ${groupName}
                    </h4>
                    <div class="space-y-1">
                        ${checkboxes}
                    </div>
                `;
                grid.appendChild(card);
            }
        }

        function savePermissions() {
            const userId = document.getElementById('current-perm-user-id').value;
            const form = document.getElementById('permissions-form');
            const formData = new FormData(form);

            fetch(`/admin/usuarios/${userId}/permissions`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    Toast.fire({ icon: 'success', title: 'Permisos actualizados correctamente' });
                    closePermissionsModal();
                } else {
                    Toast.fire({ icon: 'error', title: 'Hubo un error al guardar' });
                }
            })
            .catch(err => {
                console.error(err);
                Toast.fire({ icon: 'error', title: 'Error de conexión' });
            });
        }
    </script>
</x-layouts.admin>