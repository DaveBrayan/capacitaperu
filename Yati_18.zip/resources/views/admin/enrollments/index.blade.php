<x-layouts.admin>
    <x-slot name="title">Inscripciones</x-slot>
    <x-slot name="header">Gestión de Inscripciones</x-slot>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    @if(session('error'))
        <div class="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 flex items-center gap-2">
            <i class="ph-bold ph-warning-circle text-xl"></i>
            {{ session('error') }}
        </div>
    @endif

    <!-- BARRA DE HERRAMIENTAS -->
    <div class="flex flex-col xl:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <!-- BUSCADOR FUNCIONAL -->
        <form action="{{ route('admin.enrollments.index') }}" method="GET" class="relative w-full xl:w-96 flex gap-2">
            <div class="relative flex-1">
                <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" name="search" value="{{ $search ?? '' }}" placeholder="Buscar por alumno, email o curso..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm transition-all">
            </div>
            <button type="submit" class="px-4 bg-[#213A57] text-white rounded-xl hover:bg-[#1a2e45] transition-colors shadow-lg shadow-[#213A57]/10">
                <i class="ph-bold ph-arrow-right"></i>
            </button>
            @if($search)
                <a href="{{ route('admin.enrollments.index') }}" class="p-2.5 bg-gray-100 text-gray-400 rounded-xl hover:bg-gray-200 transition-colors" title="Limpiar búsqueda">
                    <i class="ph-bold ph-x"></i>
                </a>
            @endif
        </form>
        
        <div class="flex flex-wrap justify-center gap-3 w-full xl:w-auto">
            <!-- PROTECCIÓN: Solo si tiene permiso de gestionar inscripciones -->
            @if(Auth::user()->hasPermission('enrollments.manage'))
                <button onclick="openEnrollModal()" class="flex items-center gap-2 px-5 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#1a2e45] transition-all shadow-lg text-xs font-bold transform hover:-translate-y-0.5">
                    <i class="ph-bold ph-user-plus text-lg"></i> Nuevo Estudiante
                </button>

                <button onclick="openExistingEnrollModal()" class="flex items-center gap-2 px-5 py-2.5 bg-[#0B6477] text-white rounded-xl hover:bg-[#084d5c] transition-all shadow-lg text-xs font-bold transform hover:-translate-y-0.5">
                    <i class="ph-bold ph-users text-lg"></i> Inscribir Antiguo
                </button>

                <button onclick="openLinkGeneratorModal()" class="flex items-center gap-2 px-5 py-2.5 bg-[#0AD1C8] text-[#213A57] rounded-xl hover:bg-[#08b3ab] transition-all shadow-lg shadow-[#0AD1C8]/20 text-xs font-bold transform hover:-translate-y-0.5">
                    <i class="ph-bold ph-link text-lg"></i> Link Estudiante Nuevo
                </button>
            @endif
        </div>
    </div>

    <!-- TABLA DE SOLICITUDES -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.2s">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/50 text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 w-10">#</th> <!-- COLUMNA DE NUMERACIÓN -->
                        <th class="px-6 py-4">Solicitante</th>
                        <th class="px-6 py-4">Curso Solicitado</th>
                        <th class="px-6 py-4">Boleta de Pago</th>
                        <th class="px-6 py-4 text-center">Fecha</th>
                        <th class="px-6 py-4 text-center">Estado</th>
                        <th class="px-6 py-4 text-right">Acción</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    @forelse($enrollments as $index => $enrollment)
                    <tr class="hover:bg-[#F0FDFD] transition-colors group">
                        <!-- NUMERACIÓN INTELIGENTE -->
                        <td class="px-6 py-4 font-mono text-gray-400 text-xs">
                            {{ $enrollments->firstItem() + $index }}
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-gray-100 p-0.5 border border-gray-200 overflow-hidden shrink-0">
                                    <img src="{{ Str::startsWith($enrollment->student->avatar_url ?? '', 'http') ? $enrollment->student->avatar_url : asset($enrollment->student->avatar_url ?? 'assets/default-avatar.png') }}" class="w-full h-full object-cover">
                                </div>
                                <div class="truncate max-w-[200px]">
                                    <p class="font-bold text-[#213A57] truncate">{{ $enrollment->student->name }}</p>
                                    <p class="text-xs text-gray-500 truncate">{{ $enrollment->student->email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-2">
                                <span class="p-1.5 rounded-lg bg-blue-50 text-blue-600"><i class="ph-bold ph-graduation-cap"></i></span>
                                <span class="font-medium text-gray-700 truncate max-w-[180px]">{{ $enrollment->course->title }}</span>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            @if($enrollment->receipt_url)
                                <div class="group/boleta relative w-12 h-12 rounded-lg overflow-hidden border border-gray-200 cursor-pointer shadow-sm hover:shadow-md transition-all" onclick="verBoleta('{{ asset($enrollment->receipt_url) }}')">
                                    <img src="{{ asset($enrollment->receipt_url) }}" class="w-full h-full object-cover">
                                    <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover/boleta:opacity-100 transition-opacity">
                                        <i class="ph-bold ph-eye text-white text-lg"></i>
                                    </div>
                                </div>
                            @else
                                <span class="text-[10px] text-gray-400 italic">Sin boleta</span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-center text-xs text-gray-500">
                            {{ $enrollment->created_at->format('d/m/Y') }}<br>
                            <span class="text-[10px] opacity-60">{{ $enrollment->created_at->format('H:i') }}</span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            @if($enrollment->status === 'approved')
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-green-50 text-green-600 border border-green-100">
                                    <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Aprobado
                                </span>
                            @else
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-50 text-amber-600 border border-amber-100">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> Pendiente
                                </span>
                            @endif
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="flex justify-end items-center gap-2">
                                <!-- PROTECCIÓN DE ACCIONES DE FILA -->
                                @if(Auth::user()->hasPermission('enrollments.manage'))
                                    @if($enrollment->status !== 'approved')
                                        <form action="{{ route('admin.enrollments.approve', $enrollment->id) }}" method="POST" class="inline">
                                            @csrf @method('PUT')
                                            <button type="submit" class="px-3 py-1.5 bg-[#0AD1C8] text-white text-[10px] font-bold rounded-lg hover:bg-[#08b3ab] transition-all shadow-sm">Aprobar</button>
                                        </form>
                                    @endif
                                    
                                    <form action="{{ route('admin.enrollments.destroy', $enrollment->id) }}" method="POST" class="inline" onsubmit="return confirm('¿Seguro que desea eliminar esta inscripción?');">
                                        @csrf @method('DELETE')
                                        <button class="w-8 h-8 flex items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-500 rounded-lg transition-all"><i class="ph-bold ph-trash text-lg"></i></button>
                                    </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="px-6 py-16 text-center text-gray-400">
                            <div class="flex flex-col items-center gap-2">
                                <i class="ph-duotone ph-magnifying-glass text-4xl opacity-20"></i>
                                <p>No se encontraron inscripciones registradas.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-4 border-t border-gray-100 bg-gray-50/50">{{ $enrollments->links() }}</div>
    </div>

    <!-- 1. MODAL NUEVO ESTUDIANTE -->
    <div id="modal-enroll" class="fixed inset-0 z-50 hidden overflow-y-auto" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeEnrollModal()"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <form id="enrollForm" action="{{ route('admin.enrollments.store') }}" method="POST" enctype="multipart/form-data" class="relative transform overflow-hidden rounded-3xl bg-white shadow-2xl transition-all w-full max-w-2xl">
                @csrf
                <div class="bg-[#213A57] px-8 py-5 flex justify-between items-center text-white">
                    <h3 class="text-xl font-bold">Registro Estudiante Nuevo</h3>
                    <button type="button" onclick="closeEnrollModal()" class="text-white hover:opacity-70"><i class="ph-bold ph-x text-xl"></i></button>
                </div>
                <div class="p-8 space-y-5">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Curso</label>
                        <select name="course_id" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                            @foreach($courses as $course) <option value="{{ $course->id }}">{{ $course->title }}</option> @endforeach
                        </select>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div class="md:col-span-2">
                            <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Nombre Completo</label>
                            <input type="text" name="name" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Email</label>
                            <input type="email" name="email" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-500 uppercase mb-1">WhatsApp</label>
                            <input type="text" name="phone" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Contraseña</label>
                            <div class="relative">
                                <input type="text" id="password" name="password" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm font-mono">
                                <button type="button" onclick="generatePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-[#0AD1C8]"><i class="ph-bold ph-arrows-clockwise"></i></button>
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Comprobante</label>
                            <input type="file" name="receipt_file" class="w-full text-xs text-gray-500 border border-gray-200 rounded-xl p-2 bg-gray-50">
                        </div>
                    </div>
                    <div class="flex justify-end gap-3 pt-4 border-t">
                        <button type="button" onclick="closeEnrollModal()" class="px-6 py-2.5 text-gray-500 font-bold">Cancelar</button>
                        <button type="submit" class="px-6 py-2.5 bg-[#213A57] text-white font-bold rounded-xl shadow-lg text-sm">Inscribir Ahora</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- 2. MODAL ESTUDIANTE ANTIGUO -->
    <div id="modal-enroll-existing" class="fixed inset-0 z-50 hidden overflow-y-auto" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeExistingEnrollModal()"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <form action="{{ route('admin.enrollments.store_existing') }}" method="POST" enctype="multipart/form-data" class="relative transform overflow-hidden rounded-3xl bg-white shadow-2xl transition-all w-full max-w-xl">
                @csrf
                <div class="bg-[#0B6477] px-8 py-5 flex justify-between items-center text-white">
                    <h3 class="text-xl font-bold">Inscribir Alumno Existente</h3>
                    <button type="button" onclick="closeExistingEnrollModal()" class="text-white hover:opacity-70"><i class="ph-bold ph-x text-xl"></i></button>
                </div>
                <div class="p-8 space-y-6">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Seleccionar Alumno</label>
                        <select name="student_id" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                            <option value="">Buscar estudiante...</option>
                            @foreach($students ?? [] as $student)
                                <option value="{{ $student->id }}">{{ $student->name }} ({{ $student->email }})</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Curso</label>
                        <select name="course_id" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm">
                            @foreach($courses as $course) <option value="{{ $course->id }}">{{ $course->title }}</option> @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Comprobante (Opcional)</label>
                        <input type="file" name="receipt_file" class="w-full text-xs border border-gray-200 rounded-xl p-2 bg-gray-50">
                    </div>
                    <div class="flex justify-end gap-3 pt-4 border-t">
                        <button type="button" onclick="closeExistingEnrollModal()" class="px-6 py-2.5 text-gray-500 font-bold">Cancelar</button>
                        <button type="submit" class="px-6 py-2.5 bg-[#0B6477] text-white font-bold rounded-xl shadow-lg text-sm">Matricular</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- 3. MODAL GENERADOR DE LINKS (SOLO NUEVOS) -->
    <div id="modal-link-generator" class="fixed inset-0 z-50 hidden overflow-y-auto" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeLinkGeneratorModal()"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative transform overflow-hidden rounded-3xl bg-white shadow-2xl transition-all w-full max-w-md">
                <div class="bg-[#0AD1C8] px-8 py-5 flex justify-between items-center">
                    <div>
                        <h3 class="text-xl font-bold text-[#213A57]">Link de Registro</h3>
                        <p class="text-[10px] text-[#213A57]/70 uppercase font-bold">Solo para Estudiantes Nuevos</p>
                    </div>
                    <button type="button" onclick="closeLinkGeneratorModal()" class="text-[#213A57] hover:opacity-70"><i class="ph-bold ph-x text-xl"></i></button>
                </div>
                <div class="p-8 space-y-6">
                    <div class="p-4 bg-[#E0F9F6] rounded-2xl border border-[#0AD1C8]/20 flex items-center gap-4">
                        <div class="w-12 h-12 rounded-full bg-white flex items-center justify-center text-[#0AD1C8] shadow-sm"><i class="ph-bold ph-user-plus text-2xl"></i></div>
                        <p class="text-xs text-[#0B6477] font-medium leading-tight">Este enlace permitirá al estudiante crear su cuenta y subir su comprobante.</p>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Seleccionar Curso</label>
                        <select id="link-course-id" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                            <option value="">¿Para qué curso es el link?</option>
                            @foreach($courses as $course) <option value="{{ $course->id }}">{{ $course->title }}</option> @endforeach
                        </select>
                    </div>

                    <div id="link-result" class="hidden animate-fade-in space-y-2">
                        <label class="block text-xs font-bold text-[#0B6477] uppercase ml-1">Link Generado:</label>
                        <div class="flex gap-2">
                            <input type="text" id="generated-url" readonly class="flex-1 bg-gray-100 px-4 py-2.5 rounded-xl border border-gray-200 text-[10px] font-mono text-[#213A57]">
                            <button onclick="copyGeneratedLink()" class="px-4 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all"><i class="ph-bold ph-copy"></i></button>
                        </div>
                    </div>

                    <div class="flex justify-end gap-3 pt-4 border-t">
                        <button type="button" onclick="closeLinkGeneratorModal()" class="px-6 py-2.5 text-gray-500 font-bold text-sm">Cerrar</button>
                        <button id="btn-generate-action" onclick="generateEnrollmentLink()" class="px-6 py-2.5 bg-[#213A57] text-white font-bold rounded-xl shadow-lg text-sm">Generar Enlace</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL DE CREDENCIALES EXITOSAS (CORREGIDO) -->
    <div id="modal-credentials" class="fixed inset-0 z-[60] hidden overflow-y-auto" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#0B6477]/90 backdrop-blur-md transition-opacity"></div>
        <div class="relative z-10 flex min-h-full items-center justify-center p-4"> <!-- Agregado relative y z-10 -->
            <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
                <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600"><i class="ph-fill ph-check-circle text-3xl"></i></div>
                <h3 class="text-2xl font-bold text-[#213A57] mb-2">Inscripción Exitosa</h3>
                <p class="text-gray-500 mb-6 text-sm">Copia estos datos para enviarlos al estudiante.</p>
                <div class="bg-gray-50 rounded-xl p-4 text-left border border-gray-200 mb-6 space-y-2 font-mono text-xs">
                    <div class="flex justify-between"><span class="text-gray-400">Email:</span><span class="text-[#213A57] font-bold" id="cred-email">...</span></div>
                    <div class="flex justify-between"><span class="text-gray-400">Pass:</span><span class="text-[#213A57] font-bold" id="cred-pass">...</span></div>
                </div>
                <button onclick="copyToClipboard()" class="w-full py-3 bg-[#25D366] text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2"><i class="ph-fill ph-whatsapp-logo text-xl"></i> Copiar para WhatsApp</button>
                <button onclick="document.getElementById('modal-credentials').classList.add('hidden')" class="w-full mt-2 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- MODAL VER BOLETA -->
    <div id="modal-boleta" class="fixed inset-0 z-[100] hidden bg-black/90 backdrop-blur-md flex items-center justify-center p-4" onclick="this.classList.add('hidden')">
        <img id="boleta-img" src="" class="max-w-full max-h-[90vh] rounded-lg border-4 border-white shadow-2xl">
    </div>

    <script>
        const Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true });

        @if(session('credentials_modal'))
            document.addEventListener('DOMContentLoaded', function() {
                const data = @json(session('credentials_modal'));
                document.getElementById('cred-email').innerText = data.email;
                document.getElementById('cred-pass').innerText = data.password;
                window.tempCredentialName = data.name;
                window.tempCredentialCourse = data.course;
                document.getElementById('modal-credentials').classList.remove('hidden');
            });
        @endif

        function openEnrollModal() { document.getElementById('enrollForm').reset(); generatePassword(); document.getElementById('modal-enroll').classList.remove('hidden'); }
        function closeEnrollModal() { document.getElementById('modal-enroll').classList.add('hidden'); }
        function openExistingEnrollModal() { document.getElementById('modal-enroll-existing').classList.remove('hidden'); }
        function closeExistingEnrollModal() { document.getElementById('modal-enroll-existing').classList.add('hidden'); }
        function openLinkGeneratorModal() { 
            document.getElementById('link-result').classList.add('hidden');
            document.getElementById('btn-generate-action').classList.remove('hidden');
            document.getElementById('modal-link-generator').classList.remove('hidden'); 
        }
        function closeLinkGeneratorModal() { document.getElementById('modal-link-generator').classList.add('hidden'); }

        function copyGeneratedLink() {
            const url = document.getElementById('generated-url');
            url.select(); document.execCommand('copy');
            Toast.fire({ icon: 'success', title: 'Enlace copiado' });
        }

        function generatePassword() {
            const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
            let pass = ""; for(let i=0; i<8; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
            document.getElementById('password').value = pass;
        }

        function verBoleta(url) { document.getElementById('boleta-img').src = url; document.getElementById('modal-boleta').classList.remove('hidden'); }

        function copyToClipboard() {
            const name = window.tempCredentialName || 'Estudiante';
            const email = document.getElementById('cred-email').innerText;
            const pass = document.getElementById('cred-pass').innerText;
            const course = window.tempCredentialCourse || 'el curso';
            const text = `Hola ${name}, tu inscripción al curso *${course}* en YATI Academy ha sido exitosa.\n\nAccede aquí: ${window.location.origin}/login\nUsuario: ${email}\nContraseña: ${pass}`;
            navigator.clipboard.writeText(text).then(() => { Toast.fire({ icon: 'success', title: 'Copiado al portapapeles' }); });
        }

        async function generateEnrollmentLink() {
            const courseId = document.getElementById('link-course-id').value;
            if(!courseId) { 
                Toast.fire({ icon: 'warning', title: 'Seleccione un curso' }); 
                return; 
            }

            const btn = document.getElementById('btn-generate-action');
            btn.disabled = true;
            btn.innerText = "Generando...";

            try {
                const response = await fetch('{{ route("admin.enrollments.generate_token") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ course_id: courseId })
                });

                const data = await response.json();

                if (data.url) {
                    document.getElementById('generated-url').value = data.url;
                    document.getElementById('link-result').classList.remove('hidden');
                    btn.classList.add('hidden');
                    Toast.fire({ icon: 'success', title: 'Link único generado' });
                }
            } catch (error) {
                console.error(error);
                Toast.fire({ icon: 'error', title: 'Error al conectar con el servidor' });
                btn.disabled = false;
                btn.innerText = "Generar Enlace";
            }
        }
    </script>
</x-layouts.admin>