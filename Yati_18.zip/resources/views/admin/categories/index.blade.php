<x-layouts.admin>
    <x-slot name="title">Gestión de Categorías</x-slot>
    <x-slot name="header">Categorías</x-slot>

    <!-- Header Actions -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <form method="GET" class="relative w-full md:w-72">
            <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Buscar categoría..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm transition-all">
        </form>
        
        <!-- PROTECCIÓN: CREAR CATEGORÍA -->
        @if(Auth::user()->hasPermission('categories.manage'))
        <button onclick="openModal()" class="w-full md:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-[#213A57] text-white rounded-xl hover:bg-[#0B6477] transition-all shadow-lg shadow-[#213A57]/20 text-sm font-bold">
            <i class="ph-bold ph-plus"></i> Nueva Categoría
        </button>
        @endif
    </div>

    <!-- Lista de Categorías -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 fade-in-up" style="animation-delay: 0.1s">
        @forelse($categories as $category)
        <div class="bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-md transition-all group relative">
            
            <!-- Acciones (Solo visible si tiene permiso de gestión) -->
            @if(Auth::user()->hasPermission('categories.manage'))
            <div class="absolute top-3 right-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <button onclick="editModal({{ json_encode($category) }})" class="p-1.5 bg-gray-50 rounded-lg text-gray-500 hover:text-[#0AD1C8]"><i class="ph-bold ph-pencil-simple"></i></button>
                <form action="{{ route('admin.categories.destroy', $category->id) }}" method="POST" onsubmit="return confirm('¿Eliminar categoría?');">
                    @csrf @method('DELETE')
                    <button type="submit" class="p-1.5 bg-gray-50 rounded-lg text-gray-500 hover:text-red-500"><i class="ph-bold ph-trash"></i></button>
                </form>
            </div>
            @endif

            <div class="flex items-start gap-4">
                <div class="w-12 h-12 rounded-xl bg-[#E0F9F6] flex items-center justify-center text-[#0B6477] shrink-0">
                    <!-- Icono dinámico o default -->
                    <i class="ph-bold {{ $category->icon ?? 'ph-tag' }} text-xl"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <h3 class="font-bold text-[#213A57] text-base truncate" title="{{ $category->name }}">{{ $category->name }}</h3>
                    <p class="text-xs text-gray-400 mt-1 line-clamp-2 h-8">{{ $category->description ?? 'Sin descripción' }}</p>
                    
                    <div class="flex items-center justify-between mt-3">
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded-md {{ $category->status ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-500' }}">
                            {{ $category->status ? 'Activo' : 'Inactivo' }}
                        </span>
                        <span class="text-[10px] text-gray-400 flex items-center gap-1">
                            <i class="ph-bold ph-book-open"></i> {{ $category->courses_count }} Cursos
                        </span>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="col-span-full text-center py-12 bg-white rounded-2xl border border-gray-100 border-dashed">
            <div class="w-14 h-14 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <i class="ph-duotone ph-tag text-2xl text-gray-300"></i>
            </div>
            <p class="text-gray-400 text-sm">No hay categorías registradas.</p>
        </div>
        @endforelse
    </div>

    <!-- Paginación -->
    <div class="mt-8">
        {{ $categories->links() }}
    </div>

    <!-- MODAL (CREAR / EDITAR) -->
    <div id="category-modal" class="fixed inset-0 z-50 hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/80 backdrop-blur-sm transition-opacity" onclick="closeModal()"></div>
        
        <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4 text-center">
                <div class="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-xl transition-all sm:w-full sm:max-w-md border border-gray-100">
                    
                    <div class="bg-[#F8FAFC] px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="text-lg font-bold text-[#213A57]" id="modal-title">Nueva Categoría</h3>
                        <button onclick="closeModal()" class="text-gray-400 hover:text-red-500 transition-colors"><i class="ph-bold ph-x text-xl"></i></button>
                    </div>

                    <form id="category-form" method="POST" action="{{ route('admin.categories.store') }}">
                        @csrf
                        <input type="hidden" name="_method" id="form-method" value="POST">
                        
                        <div class="p-6 space-y-4">
                            <!-- Nombre -->
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Nombre</label>
                                <input type="text" name="name" id="input_name" required 
                                       class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm transition-all"
                                       placeholder="Ej: Desarrollo Web">
                            </div>

                            <!-- Icono -->
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">
                                    Icono (Phosphor) 
                                    <a href="https://phosphoricons.com/" target="_blank" class="text-[#0AD1C8] hover:underline ml-1 text-[10px] lowercase">ver iconos</a>
                                </label>
                                <div class="flex gap-2">
                                    <div class="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center text-gray-500 border border-gray-200" id="icon-preview">
                                        <i class="ph-bold ph-tag"></i>
                                    </div>
                                    <input type="text" name="icon" id="input_icon" 
                                           class="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm"
                                           placeholder="Ej: ph-code" oninput="updateIconPreview(this.value)">
                                </div>
                            </div>

                            <!-- Descripción -->
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Descripción</label>
                                <textarea name="description" id="input_description" rows="3"
                                          class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm resize-none"></textarea>
                            </div>

                            <!-- Estado -->
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Estado</label>
                                <select name="status" id="input_status" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-white">
                                    <option value="1">Activo</option>
                                    <option value="0">Inactivo</option>
                                </select>
                            </div>
                        </div>

                        <div class="bg-gray-50 px-6 py-4 flex justify-end gap-3 border-t border-gray-100">
                            <button type="button" onclick="closeModal()" class="px-4 py-2 bg-white border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50 text-sm font-bold">Cancelar</button>
                            <button type="submit" class="px-6 py-2 bg-[#213A57] text-white rounded-lg hover:bg-[#0B6477] text-sm font-bold shadow-lg shadow-[#213A57]/20">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const modal = document.getElementById('category-modal');
        const form = document.getElementById('category-form');
        const title = document.getElementById('modal-title');
        const methodInput = document.getElementById('form-method');

        function updateIconPreview(val) {
            const preview = document.getElementById('icon-preview');
            // Simple validation to ensure it starts with ph-
            const iconClass = val && val.trim() !== '' ? val : 'ph-tag';
            preview.innerHTML = `<i class="ph-bold ${iconClass}"></i>`;
        }

        function openModal() {
            form.action = "{{ route('admin.categories.store') }}";
            methodInput.value = "POST";
            title.innerText = "Nueva Categoría";
            form.reset();
            updateIconPreview('');
            modal.classList.remove('hidden');
        }

        function editModal(category) {
            let url = "{{ route('admin.categories.update', ':id') }}";
            form.action = url.replace(':id', category.id);
            methodInput.value = "PUT";
            title.innerText = "Editar Categoría";
            
            document.getElementById('input_name').value = category.name;
            document.getElementById('input_icon').value = category.icon;
            document.getElementById('input_description').value = category.description;
            document.getElementById('input_status').value = category.status ? "1" : "0";
            
            updateIconPreview(category.icon);
            modal.classList.remove('hidden');
        }

        function closeModal() {
            modal.classList.add('hidden');
        }
    </script>
</x-layouts.admin>