<x-layouts.admin>
    <x-slot name="title">Dashboard - YATI</x-slot>
    <x-slot name="header">Resumen General</x-slot>

    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- HEADER CON FILTROS -->
    <div class="flex flex-col md:flex-row justify-between items-end gap-4 mb-8 fade-in-up" style="animation-delay: 0.1s">
        <div>
            <h1 class="text-3xl font-bold text-[#213A57]">
                Hola, <span class="text-transparent bg-clip-text bg-gradient-to-r from-[#0B6477] to-[#0AD1C8]">{{ Auth::user()->name }}</span> 👋
            </h1>
            <p class="text-gray-500 mt-1">Reporte de rendimiento: <span class="font-bold text-[#0B6477]">{{ $periodLabel }}</span></p>
        </div>

        <!-- FILTROS -->
        <div class="bg-white p-1 rounded-xl border border-gray-200 flex shadow-sm">
            <a href="{{ route('admin.dashboard', ['filter' => 'today']) }}" 
               class="px-4 py-2 rounded-lg text-xs font-bold transition-all {{ $filter === 'today' ? 'bg-[#213A57] text-white shadow-md' : 'text-gray-500 hover:bg-gray-50' }}">
               Hoy
            </a>
            <a href="{{ route('admin.dashboard', ['filter' => '7_days']) }}" 
               class="px-4 py-2 rounded-lg text-xs font-bold transition-all {{ $filter === '7_days' ? 'bg-[#213A57] text-white shadow-md' : 'text-gray-500 hover:bg-gray-50' }}">
               7 Días
            </a>
            <a href="{{ route('admin.dashboard', ['filter' => 'month']) }}" 
               class="px-4 py-2 rounded-lg text-xs font-bold transition-all {{ $filter === 'month' ? 'bg-[#213A57] text-white shadow-md' : 'text-gray-500 hover:bg-gray-50' }}">
               Este Mes
            </a>
        </div>
    </div>

    <!-- TARJETAS DE MÉTRICAS -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        
        <!-- CARD: ESTUDIANTES -->
        <div class="bg-white rounded-3xl p-6 shadow-xl shadow-gray-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 border border-gray-100 group fade-in-up" style="animation-delay: 0.2s">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1">Nuevos Estudiantes</p>
                    <h3 class="text-3xl font-bold text-[#213A57]">+{{ $newStudentsCurrent }}</h3>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-[#eefcfc] flex items-center justify-center text-[#0B6477] group-hover:bg-[#0B6477] group-hover:text-white transition-colors duration-300">
                    <i class="ph ph-users-three text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                @if($studentGrowth >= 0)
                    <span class="bg-[#80ED99]/30 text-[#0B6477] px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <i class="ph ph-trend-up"></i> +{{ round($studentGrowth, 0) }}%
                    </span>
                @else
                    <span class="bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <i class="ph ph-trend-down"></i> {{ round($studentGrowth, 0) }}%
                    </span>
                @endif
                <span class="text-gray-400 ml-2 text-xs">vs periodo anterior</span>
            </div>
        </div>

        <!-- CARD: CURSOS ACTIVOS -->
        <div class="bg-gradient-to-br from-[#0B6477] to-[#14919B] rounded-3xl p-6 shadow-xl shadow-[#0B6477]/30 hover:-translate-y-1 transition-all duration-300 text-white fade-in-up" style="animation-delay: 0.3s">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-bold text-[#45DFB1] uppercase tracking-wide mb-1">Total Cursos</p>
                    <h3 class="text-3xl font-bold">{{ $activeCourses }}</h3>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white">
                    <i class="ph ph-monitor-play text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm text-gray-100">
                <span class="text-white font-bold text-lg">+{{ $newCoursesPeriod }}</span>
                <span class="opacity-70 ml-2 text-xs">publicados en este periodo</span>
            </div>
        </div>

        <!-- CARD: INGRESOS -->
        <div class="bg-white rounded-3xl p-6 shadow-xl shadow-gray-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 border border-gray-100 group fade-in-up" style="animation-delay: 0.4s">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-bold text-gray-400 uppercase tracking-wide mb-1">Ingresos</p>
                    <h3 class="text-3xl font-bold text-[#213A57]">Bs {{ number_format($currentRevenue, 2) }}</h3>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-[#f0fdf9] flex items-center justify-center text-[#0AD1C8] group-hover:bg-[#0AD1C8] group-hover:text-white transition-colors duration-300">
                    <i class="ph ph-currency-dollar text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 flex items-center text-sm">
                @if($revenueGrowth >= 0)
                    <span class="bg-[#80ED99]/30 text-green-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <i class="ph ph-trend-up"></i> +{{ round($revenueGrowth, 1) }}%
                    </span>
                @else
                    <span class="bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                        <i class="ph ph-trend-down"></i> {{ round($revenueGrowth, 1) }}%
                    </span>
                @endif
                <span class="text-gray-400 ml-2 text-xs">vs periodo anterior</span>
            </div>
        </div>

        <!-- CARD: TASA FINALIZACIÓN -->
        <div class="bg-gradient-to-br from-[#0AD1C8] to-[#45DFB1] rounded-3xl p-6 shadow-xl shadow-[#45DFB1]/40 hover:-translate-y-1 transition-all duration-300 fade-in-up" style="animation-delay: 0.5s">
            <div class="flex justify-between items-start">
                <div>
                    <p class="text-xs font-bold text-[#213A57] uppercase tracking-wide mb-1 opacity-80">Tasa Finalización</p>
                    <h3 class="text-3xl font-bold text-[#213A57]">{{ $completionRate }}%</h3>
                </div>
                <div class="w-12 h-12 rounded-2xl bg-[#213A57]/10 flex items-center justify-center text-[#213A57]">
                    <i class="ph ph-medal text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 w-full bg-[#213A57]/10 rounded-full h-1.5">
                <div class="bg-[#213A57] h-1.5 rounded-full" style="width: {{ $completionRate }}%"></div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 fade-in-up" style="animation-delay: 0.6s">
        
        <!-- TABLA: ÚLTIMAS INSCRIPCIONES (GENERALES) -->
        <div class="lg:col-span-2 bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-bold text-xl text-[#213A57]">Últimas Inscripciones</h3>
                <a href="{{ route('admin.enrollments.index') }}" class="text-sm font-medium text-[#0B6477] hover:text-[#0AD1C8] transition-colors">Ver todas</a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-[#0B6477] text-sm border-b border-gray-100">
                            <th class="pb-3 font-semibold pl-4">Estudiante</th>
                            <th class="pb-3 font-semibold">Curso</th>
                            <th class="pb-3 font-semibold">Fecha</th>
                            <th class="pb-3 font-semibold">Estado</th>
                            <th class="pb-3 font-semibold"></th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        @forelse($recentEnrollments as $enrollment)
                        <tr class="hover:bg-[#f8fcfc] transition-colors group">
                            <td class="py-4 pl-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-gray-200 overflow-hidden shrink-0 border border-gray-100">
                                        <img src="{{ $enrollment->student->avatar_url ? (Str::startsWith($enrollment->student->avatar_url, 'http') ? $enrollment->student->avatar_url : asset($enrollment->student->avatar_url)) : 'https://ui-avatars.com/api/?name='.urlencode($enrollment->student->name) }}" class="w-full h-full object-cover">
                                    </div>
                                    <div class="font-medium text-[#213A57]">{{ $enrollment->student->name }}</div>
                                </div>
                            </td>
                            <td class="py-4 text-gray-600 max-w-[150px] truncate" title="{{ $enrollment->course->title }}">
                                {{ $enrollment->course->title }}
                            </td>
                            <td class="py-4 text-gray-400 text-xs">
                                {{ $enrollment->created_at->format('d M, H:i') }}
                            </td>
                            <td class="py-4">
                                @if($enrollment->is_completed)
                                    <span class="px-3 py-1 rounded-full text-xs font-semibold bg-[#80ED99]/20 text-[#0B6477] border border-[#80ED99]">
                                        Completado
                                    </span>
                                @else
                                    <span class="px-3 py-1 rounded-full text-xs font-semibold bg-yellow-100 text-yellow-700 border border-yellow-200">
                                        En Curso
                                    </span>
                                @endif
                            </td>
                            <td class="py-4 text-right pr-2">
                                <a href="{{ route('admin.students.index', ['search' => $enrollment->student->email]) }}" class="text-gray-300 hover:text-[#0AD1C8] transition-colors"><i class="ph ph-eye text-xl"></i></a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="py-8 text-center text-gray-400">No hay inscripciones recientes.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- GRÁFICO: VENTAS -->
        <div class="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm relative overflow-hidden flex flex-col">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h3 class="font-bold text-xl text-[#213A57] flex items-center gap-2">
                        <i class="ph ph-chart-line-up text-[#0AD1C8]"></i> Ventas
                    </h3>
                    <p class="text-xs text-gray-400">Evolución de ingresos</p>
                </div>
                <div class="bg-[#E0F9F6] text-[#0B6477] px-3 py-1 rounded-lg text-xs font-bold">
                    {{ $filter === 'today' ? 'Hoy' : ($filter === '7_days' ? '7 Días' : 'Mes') }}
                </div>
            </div>

            <!-- Contenedor del Gráfico -->
            <div class="flex-1 min-h-[250px] relative w-full">
                <canvas id="salesChart"></canvas>
            </div>
        </div>

    </div>

    <!-- Script para Chart.js -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('salesChart').getContext('2d');
            
            // Datos dinámicos desde el controlador
            const labels = @json($chartLabels);
            const data = @json($chartData);

            // Crear gradiente para el gráfico
            const gradient = ctx.createLinearGradient(0, 0, 0, 300);
            gradient.addColorStop(0, 'rgba(10, 209, 200, 0.4)'); // Color #0AD1C8
            gradient.addColorStop(1, 'rgba(10, 209, 200, 0.0)');

            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Ingresos (Bs)',
                        data: data,
                        borderColor: '#0B6477',
                        backgroundColor: gradient,
                        borderWidth: 2,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#0B6477',
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        fill: true,
                        tension: 0.4 // Curva suave
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#213A57',
                            titleColor: '#fff',
                            bodyColor: '#fff',
                            padding: 10,
                            displayColors: false,
                            callbacks: {
                                label: function(context) {
                                    return 'Bs ' + context.parsed.y;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#f3f4f6',
                                borderDash: [5, 5]
                            },
                            ticks: {
                                color: '#9ca3af',
                                font: { size: 10 }
                            }
                        },
                        x: {
                            grid: { display: false },
                            ticks: {
                                color: '#9ca3af',
                                font: { size: 10 }
                            }
                        }
                    }
                }
            });
        });
    </script>
</x-layouts.admin>