<x-layouts.admin>
    <x-slot name="title">Estudiantes - Gestión</x-slot>
    <x-slot name="header">Directorio de Estudiantes</x-slot>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="//unpkg.com/alpinejs" defer></script>

    <!-- BARRA DE HERRAMIENTAS -->
    <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-8 fade-in-up">
        <form action="{{ route('admin.students.index') }}" method="GET" class="flex gap-3 w-full md:w-auto">
            <div class="relative w-full md:w-96">
                <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" name="search" value="{{ $search ?? '' }}" placeholder="Nombre, correo, CI o WhatsApp..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-sm">
            </div>
            <select name="status" onchange="this.form.submit()" class="px-4 py-2.5 rounded-xl border border-gray-200 bg-white text-gray-600 text-sm focus:border-[#0AD1C8] outline-none cursor-pointer">
                <option value="Todos" {{ request('status') == 'Todos' ? 'selected' : '' }}>Todos</option>
                <option value="Activos" {{ request('status') == 'Activos' ? 'selected' : '' }}>Activos</option>
                <option value="Inactivos" {{ request('status') == 'Inactivos' ? 'selected' : '' }}>Inactivos</option>
            </select>
        </form>

        <div class="text-xs text-gray-400 font-medium">
            <i class="ph-bold ph-check-square text-[#0AD1C8]"></i> Listando alumnos con inscripciones aprobadas.
        </div>
    </div>

    <!-- TABLA -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.2s">
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50/50 text-[10px] font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 w-12 text-center">#</th>
                        <th class="px-6 py-4">Estudiante</th>
                        <th class="px-6 py-4">Identificación / Celular</th>
                        <th class="px-6 py-4">Últimos Cursos Inscritos</th>
                        <th class="px-6 py-4 text-center">Estado</th>
                        <th class="px-6 py-4 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    @forelse($students as $index => $student)
                    <tr class="hover:bg-[#F0FDFD]/50 transition-colors group">
                        <td class="px-6 py-4 text-center font-mono text-gray-400 text-xs">
                            {{ $students->firstItem() + $index }}
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-full bg-[#E0F9F6] p-0.5 border border-[#0AD1C8]/20 overflow-hidden shrink-0">
                                    <img src="{{ Str::startsWith($student->avatar_url, 'http') ? $student->avatar_url : asset($student->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($student->name)) }}" class="w-full h-full rounded-full object-cover">
                                </div>
                                <div class="max-w-[200px]">
                                    <p class="font-bold text-[#213A57] leading-tight">{{ $student->name }}</p>
                                    <p class="text-[10px] text-gray-400 truncate">{{ $student->email }}</p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="space-y-1">
                                <div class="flex items-center gap-1.5 text-xs text-gray-600">
                                    <i class="ph-bold ph-identification-card text-[#0AD1C8]"></i>
                                    <span>{{ $student->ci_nit ?? 'Sin CI' }}</span>
                                </div>
                                <div class="flex items-center gap-1.5 text-xs text-gray-600">
                                    <i class="ph-bold ph-whatsapp-logo text-green-500"></i>
                                    <span>{{ $student->phone ?? 'S/N' }}</span>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="flex flex-col gap-1.5 py-1">
                                @forelse($student->enrollments as $enrollment)
                                    <div class="flex items-start gap-1.5 group/item">
                                        <div class="mt-1 w-1.5 h-1.5 rounded-full bg-[#0AD1C8] shrink-0"></div>
                                        <span class="text-[10px] font-bold text-[#213A57] leading-tight hover:text-[#0B6477] transition-colors" title="{{ $enrollment->course->title }}">
                                            {{ $enrollment->course->title }}
                                        </span>
                                    </div>
                                @empty
                                    <span class="text-[10px] text-gray-300 italic">Sin cursos aprobados</span>
                                @endforelse
                                @if($student->enrollments_count > 2)
                                    <span class="text-[9px] font-bold text-[#0AD1C8] bg-[#E0F9F6] px-2 py-0.5 rounded-full w-fit mt-1">
                                        + {{ $student->enrollments_count - 2 }} cursos adicionales
                                    </span>
                                @endif
                            </div>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase {{ $student->status === 'active' ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-500' }}">
                                <span class="w-1 h-1 rounded-full {{ $student->status === 'active' ? 'bg-green-500' : 'bg-gray-400' }}"></span>
                                {{ $student->status === 'active' ? 'Activo' : 'Inactivo' }}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <div class="flex items-center justify-end gap-1">
                                @if(Auth::user()->hasPermission('students.manage'))
                                    <button type="button" onclick='openEditModal(@json($student))' class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-amber-500 hover:bg-amber-50 transition-all shadow-sm bg-white border border-gray-100" title="Editar">
                                        <i class="ph-bold ph-pencil-simple"></i>
                                    </button>
                                    <button type="button" onclick="confirmResetPass({{ $student->id }})" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-blue-500 hover:bg-blue-50 transition-all shadow-sm bg-white border border-gray-100" title="Restablecer Contraseña">
                                        <i class="ph-bold ph-key"></i>
                                    </button>
                                    <button type="button" onclick="confirmResetPin({{ $student->id }})" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-purple-500 hover:bg-purple-50 transition-all shadow-sm bg-white border border-gray-100" title="Restablecer PIN">
                                        <i class="ph-bold ph-numpad"></i>
                                    </button>
                                    <button type="button" onclick="confirmDelete({{ $student->id }})" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all shadow-sm bg-white border border-gray-100" title="Eliminar">
                                        <i class="ph-bold ph-trash"></i>
                                    </button>
                                    <button type="button" onclick="openHistoryModal({{ $student->id }}, '{{ $student->name }}')" class="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-[#0AD1C8] hover:bg-[#E0F9F6] transition-all shadow-sm bg-white border border-gray-100 ml-1" title="Historial y Avance">
                                        <i class="ph-bold ph-clock-counter-clockwise text-lg"></i>
                                    </button>

                                    <form id="form-reset-{{ $student->id }}" action="{{ route('admin.students.reset_password', $student->id) }}" method="POST" class="hidden">@csrf @method('PUT')</form>
                                    <form id="form-reset-pin-{{ $student->id }}" action="{{ route('admin.students.reset_pin', $student->id) }}" method="POST" class="hidden">@csrf @method('PUT')</form>
                                    <form id="form-delete-{{ $student->id }}" action="{{ route('admin.students.destroy', $student->id) }}" method="POST" class="hidden">@csrf @method('DELETE')</form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="px-6 py-12 text-center text-gray-400">No se encontraron estudiantes aprobados.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-4 border-t border-gray-100 bg-gray-50/50">{{ $students->links() }}</div>
    </div>

    <!-- MODAL DE EDICIÓN -->
    <div id="modal-student" class="fixed inset-0 z-50 hidden" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/90 backdrop-blur-sm transition-opacity" onclick="closeModal()"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <form id="studentForm" action="" method="POST" enctype="multipart/form-data" class="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden z-10">
                @csrf @method('PUT')
                <div class="bg-[#213A57] p-6 text-white flex justify-between items-center">
                    <h3 class="text-xl font-bold">Editar Estudiante</h3>
                    <button type="button" onclick="closeModal()" class="hover:opacity-70"><i class="ph-bold ph-x text-xl"></i></button>
                </div>
                <div class="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="md:col-span-2 flex justify-center mb-4">
                         <div class="relative group">
                            <img id="avatar-preview-large" src="" class="w-24 h-24 rounded-full border-4 border-gray-100 object-cover shadow-lg">
                            <input type="file" name="avatar_file" id="avatar_file" class="hidden" onchange="previewFileAvatar(this)">
                            <button type="button" onclick="document.getElementById('avatar_file').click()" class="absolute bottom-0 right-0 bg-[#0AD1C8] text-white p-1.5 rounded-full shadow hover:bg-[#08b3ab]"><i class="ph-bold ph-camera"></i></button>
                         </div>
                    </div>
                    <div class="md:col-span-1">
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Nombre Completo</label>
                        <input type="text" id="name" name="name" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                    </div>
                    <div class="md:col-span-1">
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">CI / NIT</label>
                        <input type="text" id="ci_nit" name="ci_nit" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Correo Electrónico</label>
                        <input type="email" id="email" name="email" required class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">WhatsApp</label>
                        <input type="text" id="phone" name="phone" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-gray-400 uppercase mb-1">Estado de Cuenta</label>
                        <select id="status" name="status" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0AD1C8] outline-none text-sm bg-gray-50">
                            <option value="active">Activo</option>
                            <option value="inactive">Inactivo</option>
                        </select>
                    </div>
                    <div class="md:col-span-2 flex justify-end gap-3 pt-4 border-t">
                        <button type="button" onclick="closeModal()" class="px-6 py-2.5 text-gray-500 font-bold">Cancelar</button>
                        <button type="submit" class="px-6 py-2.5 bg-[#213A57] text-white font-bold rounded-xl shadow-lg">Guardar Cambios</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL DE CREDENCIALES -->
    <div id="modal-credentials" class="fixed inset-0 z-[60] hidden" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#0B6477]/90 backdrop-blur-md transition-opacity"></div>
        <div class="relative z-10 flex min-h-full items-center justify-center p-4">
            <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
                <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600"><i class="ph-fill ph-key text-3xl"></i></div>
                <h3 class="text-2xl font-bold text-[#213A57] mb-2">Nuevas Credenciales</h3>
                <div class="bg-gray-50 rounded-xl p-4 text-left border border-gray-200 mb-6 space-y-2 font-mono text-sm">
                    <div class="flex justify-between"><span class="text-gray-400">Usuario:</span><span class="text-[#213A57] font-bold" id="cred-email">...</span></div>
                    <div id="row-pass" class="flex justify-between hidden"><span class="text-gray-400">Contraseña:</span><span class="text-[#0AD1C8] font-bold text-lg" id="cred-pass">...</span></div>
                    <div id="row-pin" class="flex justify-between hidden"><span class="text-gray-400">PIN:</span><span class="text-purple-600 font-bold text-lg" id="cred-pin">...</span></div>
                </div>
                <button onclick="copyToClipboard()" class="w-full py-3 bg-[#25D366] text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 mb-2"><i class="ph-fill ph-whatsapp-logo text-xl"></i> Copiar Datos</button>
                <button onclick="document.getElementById('modal-credentials').classList.add('hidden')" class="w-full py-3 bg-gray-100 text-gray-600 font-bold rounded-xl">Cerrar</button>
            </div>
        </div>
    </div>

    <!-- MODAL HISTORIAL ACADÉMICO -->
    <div id="modal-history" class="fixed inset-0 z-[70] hidden" role="dialog" aria-modal="true">
        <div class="fixed inset-0 bg-[#213A57]/95 backdrop-blur-md transition-opacity" onclick="closeHistoryModal()"></div>
        <div class="relative z-10 flex min-h-full items-center justify-center p-4">
            <div class="bg-white rounded-3xl shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col max-h-[90vh]">
                <div class="bg-[#213A57] p-6 text-white flex justify-between items-center shrink-0">
                    <div>
                        <h3 class="text-xl font-bold flex items-center gap-2">
                            <i class="ph-bold ph-student"></i>
                            Historial de <span id="history-student-name" class="text-[#0AD1C8]">...</span>
                        </h3>
                        <p class="text-xs text-gray-400 mt-1">Gestiona el avance y certificados manualmente.</p>
                    </div>
                    <button onclick="closeHistoryModal()" class="hover:opacity-70 bg-white/10 p-2 rounded-full"><i class="ph-bold ph-x text-xl"></i></button>
                </div>
                
                <div class="flex-1 overflow-y-auto p-6 bg-gray-50" id="history-container">
                    <div class="text-center py-12 text-gray-400">
                        <i class="ph-duotone ph-spinner-gap text-4xl animate-spin mb-2"></i>
                        <p>Cargando historial...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true });

        @if(session('success')) Toast.fire({ icon: 'success', title: '{{ session('success') }}' }); @endif
        @if(session('credentials_modal'))
            document.addEventListener('DOMContentLoaded', function() {
                const data = @json(session('credentials_modal'));
                document.getElementById('cred-email').innerText = data.email;
                if (data.password) {
                    document.getElementById('row-pass').classList.remove('hidden');
                    document.getElementById('cred-pass').innerText = data.password;
                    window.tempCredentialType = 'password';
                }
                if (data.pin) {
                    document.getElementById('row-pin').classList.remove('hidden');
                    document.getElementById('cred-pin').innerText = data.pin;
                    window.tempCredentialType = 'pin';
                }
                window.tempCredentialData = data;
                document.getElementById('modal-credentials').classList.remove('hidden');
            });
        @endif

        function confirmResetPass(id) { Swal.fire({ title: '¿Restablecer Contraseña?', text: 'Se generará una nueva clave aleatoria.', icon: 'warning', showCancelButton: true, confirmButtonColor: '#213A57', confirmButtonText: 'Sí, generar' }).then((r) => { if(r.isConfirmed) document.getElementById('form-reset-'+id).submit(); }); }
        function confirmResetPin(id) { Swal.fire({ title: '¿Restablecer PIN?', text: 'Se generará un nuevo PIN de seguridad.', icon: 'question', showCancelButton: true, confirmButtonColor: '#7c3aed', confirmButtonText: 'Sí, generar PIN' }).then((r) => { if(r.isConfirmed) document.getElementById('form-reset-pin-'+id).submit(); }); }
        function confirmDelete(id) { Swal.fire({ title: '¿Eliminar Estudiante?', text: 'Se borrará el acceso y todo su historial.', icon: 'error', showCancelButton: true, confirmButtonColor: '#d33', confirmButtonText: 'Sí, borrar' }).then((r) => { if(r.isConfirmed) document.getElementById('form-delete-'+id).submit(); }); }

        function openEditModal(student) {
            document.getElementById('studentForm').action = "{{ route('admin.students.update', ':id') }}".replace(':id', student.id);
            document.getElementById('name').value = student.name;
            document.getElementById('email').value = student.email;
            document.getElementById('ci_nit').value = student.ci_nit || '';
            document.getElementById('phone').value = student.phone || '';
            document.getElementById('status').value = student.status;
            let avatarSrc = student.avatar_url ? (student.avatar_url.startsWith('http') ? student.avatar_url : "{{ asset('') }}" + student.avatar_url) : "https://ui-avatars.com/api/?name=" + encodeURIComponent(student.name);
            document.getElementById('avatar-preview-large').src = avatarSrc;
            document.getElementById('modal-student').classList.remove('hidden');
        }
        function closeModal() { document.getElementById('modal-student').classList.add('hidden'); }
        function previewFileAvatar(input) { if (input.files && input.files[0]) { const reader = new FileReader(); reader.onload = e => { document.getElementById('avatar-preview-large').src = e.target.result; }; reader.readAsDataURL(input.files[0]); } }
        function copyToClipboard() {
            const data = window.tempCredentialData || {};
            const type = window.tempCredentialType || 'password';
            const email = document.getElementById('cred-email').innerText;
            let text = '';
            if (type === 'password') text = `Hola ${data.name}, tu contraseña: ${document.getElementById('cred-pass').innerText}`;
            else if (type === 'pin') text = `Hola ${data.name}, tu PIN: ${document.getElementById('cred-pin').innerText}`;
            navigator.clipboard.writeText(text).then(() => Toast.fire({ icon: 'success', title: 'Copiado' }));
        }

        let currentStudentId = null;

        function openHistoryModal(id, name) {
            currentStudentId = id;
            document.getElementById('history-student-name').innerText = name;
            document.getElementById('modal-history').classList.remove('hidden');
            loadHistory(id);
        }

        function closeHistoryModal() {
            document.getElementById('modal-history').classList.add('hidden');
            currentStudentId = null;
        }

        function loadHistory(id) {
            const container = document.getElementById('history-container');
            container.innerHTML = '<div class="text-center py-12 text-gray-400"><i class="ph-duotone ph-spinner-gap text-4xl animate-spin mb-2"></i><p>Cargando historial...</p></div>';

            fetch(`/admin/estudiantes/${id}/historial`)
                .then(res => res.json())
                .then(data => {
                    if (data.length === 0) {
                        container.innerHTML = '<div class="text-center py-12 text-gray-400 bg-white rounded-xl border border-dashed border-gray-300"><i class="ph-duotone ph-folder-open text-4xl mb-2"></i><p>Este estudiante no tiene cursos inscritos.</p></div>';
                        return;
                    }

                    let html = '<div class="space-y-4" x-data="{ activeCourse: null }">';
                    data.forEach((course, index) => {
                        const progress = course.progress_percent;
                        const certUrl = course.certificate_uuid ? `/validar/certificado/${course.certificate_uuid}` : '#';
                        const isOpen = index === 0 ? 'true' : 'false';

                        let topicsHtml = '';
                        course.topics.forEach(topic => {
                            let lessonsHtml = '';
                            topic.lessons.forEach(lesson => {
                                const isChecked = lesson.is_completed ? 'checked' : '';
                                const typeIcon = lesson.type === 'quiz' ? 'ph-list-checks text-purple-500' : 'ph-play-circle text-blue-500';
                                
                                lessonsHtml += `
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100 hover:border-blue-200 transition-colors">
                                        <div class="flex items-center gap-3">
                                            <i class="ph-fill ${typeIcon} text-xl"></i>
                                            <div>
                                                <p class="text-sm font-bold text-gray-700">${lesson.title}</p>
                                                <p class="text-[10px] text-gray-400 uppercase">${lesson.type}</p>
                                            </div>
                                        </div>
                                        <label class="flex items-center gap-2 cursor-pointer">
                                            <span class="text-xs font-bold text-gray-500">Completado</span>
                                            <input type="checkbox" ${isChecked} onchange="toggleLesson(${lesson.id}, this.checked)" class="w-5 h-5 text-[#0AD1C8] rounded focus:ring-[#0AD1C8] cursor-pointer">
                                        </label>
                                    </div>
                                `;
                            });

                            topicsHtml += `
                                <div class="mb-4 last:mb-0">
                                    <h5 class="text-xs font-bold text-gray-400 uppercase mb-2 ml-1">${topic.title}</h5>
                                    <div class="space-y-2">${lessonsHtml}</div>
                                </div>
                            `;
                        });

                        let finalEvalHtml = '';
                        let evalConfig = course.evaluation_config;
                        if (typeof evalConfig === 'string') {
                            try { evalConfig = JSON.parse(evalConfig); } catch(e) { evalConfig = {}; }
                        }
                        evalConfig = evalConfig || {};

                        const isExam = evalConfig.final_exam_enabled == true || evalConfig.final_exam_enabled == 1 || evalConfig.final_exam_enabled == '1';
                        const isProject = evalConfig.final_project_enabled == true || evalConfig.final_project_enabled == 1 || evalConfig.final_project_enabled == '1';

                        // --- NUEVA LÓGICA DE CONDICIÓN PARA CERTIFICADO ---
                        const minScore = parseInt(evalConfig.min_score || 51); // Valor por defecto 51
                        const finalScore = course.final_score;
                        const isCertAvailable = (progress === 100) || (finalScore !== null && finalScore >= minScore);

                        if (isExam || isProject) {
                            const finalTitle = (isExam && !isProject) ? 'Examen Final' : ((!isExam && isProject) ? 'Trabajo Final' : 'Evaluación Final');
                            const hasAttempt = finalScore !== null;
                            
                            let statusIcon = '';
                            let statusText = '';
                            let resetButton = '';
                            let detailsHtml = '';

                            if (!hasAttempt) {
                                statusText = '<span class="text-gray-400 font-bold text-xs">Pendiente</span>';
                                statusIcon = '<i class="ph-bold ph-circle text-gray-300 text-xl"></i>';
                            } else {
                                if (finalScore >= minScore) {
                                    statusText = `<span class="text-green-600 font-bold text-xs">Aprobado (${finalScore} pts)</span>`;
                                    statusIcon = '<i class="ph-fill ph-check-circle text-green-500 text-xl"></i>';
                                } else {
                                    statusText = `<span class="text-red-500 font-bold text-xs">Reprobado (${finalScore} pts)</span>`;
                                    statusIcon = '<i class="ph-fill ph-x-circle text-red-500 text-xl"></i>';
                                    
                                    resetButton = `
                                        <button onclick="confirmResetEval(${currentStudentId}, ${course.course_id})" 
                                                class="ml-3 px-3 py-1 bg-white border border-red-200 text-red-500 text-xs font-bold rounded-lg hover:bg-red-50 transition-colors flex items-center gap-1 shadow-sm" 
                                                title="Borrar intento y permitir rendir de nuevo">
                                            <i class="ph-bold ph-arrow-counter-clockwise"></i> Reiniciar
                                        </button>
                                    `;
                                }
                            }

                            if (isExam && evalConfig.final_exam_data && evalConfig.final_exam_data.questions && evalConfig.final_exam_data.questions.length > 0) {
                                let questionsList = '';
                                let studentAnswers = course.exam_answers;
                                if (typeof studentAnswers === 'string') {
                                    try { studentAnswers = JSON.parse(studentAnswers); } catch(e) { studentAnswers = {}; }
                                }
                                studentAnswers = studentAnswers || {}; 

                                evalConfig.final_exam_data.questions.forEach((q, qIdx) => {
                                    let studentAns = null;
                                    let key = 'q_' + qIdx;
                                    
                                    if(studentAnswers[key] !== undefined) {
                                        studentAns = studentAnswers[key];
                                    } else if (studentAnswers[qIdx] !== undefined) {
                                        studentAns = studentAnswers[qIdx];
                                    }

                                    if(Array.isArray(studentAns)) studentAns = studentAns.join(', ');
                                    if(studentAns === null) studentAns = 'Sin respuesta';

                                    const correctAns = Array.isArray(q.correct) ? q.correct.join(', ') : (q.correct || 'Texto Libre');
                                    
                                    let isCorrectVisual = false;
                                    if(q.type !== 'open' && String(studentAns).trim() == String(correctAns).trim()) isCorrectVisual = true;
                                    
                                    const ansColor = isCorrectVisual ? 'text-green-600 bg-green-50 border-green-200' : 'text-red-500 bg-red-50 border-red-200';
                                    const icon = isCorrectVisual ? '<i class="ph-bold ph-check text-green-600"></i>' : '<i class="ph-bold ph-x text-red-500"></i>';

                                    questionsList += `
                                        <div class="mb-3 pb-3 border-b border-gray-200 last:border-0 last:pb-0 last:mb-0">
                                            <p class="font-bold text-gray-700 text-[11px] mb-2"><span class="text-purple-600">P${qIdx+1}.</span> ${q.title || q.text} <span class="text-gray-400 font-normal">(${q.points} pts)</span></p>
                                            
                                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                                                <div class="p-2 rounded border ${ansColor} flex items-start gap-2">
                                                    <div class="mt-0.5 shrink-0">${icon}</div>
                                                    <div>
                                                        <span class="font-bold block opacity-70 mb-0.5">Estudiante:</span> 
                                                        <span class="font-bold">${studentAns}</span>
                                                    </div>
                                                </div>
                                                <div class="p-2 rounded border border-gray-200 bg-gray-50 flex items-start gap-2">
                                                    <div class="mt-0.5 shrink-0"><i class="ph-bold ph-check-circle text-gray-400"></i></div>
                                                    <div>
                                                        <span class="font-bold text-gray-500 block opacity-70 mb-0.5">Correcta:</span> 
                                                        <span class="text-gray-700">${correctAns}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>`;
                                });

                                detailsHtml = `
                                    <div x-data="{ showDetails: false }" class="mt-3 w-full">
                                        <button @click="showDetails = !showDetails" class="text-[10px] font-bold text-purple-600 hover:underline flex items-center gap-1 mb-2">
                                            <i class="ph-bold" :class="showDetails ? 'ph-caret-up' : 'ph-caret-down'"></i> Ver Detalles y Respuestas
                                        </button>
                                        <div x-show="showDetails" class="bg-white p-4 rounded-lg border border-gray-200 shadow-inner">
                                            ${questionsList}
                                        </div>
                                    </div>
                                `;
                            }

                            finalEvalHtml = `
                                <div class="mt-4 pt-4 border-t border-gray-100">
                                    <div class="p-3 bg-purple-50 rounded-lg border-l-4 border-purple-500">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap-3">
                                                <div class="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center text-white shrink-0 shadow-sm">
                                                    <i class="ph-fill ph-trophy"></i>
                                                </div>
                                                <div>
                                                    <p class="text-sm font-bold text-gray-800">${finalTitle}</p>
                                                    <p class="text-[10px] text-purple-600 uppercase font-bold">Requisito Obligatorio</p>
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                ${statusText}
                                                ${statusIcon}
                                                ${resetButton}
                                            </div>
                                        </div>
                                        ${detailsHtml}
                                    </div>
                                </div>
                            `;
                        }

                        html += `
                            <div class="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm transition-all hover:shadow-md" x-data="{ open: ${isOpen} }">
                                <div @click="open = !open" class="p-4 flex items-center justify-between cursor-pointer bg-white hover:bg-gray-50 transition-colors">
                                    <div class="flex items-center gap-4">
                                        <div class="w-12 h-12 rounded-lg bg-[#E0F9F6] flex items-center justify-center text-[#0AD1C8] font-bold text-lg border border-[#0AD1C8]/20">
                                            ${progress}%
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-[#213A57] text-lg">${course.course_title}</h4>
                                            <p class="text-xs text-gray-500">Inscrito: ${course.enrolled_at}</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-4">
                                        ${(course.certificate_uuid && isCertAvailable) ? 
                                            `<a href="${certUrl}" target="_blank" @click.stop class="px-4 py-2 bg-[#0AD1C8] hover:bg-[#0B6477] text-white text-xs font-bold rounded-lg shadow-lg flex items-center gap-2 transition-all">
                                                <i class="ph-bold ph-certificate"></i> Ver Certificado
                                            </a>` : 
                                            `<span class="text-xs text-gray-400 italic bg-gray-100 px-3 py-1 rounded-full">Sin Certificado</span>`
                                        }
                                        <i class="ph-bold ph-caret-down text-gray-400 transition-transform duration-300" :class="{ 'rotate-180': open }"></i>
                                    </div>
                                </div>
                                <div x-show="open" x-collapse class="border-t border-gray-100 p-6 bg-white">
                                    ${topicsHtml}
                                    ${finalEvalHtml}
                                </div>
                            </div>
                        `;
                    });
                    html += '</div>';
                    container.innerHTML = html;
                });
        }

        function toggleLesson(lessonId, isCompleted) {
            if (!currentStudentId) return;

            fetch('{{ route("admin.students.toggle_progress") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    student_id: currentStudentId,
                    lesson_id: lessonId,
                    completed: isCompleted ? 1 : 0
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    Toast.fire({ icon: 'success', title: 'Progreso actualizado' });
                    // Si se completó el curso y se generó certificado, recargamos para mostrar el botón
                    if (data.new_progress === 100 && data.certificate_uuid) {
                        loadHistory(currentStudentId);
                    }
                }
            })
            .catch(err => console.error(err));
        }

        function confirmResetEval(studentId, courseId) {
            Swal.fire({
                title: '¿Dar otra oportunidad?',
                text: "Se borrará la calificación del examen/trabajo final y el estudiante podrá realizarlo nuevamente. Esta acción es irreversible.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sí, reiniciar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`/admin/estudiantes/${studentId}/reset-eval/${courseId}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        }
                    })
                    .then(async response => {
                        if (!response.ok) {
                            const text = await response.text();
                            try {
                                const json = JSON.parse(text);
                                throw new Error(json.message || 'Error del servidor');
                            } catch (e) {
                                throw new Error('Error del servidor: ' + response.statusText);
                            }
                        }
                        return response.json();
                    })
                    .then(data => {
                        if(data.success) {
                            Toast.fire({ icon: 'success', title: 'Evaluación reiniciada exitosamente' });
                            loadHistory(studentId); // Recargar el modal para ver cambios
                        } else {
                            Swal.fire('Error', data.message || 'No se pudo reiniciar la evaluación.', 'error');
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        Swal.fire('Error', err.message || 'Ocurrió un error de conexión.', 'error');
                    });
                }
            })
        }
    </script>
</x-layouts.admin>