<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Aula Virtual - YATI' }}</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Inter', sans-serif; }
        
        /* Scrollbar oscura para la lista de lecciones */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #1e293b; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #475569; }

        /* Estilos personalizados para el reproductor */
        .aspect-video { aspect-ratio: 16 / 9; }
    </style>
</head>
<body class="bg-[#0f172a] text-gray-300 antialiased overflow-hidden h-screen flex flex-col">

    <!-- NAVBAR SUPERIOR (Compacto) -->
    <header class="h-16 bg-[#1e293b] border-b border-gray-800 flex items-center justify-between px-4 shrink-0 z-20">
        <div class="flex items-center gap-4">
            <a href="{{ route('student.dashboard') }}" class="text-gray-400 hover:text-white transition-colors flex items-center gap-2 text-sm font-medium">
                <i class="ph-bold ph-arrow-left"></i> Volver al Panel
            </a>
            <div class="h-6 w-px bg-gray-700 mx-2"></div>
            <h1 class="text-white font-bold text-sm md:text-base truncate max-w-md hidden md:block">
                {{ $courseTitle ?? 'Supervisor SSOMA: Seguridad Industrial' }}
            </h1>
        </div>

        <div class="flex items-center gap-4">
            
            <!-- Botón Menu Móvil (Solo visible en celular) -->
            <button class="lg:hidden text-white p-2" onclick="document.getElementById('playlist-sidebar').classList.toggle('hidden')">
                <i class="ph-bold ph-list text-2xl"></i>
            </button>
        </div>
    </header>

    <!-- CONTENIDO PRINCIPAL (Flex Row) -->
    <div class="flex-1 flex overflow-hidden relative">
        
        <!-- ZONA DE VIDEO (Izquierda / Centro) -->
        <main class="flex-1 overflow-y-auto scroll-smooth bg-[#0f172a] relative">
            {{ $slot }}
        </main>

        <!-- SIDEBAR DE LECCIONES (Derecha) -->
        <aside id="playlist-sidebar" class="w-full lg:w-96 bg-[#1e293b] border-l border-gray-800 flex flex-col absolute lg:static inset-0 z-10 hidden lg:flex">
            
            <!-- Título del Contenido -->
            <div class="p-4 border-b border-gray-800 bg-[#1e293b]">
                <h3 class="font-bold text-white text-sm uppercase tracking-wider mb-1">Contenido del Curso</h3>
                <p class="text-xs text-gray-500">5 Módulos • 40 Lecciones</p>
            </div>

            <!-- Lista Scrollable -->
            <div class="flex-1 overflow-y-auto p-2 space-y-4">
                {{ $sidebar }}
            </div>

        </aside>

    </div>

</body>
</html>