<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'YATI - Aprende sin límites' }}</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        
        .text-gradient {
            background: linear-gradient(to right, #0B6477, #0AD1C8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-primary {
            background: linear-gradient(135deg, #0B6477 0%, #0AD1C8 100%);
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px -10px rgba(10, 209, 200, 0.5);
        }
        
        .fade-in-up { animation: fadeInUp 0.8s ease-out forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
        
        .no-scrollbar::-webkit-scrollbar { display: none; }
    </style>
</head>
<body class="bg-gray-50 text-slate-800 antialiased selection:bg-[#0AD1C8] selection:text-white">

    <nav class="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 transition-all duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                
                <!-- Logotipo -->
                <a href="{{ route('home') }}" class="flex items-center gap-2 group">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0AD1C8] to-[#45DFB1] flex items-center justify-center text-[#213A57] shadow-lg shadow-[#0AD1C8]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-student text-xl"></i>
                    </div>
                    <span class="font-bold text-2xl tracking-wide text-[#213A57]">YATI</span>
                </a>

                <!-- Menú Central -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="{{ route('home') }}" class="text-gray-600 hover:text-[#0B6477] font-medium transition-colors">Inicio</a>
                    <a href="{{ route('catalog') }}" class="text-gray-600 hover:text-[#0B6477] font-medium transition-colors">Cursos</a>
                    <a href="{{ route('about') }}" class="text-gray-600 hover:text-[#0B6477] font-medium transition-colors">Nosotros</a>
                    <a href="{{ route('contact') }}" class="text-gray-600 hover:text-[#0B6477] font-medium transition-colors">Contacto</a>
                </div>

                <!-- Botones Dinámicos (Inteligentes) -->
                <div class="hidden md:flex items-center gap-4">
                    @auth('web')
                        <!-- Vista para Administradores -->
                        <span class="text-xs font-bold text-gray-400 uppercase tracking-widest mr-2">Admin</span>
                        <a href="{{ route('admin.dashboard') }}" class="btn-primary text-white px-6 py-2.5 rounded-xl font-medium shadow-lg flex items-center gap-2">
                            <i class="ph-bold ph-layout"></i>
                            Panel Control
                        </a>
                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="p-2.5 text-gray-400 hover:text-red-500 transition-colors" title="Cerrar Sesión">
                                <i class="ph-bold ph-sign-out text-xl"></i>
                            </button>
                        </form>

                    @elseauth('student')
                        <!-- Vista para Estudiantes -->
                        <a href="{{ route('student.dashboard') }}" class="btn-primary text-white px-6 py-2.5 rounded-xl font-medium shadow-lg flex items-center gap-2">
                            <i class="ph-bold ph-student"></i>
                            Mi Aprendizaje
                        </a>
                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="p-2.5 text-gray-400 hover:text-red-500 transition-colors" title="Cerrar Sesión">
                                <i class="ph-bold ph-sign-out text-xl"></i>
                            </button>
                        </form>

                    @else
                        <!-- Vista para Invitados (No logueados) -->
                        <a href="{{ route('login') }}" class="text-[#213A57] font-semibold hover:text-[#0AD1C8] transition-colors">Ingresar</a>
                        <a href="{{ route('login') }}" class="btn-primary text-white px-6 py-2.5 rounded-xl font-medium shadow-lg shadow-[#0AD1C8]/20">
                            Crear cuenta
                        </a>
                    @endauth
                </div>

                <!-- Botón Móvil -->
                <div class="md:hidden flex items-center gap-4">
                    @auth('student')
                         <a href="{{ route('student.dashboard') }}" class="text-[#0AD1C8] text-2xl"><i class="ph-bold ph-user-circle"></i></a>
                    @endauth
                    <button class="text-[#213A57] text-2xl"><i class="ph ph-list"></i></button>
                </div>
            </div>
        </div>
    </nav>

    <main class="min-h-screen">
        {{ $slot }}
    </main>

    <footer class="bg-[#213A57] text-white pt-16 pb-8 border-t border-[#45DFB1]/20 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-[#0AD1C8] opacity-5 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <div class="col-span-1 md:col-span-1">
                    <div class="flex items-center gap-2 mb-4">
                        <div class="w-8 h-8 rounded-lg bg-[#0AD1C8] flex items-center justify-center text-[#213A57]">
                            <i class="ph-bold ph-student text-lg"></i>
                        </div>
                        <span class="font-bold text-xl tracking-wide">YATI</span>
                    </div>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        Transformamos el aprendizaje en Latinoamérica con tecnología y pasión.
                    </p>
                </div>
                
                <div>
                    <h4 class="font-bold mb-4 text-[#45DFB1]">Plataforma</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="{{ route('catalog') }}" class="hover:text-white transition-colors">Cursos</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Precios</a></li>
                        <li><a href="{{ route('contact') }}" class="hover:text-white transition-colors">Para Empresas</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-bold mb-4 text-[#45DFB1]">Comunidad</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li><a href="https://www.facebook.com/pachaconsultingbolivia" class="hover:text-white transition-colors">Facebook</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Blog</a></li>
                        <li><a href="https://seminario.pachabol.com/" class="hover:text-white transition-colors">Pachabol Live</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold mb-4 text-[#45DFB1]">Contacto</h4>
                    <ul class="space-y-2 text-sm text-gray-400">
                        <li class="flex items-center gap-2"><i class="ph ph-map-pin"></i> Av. Raul Salmon NRO. 26 Of. 7, Zona 12 de Octubre. Ciudad de El Alto. La Paz, Bolivia.</li>
                        <li class="flex items-center gap-2"><i class="ph ph-envelope"></i> capacitaciones@pachabol.com</li>
                        <li class="flex items-center gap-2"><i class="ph ph-whatsapp-logo"></i> +591 62529911</li>
                    </ul>
                </div>
            </div>
            
            <div class="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-sm text-gray-500">© 2026 YATI. Desarollado por Deivid Chipana.</p>
                <div class="flex gap-4">
                    <a href="#" class="text-gray-400 hover:text-[#0AD1C8] transition-colors"><i class="ph-fill ph-facebook-logo text-xl"></i></a>
                    <a href="#" class="text-gray-400 hover:text-[#0AD1C8] transition-colors"><i class="ph-fill ph-instagram-logo text-xl"></i></a>
                    <a href="#" class="text-gray-400 hover:text-[#0AD1C8] transition-colors"><i class="ph-fill ph-linkedin-logo text-xl"></i></a>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>