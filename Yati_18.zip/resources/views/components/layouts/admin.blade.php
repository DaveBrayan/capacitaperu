<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'YATI - Plataforma Educativa' }}</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #0B6477; border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #213A57; }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 antialiased selection:bg-[#0AD1C8] selection:text-white">

    <div class="min-h-screen flex relative overflow-hidden">
        
        <!-- Decoración de fondo -->
        <div class="absolute top-0 left-0 w-96 h-96 bg-[#45DFB1] opacity-10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none"></div>
        <div class="absolute bottom-0 right-0 w-96 h-96 bg-[#0AD1C8] opacity-10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 z-0 pointer-events-none"></div>

        <!-- SIDEBAR -->
        <aside class="w-72 bg-[#213A57] text-white flex flex-col z-10 shadow-2xl transition-all duration-300">
            <div class="h-24 flex items-center px-8 border-b border-[#2d4b6e]">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#0AD1C8] to-[#45DFB1] flex items-center justify-center shadow-lg shadow-[#0AD1C8]/20">
                        <i class="ph ph-student text-xl text-[#213A57] font-bold"></i>
                    </div>
                    <div>
                        <h1 class="font-bold text-2xl tracking-wide">YATI</h1>
                        <p class="text-[10px] text-[#80ED99] tracking-widest uppercase opacity-80">Admin Panel</p>
                    </div>
                </div>
            </div>

            <nav class="flex-1 px-4 py-8 space-y-2 overflow-y-auto">
                
                <!-- SECCIÓN PRINCIPAL (Siempre visible) -->
                <p class="px-4 text-xs font-semibold text-[#45DFB1] uppercase tracking-wider mb-2 opacity-70">Principal</p>
                
                <a href="{{ route('admin.dashboard') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.dashboard') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                    @if(request()->routeIs('admin.dashboard'))
                        <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                        <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                    @endif
                    <i class="ph ph-squares-four text-xl {{ request()->routeIs('admin.dashboard') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                    <span class="font-medium">Dashboard</span>
                </a>

                <!-- SECCIÓN GESTIÓN ACADÉMICA -->
                {{-- Solo mostrar título si tiene permiso para ver ALGO de esto --}}
                @if(Auth::user()->hasPermission('courses.view') || Auth::user()->hasPermission('students.view') || Auth::user()->hasPermission('instructors.view') || Auth::user()->hasPermission('categories.view'))
                    <p class="px-4 text-xs font-semibold text-[#45DFB1] uppercase tracking-wider mt-8 mb-2 opacity-70">Gestión Académica</p>

                    @if(Auth::user()->hasPermission('courses.view'))
                    <a href="{{ route('admin.courses.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.courses.*') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.courses.*'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-graduation-cap text-xl {{ request()->routeIs('admin.courses.*') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Cursos</span>
                    </a>
                    @endif

                    @if(Auth::user()->hasPermission('students.view'))
                    <a href="{{ route('admin.students.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.students.index') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.students.index'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-users text-xl {{ request()->routeIs('admin.students.index') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Estudiantes</span>
                    </a>
                    @endif

                    @if(Auth::user()->hasPermission('instructors.view'))
                    <a href="{{ route('admin.instructors.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.instructors.index') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.instructors.index'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-chalkboard-teacher text-xl {{ request()->routeIs('admin.instructors.index') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Docentes</span>
                    </a>
                    @endif

                    @if(Auth::user()->hasPermission('categories.view'))
                    <a href="{{ route('admin.categories.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.categories.index') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.categories.index'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-tag text-xl {{ request()->routeIs('admin.categories.index') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Categorías</span>
                    </a>
                    @endif
                @endif

                <!-- SECCIÓN INSCRIPCIÓN -->
                @if(Auth::user()->hasPermission('enrollments.view'))
                    <p class="px-4 text-xs font-semibold text-[#45DFB1] uppercase tracking-wider mt-8 mb-2 opacity-70">Inscripción</p>

                    <a href="{{ route('admin.enrollments.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.enrollments.*') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.enrollments.*'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-user-list text-xl {{ request()->routeIs('admin.enrollments.*') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Inscritos</span>
                    </a>
                @endif

                <!-- SECCIÓN MARKETING -->
                @if(Auth::user()->hasPermission('promotions.view'))
                    <p class="px-4 text-xs font-semibold text-[#45DFB1] uppercase tracking-wider mt-8 mb-2 opacity-70">Marketing</p>

                    <a href="{{ route('admin.promotions.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.promotions.*') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.promotions.*'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-ticket text-xl {{ request()->routeIs('admin.promotions.*') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Promociones</span>
                    </a>
                @endif

                <!-- SECCIÓN ADMINISTRACIÓN -->
                @if(Auth::user()->hasPermission('users.view'))
                    <p class="px-4 text-xs font-semibold text-[#45DFB1] uppercase tracking-wider mt-8 mb-2 opacity-70">Administración</p>
                    
                    <a href="{{ route('admin.staff.index') }}" class="group flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 relative overflow-hidden {{ request()->routeIs('admin.staff.index') ? 'bg-[#0B6477] text-white' : 'hover:bg-[#0B6477] text-gray-300 hover:text-white' }}">
                        @if(request()->routeIs('admin.staff.index'))
                            <div class="absolute inset-0 bg-gradient-to-r from-[#0AD1C8]/20 to-transparent pointer-events-none"></div>
                            <div class="absolute left-0 top-0 bottom-0 w-1 bg-[#0AD1C8]"></div>
                        @endif
                        <i class="ph ph-user-gear text-xl {{ request()->routeIs('admin.staff.index') ? 'text-[#80ED99]' : 'group-hover:text-[#80ED99]' }}"></i>
                        <span class="font-medium">Equipo / Staff</span>
                    </a>
                @endif
            </nav>

            <!-- Perfil Footer -->
            <div class="p-4 border-t border-[#2d4b6e] bg-[#1a2e45]">
                <div class="flex items-center gap-3">
                    <img src="https://ui-avatars.com/api/?name={{ urlencode(Auth::user()->name ?? 'Admin') }}&background=0AD1C8&color=fff" alt="Admin" class="w-10 h-10 rounded-full border-2 border-[#45DFB1] object-cover">
                    <div class="flex-1 min-w-0">
                        <h4 class="text-sm font-semibold text-white truncate">{{ Auth::user()->name ?? 'Invitado' }}</h4>
                        <p class="text-xs text-gray-400 capitalize">{{ Auth::user()->role ?? 'Usuario' }}</p>
                    </div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-gray-400 hover:text-[#80ED99] transition-colors"><i class="ph ph-sign-out text-xl"></i></button>
                    </form>
                </div>
            </div>
        </aside>

        <!-- CONTENIDO -->
        <div class="flex-1 flex flex-col h-screen overflow-hidden z-10">
            <!-- Header simple -->
            <header class="h-20 bg-white/80 backdrop-blur-md border-b border-gray-100 flex items-center justify-between px-8 z-20 sticky top-0">
                <h2 class="font-semibold text-xl text-[#213A57]">{{ $header ?? 'Panel' }}</h2>
                <div class="flex items-center gap-6">
                    <button class="relative p-2 rounded-full hover:bg-gray-100 text-gray-500"><i class="ph ph-bell text-xl"></i></button>
                </div>
            </header>

            <main class="flex-1 overflow-y-auto p-8 scroll-smooth">
                {{ $slot }}
            </main>
        </div>
    </div>
</body>
</html>