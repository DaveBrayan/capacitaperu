<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'YATI - Estudiante' }}</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Poppins', sans-serif; }
        .fade-in-up { animation: fadeInUp 0.5s ease-out forwards; opacity: 0; transform: translateY(20px); }
        @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #0AD1C8; }
    </style>
</head>
<body class="bg-gray-50 text-slate-800 antialiased selection:bg-[#0AD1C8] selection:text-white">

    <div class="min-h-screen flex relative overflow-hidden">
        
        <!-- SIDEBAR (Azul Base) -->
        <aside class="w-64 bg-[#213A57] text-white flex flex-col shadow-xl z-20 fixed h-full transition-all">
            
            <!-- Logo -->
            <div class="h-20 flex items-center px-6 border-b border-white/10">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-lg bg-[#0AD1C8] flex items-center justify-center text-[#213A57] shadow-lg shadow-[#0AD1C8]/20">
                        <i class="ph-bold ph-student text-lg"></i>
                    </div>
                    <span class="font-bold text-xl tracking-wide">YATI</span>
                </div>
            </div>

            <!-- Navegación -->
            <nav class="flex-1 px-3 py-6 space-y-1 overflow-y-auto">
                <p class="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Mi Progreso</p>
                
                <a href="{{ route('student.dashboard') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg {{ request()->routeIs('student.dashboard') ? 'bg-white/10 text-white border-[#0AD1C8]' : 'text-slate-300 hover:bg-white/10 hover:text-white border-transparent hover:border-[#0AD1C8]' }} font-medium group transition-all border-l-4">
                    <i class="ph-fill ph-squares-four text-lg {{ request()->routeIs('student.dashboard') ? 'text-[#0AD1C8]' : 'group-hover:scale-110 transition-transform' }}"></i>
                    <span>Mi Aprendizaje</span>
                </a>

                <!-- <a href="{{ route('student.certificates') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg {{ request()->routeIs('student.certificates') ? 'bg-white/10 text-white border-[#0AD1C8]' : 'text-slate-300 hover:bg-white/10 hover:text-white border-transparent hover:border-[#0AD1C8]' }} font-medium group transition-all border-l-4">
                    <i class="ph ph-certificate text-lg {{ request()->routeIs('student.certificates') ? 'text-[#0AD1C8]' : 'group-hover:scale-110 transition-transform' }}"></i>
                    <span>Mis Certificados</span>
                </a>
                
                <a href="{{ route('student.wishlist') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg {{ request()->routeIs('student.wishlist') ? 'bg-white/10 text-white border-[#0AD1C8]' : 'text-slate-300 hover:bg-white/10 hover:text-white border-transparent hover:border-[#0AD1C8]' }} font-medium group transition-all border-l-4">
                    <i class="ph ph-heart text-lg {{ request()->routeIs('student.wishlist') ? 'text-[#0AD1C8]' : 'group-hover:scale-110 transition-transform' }}"></i>
                    <span>Lista de Deseos</span>
                </a> -->

                <p class="px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider mt-6 mb-3">Cuenta</p>

                <a href="{{ route('student.profile') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg {{ request()->routeIs('student.profile') ? 'bg-white/10 text-white border-[#0AD1C8]' : 'text-slate-300 hover:bg-white/10 hover:text-white border-transparent hover:border-[#0AD1C8]' }} font-medium group transition-all border-l-4">
                    <i class="ph ph-user-circle text-lg {{ request()->routeIs('student.profile') ? 'text-[#0AD1C8]' : 'group-hover:scale-110 transition-transform' }}"></i>
                    <span>Mi Perfil</span>
                </a>
                
                <a href="{{ route('student.billing') }}" class="flex items-center gap-3 px-3 py-2.5 rounded-lg {{ request()->routeIs('student.billing') ? 'bg-white/10 text-white border-[#0AD1C8]' : 'text-slate-300 hover:bg-white/10 hover:text-white border-transparent hover:border-[#0AD1C8]' }} font-medium group transition-all border-l-4">
                    <i class="ph ph-credit-card text-lg {{ request()->routeIs('student.billing') ? 'text-[#0AD1C8]' : 'group-hover:scale-110 transition-transform' }}"></i>
                    <span>Mis Compras</span>
                </a>
            </nav>

            <!-- Perfil Usuario Mini (Dinámico) -->
            @php
                $user = Auth::guard('student')->user();
                $avatar = $user->avatar_url 
                    ? (Str::startsWith($user->avatar_url, 'http') ? $user->avatar_url : asset($user->avatar_url))
                    : 'https://ui-avatars.com/api/?name='.urlencode($user->name).'&background=0AD1C8&color=fff';
            @endphp
            <div class="p-4 border-t border-white/10 bg-[#1a2e45]">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3 overflow-hidden">
                        <img src="{{ $avatar }}" class="w-9 h-9 rounded-full border-2 border-[#0AD1C8] p-0.5 object-cover shrink-0">
                        <div class="overflow-hidden">
                            <h4 class="text-sm font-semibold text-white truncate" title="{{ $user->name }}">{{ $user->name }}</h4>
                            <p class="text-[10px] text-[#0AD1C8] uppercase tracking-wide">Estudiante</p>
                        </div>
                    </div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-slate-400 hover:text-white transition-colors p-1" title="Cerrar Sesión">
                            <i class="ph ph-sign-out text-lg"></i>
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        <!-- CONTENIDO PRINCIPAL -->
        <div class="flex-1 flex flex-col min-h-screen ml-64 bg-gray-50">
            <!-- Header Transparente -->
            <header class="h-20 bg-white/80 backdrop-blur-md border-b border-gray-100 flex items-center justify-between px-8 z-10 sticky top-0">
                <h2 class="font-bold text-xl text-[#213A57]">
                    {{ $header ?? 'Panel de Estudiante' }}
                </h2>
                
                <div class="flex items-center gap-4">
                    <!-- Buscador Simple -->
                    <div class="hidden md:flex relative">
                        <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="text" placeholder="Buscar en mis cursos..." class="pl-10 pr-4 py-2 rounded-full border-none bg-gray-100 focus:bg-white focus:ring-2 focus:ring-[#0AD1C8] transition-all w-64 text-sm">
                    </div>
                    
                    <!-- Boton de notificación -->
                    <button class="w-10 h-10 rounded-full border border-gray-200 text-gray-500 hover:bg-gray-50 hover:text-[#0B6477] transition-colors flex items-center justify-center relative group">
                        <span class="absolute top-2 right-2.5 w-2 h-2 rounded-full bg-red-500 ring-2 ring-white group-hover:animate-ping"></span>
                        <i class="ph ph-bell text-xl"></i>
                    </button>
                </div>
            </header>

            <!-- Main con fondo gris suave y padding -->
            <main class="flex-1 p-8 overflow-y-auto scroll-smooth relative">
                <!-- Decoración sutil de fondo -->
                <div class="absolute top-0 right-0 w-96 h-96 bg-[#0AD1C8] opacity-5 rounded-full blur-3xl pointer-events-none -translate-y-1/2 translate-x-1/2"></div>
                
                {{ $slot }}
            </main>
        </div>
    </div>
</body>
</html>