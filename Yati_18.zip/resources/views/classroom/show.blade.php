<x-layouts.classroom>
    <x-slot name="courseTitle">{{ $course->title }}</x-slot>
    
    <script src="//unpkg.com/alpinejs" defer></script>
    <style>
        [x-cloak] { display: none !important; }
        @media (min-width: 1024px) {
            aside { width: 22rem !important; } 
            main { flex: 1; min-width: 0; }
        }
        .prose table { width: 100%; border-collapse: collapse; margin: 1em 0; }
        .prose th, .prose td { border: 1px solid #475569; padding: 8px; text-align: left; }
        .prose th { bg-color: #1e293b; }
    </style>

    <!-- --- LÓGICA DE CÁLCULO GLOBAL (Para usar en Main y Sidebar) --- -->
    @php
        // 1. Configuración y Valores Base
        $evalConfig = $course->evaluation_config ?? [];
        $minScore = $evalConfig['min_score'] ?? 51; // Nota mínima por defecto 51
        $attWeight = $evalConfig['attendance_weight'] ?? 20;
        $examWeight = $evalConfig['final_assessment_weight'] ?? 80;
        
        $isExamEnabled = $evalConfig['final_exam_enabled'] ?? false;
        $isProjectEnabled = $evalConfig['final_project_enabled'] ?? false;
        $hasExam = $isExamEnabled || $isProjectEnabled;

        // 2. Cálculo de Puntos
        // Asistencia
        $attPoints = ($attendancePercent * $attWeight) / 100;
        
        // Evaluación Final
        $rawScore = 0;      
        $maxPossible = 100; 

        if ($isProjectEnabled) {
            $rawScore = $projectSubmission->score ?? 0;
            $maxPossible = $evalConfig['final_project_data']['score'] ?? 100;
        } elseif ($isExamEnabled) {
            $rawScore = $finalExamScore ?? 0;
            $maxPossible = $examTotalPoints ?? 100; // Viene del controller
        }
        if ($maxPossible <= 0) $maxPossible = 100;

        // Ponderación
        $examPoints = ($rawScore / $maxPossible) * $examWeight;
        $finalTotalScore = round($attPoints + $examPoints, 2);

        // 3. Estados
        // ¿Ya intentó/entregó?
        $hasAttempted = ($isExamEnabled && $finalExamScore !== null) || 
                        ($isProjectEnabled && $projectSubmission && $projectSubmission->status !== 'pending');

        $passedScore = $finalTotalScore >= $minScore;
        $passedAttendance = $attendancePercent >= 100;
        
        // Estado Oficial de Aprobación
        $isApproved = $passedScore; 

        // LÓGICA CRÍTICA: Obtención del Certificado
        // Si hay examen/trabajo, DEBE tener nota aprobatoria (passedScore).
        // Si NO hay examen, basta con completar el contenido (progress 100).
        $canGetCertificate = false;
        if ($hasExam) {
            $canGetCertificate = $passedScore;
        } else {
            $canGetCertificate = $progress == 100;
        }

        // Buscar Certificado existente
        $certificate = \App\Models\Certificate::where('student_id', auth('student')->id())
                        ->where('course_id', $course->id)
                        ->first();
        
        // URL directa al visualizador
        $certUrl = $certificate ? route('certificate.verify', $certificate->uuid) : '#';
        
        // Lógica de fechas de liberación
        $certConfig = $course->certificate_template ?? [];
        $releaseMode = $certConfig['release_mode'] ?? 'completion';
        $releaseDate = isset($certConfig['release_date']) ? \Carbon\Carbon::parse($certConfig['release_date']) : null;
        $isDateReleased = true;
        if ($releaseMode === 'scheduled' && $releaseDate) {
            $isDateReleased = now()->greaterThanOrEqualTo($releaseDate);
        }
        
        $showModal = $canGetCertificate && session('success');
        $canDownload = $canGetCertificate && $isDateReleased && $certificate;
    @endphp

    <!-- MENSAJES FLASH -->
    @if(session('success'))
        <div class="fixed top-20 right-8 z-50 bg-green-500 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce-in border border-green-400">
            <i class="ph-bold ph-check-circle text-2xl"></i>
            <div><p class="font-bold">¡Excelente!</p><p class="text-sm">{{ session('success') }}</p></div>
        </div>
    @endif
    @if(session('warning'))
        <div class="fixed top-20 right-8 z-50 bg-amber-500 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-bounce-in border border-amber-400">
            <i class="ph-bold ph-warning text-2xl"></i>
            <div><p class="font-bold">Atención</p><p class="text-sm">{{ session('warning') }}</p></div>
        </div>
    @endif

    <!-- 1. BARRA DE TÍTULO Y NAVEGACIÓN -->
    <div class="px-6 py-4 border-b border-gray-800 bg-[#0f172a] flex flex-col md:flex-row justify-between items-center gap-4 sticky top-0 z-30 shadow-md">
        <div class="flex-1">
            <h2 class="text-lg md:text-xl font-bold text-white leading-tight">
                @if(request('mode') === 'planning' || (!request('lesson') && request('mode') !== 'final'))
                    <span class="text-[#0AD1C8]"><i class="ph-bold ph-house"></i> Inicio del Curso</span>
                @elseif(request('mode') === 'final')
                    Evaluación Final
                @else
                    {{ $currentLesson->title }}
                @endif
            </h2>
            <p class="text-xs text-gray-500 font-medium uppercase tracking-wide truncate">
                @if(request('mode') === 'planning' || (!request('lesson') && request('mode') !== 'final'))
                    Planificación y Comunidad
                @elseif(request('mode') === 'final')
                    Cierre del Curso
                @else
                    {{ $currentLesson->topic->title ?? 'Módulo General' }}
                @endif
            </p>
        </div>
        
        <div class="flex items-center gap-2 shrink-0">
            @if(request('mode') !== 'planning' && request('mode') !== 'final' && request('lesson'))
                @if($prevLesson)
                    <a href="{{ route('classroom.show', ['course' => $course->slug, 'lesson' => $prevLesson->slug ?? $prevLesson->id]) }}" 
                       class="px-3 py-2 rounded-lg border border-gray-700 text-gray-400 hover:text-white hover:border-gray-500 transition-colors flex items-center gap-2 text-xs font-bold">
                        <i class="ph-bold ph-caret-left"></i> Anterior
                    </a>
                @endif

                @if($nextLesson)
                    <a href="{{ route('classroom.show', ['course' => $course->slug, 'lesson' => $nextLesson->slug ?? $nextLesson->id]) }}" 
                       class="px-4 py-2 rounded-lg bg-[#0AD1C8] hover:bg-[#0B6477] text-[#0f172a] font-bold transition-colors flex items-center gap-2 text-xs shadow-lg shadow-[#0AD1C8]/20">
                        Siguiente <i class="ph-bold ph-caret-right"></i>
                    </a>
                @else
                    @if($hasExam)
                        <a href="?mode=final" class="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center gap-2 text-xs shadow-lg">
                            Ir al Examen Final <i class="ph-bold ph-star"></i>
                        </a>
                    @endif
                @endif
            @endif
        </div>
    </div>

    <!-- 2. CONTENIDO PRINCIPAL -->
    <div class="p-6 overflow-y-auto h-[calc(100vh-80px)] custom-scrollbar bg-[#0B1120]">
        
        <!-- --- MODO: PLANIFICACIÓN (DEFAULT) --- -->
        @if(request('mode') === 'planning' || (!request('lesson') && request('mode') !== 'final'))
            <div class="max-w-5xl mx-auto space-y-8 animate-fade-in-up">
                
                @if(!empty($course->metadata['whatsapp_group']))
                <div class="bg-gradient-to-r from-green-600 to-emerald-700 rounded-2xl p-6 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden group border border-green-500/30">
                    <div class="absolute -right-10 -top-10 text-white/10 group-hover:scale-110 transition-transform duration-500">
                        <i class="ph-fill ph-whatsapp-logo text-9xl"></i>
                    </div>
                    
                    <div class="relative z-10">
                        <h3 class="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                            <i class="ph-bold ph-chats-circle"></i> Comunidad Oficial
                        </h3>
                        <p class="text-green-50 text-sm max-w-lg leading-relaxed">
                            Únete al grupo de WhatsApp para recibir anuncios importantes, resolver dudas en tiempo real y conectar con tus compañeros.
                        </p>
                    </div>
                    <a href="{{ $course->metadata['whatsapp_group'] }}" target="_blank" class="relative z-10 px-8 py-3 bg-white text-green-700 font-bold rounded-xl shadow-lg hover:bg-green-50 hover:shadow-xl transition-all transform hover:-translate-y-1 flex items-center gap-2 whitespace-nowrap">
                        <i class="ph-fill ph-whatsapp-logo text-xl"></i>
                        Unirme al Grupo
                    </a>
                </div>
                @endif

                <div class="bg-[#1e293b] rounded-2xl border border-gray-700 p-8 shadow-2xl">
                    <div class="border-b border-gray-700 pb-4 mb-6 flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-[#0AD1C8]/10 flex items-center justify-center text-[#0AD1C8]">
                            <i class="ph-bold ph-calendar-check text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white">Cronograma y Planificación</h3>
                            <p class="text-xs text-gray-400">Detalles y organización del curso.</p>
                        </div>
                    </div>
                    
                    @if(!empty($course->metadata['planning']))
                        <div class="prose prose-invert prose-lg max-w-none text-gray-300">
                            {!! $course->metadata['planning'] !!}
                        </div>
                    @else
                        <div class="text-center py-16 text-gray-500 bg-gray-800/50 rounded-xl border border-dashed border-gray-700">
                            <i class="ph-duotone ph-calendar-x text-4xl mb-3 block opacity-50"></i>
                            <p>No hay información de planificación disponible por el momento.</p>
                        </div>
                    @endif

                    @php
                        $firstTopic = $course->topics->first();
                        $firstLesson = $firstTopic ? $firstTopic->lessons->first() : null;
                    @endphp
                    
                    @if($firstLesson)
                    <div class="mt-8 pt-6 border-t border-gray-700 flex justify-center">
                        <a href="{{ route('classroom.show', ['course' => $course->slug, 'lesson' => $firstLesson->slug ?? $firstLesson->id]) }}" 
                           class="px-8 py-4 bg-[#0AD1C8] hover:bg-[#0B6477] text-[#0f172a] font-bold text-lg rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 flex items-center gap-2">
                            Comenzar Curso Ahora <i class="ph-bold ph-arrow-right"></i>
                        </a>
                    </div>
                    @endif
                </div>
            </div>

        <!-- --- MODO: EVALUACIÓN FINAL --- -->
        @elseif(request('mode') === 'final')

            <div class="max-w-4xl mx-auto space-y-12">
                
                <!-- Resultados (Si ya intentó la evaluación o entregó proyecto) -->
                @if($hasAttempted)
                    <div class="p-12 text-center bg-gray-800 rounded-2xl border border-gray-700 shadow-2xl" x-data="{ showCertModal: {{ $showModal ? 'true' : 'false' }} }">
                        <!-- Icono Principal -->
                        <div class="w-24 h-24 {{ $isApproved ? 'bg-gradient-to-br from-green-400 to-emerald-600 shadow-green-500/20' : 'bg-gradient-to-br from-red-400 to-red-600 shadow-red-500/20' }} rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl border-4 border-gray-800">
                            <i class="ph-fill {{ $isApproved ? 'ph-medal' : 'ph-x-circle' }} text-5xl text-white"></i>
                        </div>

                        <!-- Título Estado -->
                        <h2 class="text-3xl font-bold text-white mb-2">{{ $isApproved ? '¡Curso Aprobado!' : 'Curso No Aprobado' }}</h2>
                        
                        <!-- Tarjeta de Notas -->
                        <div class="max-w-md mx-auto bg-gray-900 rounded-xl p-6 border border-gray-700 mt-6 mb-8">
                            <!-- Fila Asistencia -->
                            <div class="flex justify-between items-center mb-2 text-sm text-gray-400">
                                <span>Asistencia ({{ $attendancePercent }}%)</span>
                                <span class="font-bold text-white">+{{ round($attPoints, 1) }} pts</span>
                            </div>
                            
                            <!-- Fila Evaluación -->
                            <div class="flex justify-between items-center mb-4 text-sm text-gray-400 border-b border-gray-700 pb-2">
                                <span>Evaluación ({{ $rawScore }}/{{ $maxPossible }})</span>
                                <span class="font-bold text-white">+{{ round($examPoints, 1) }} pts</span>
                            </div>
                            
                            <!-- Fila Nota Final -->
                            <div class="flex justify-between items-center text-lg">
                                <span class="font-bold text-gray-300">Nota Final</span>
                                <span class="font-black {{ $isApproved ? 'text-green-400' : 'text-red-400' }}">{{ round($finalTotalScore) }} <span class="text-xs text-gray-500">/ 100</span></span>
                            </div>
                            <div class="text-xs text-center mt-3 text-gray-500">Nota mínima requerida: {{ $minScore }}</div>
                        </div>

                        <!-- Botones de Acción -->
                        <div class="flex flex-col items-center gap-3">
                            <!-- BOTÓN VER CERTIFICADO -->
                            @if($canDownload)
                                <!-- Se usa certUrl que apunta al visualizador público -->
                                <a href="{{ $certUrl }}" target="_blank" class="px-6 py-3 bg-[#0AD1C8] hover:bg-[#0B6477] text-[#0f172a] font-bold rounded-xl transition-all shadow-lg flex items-center gap-2">
                                    <i class="ph-bold ph-certificate"></i> Ver Certificado
                                </a>
                            @elseif($isApproved && !$isDateReleased)
                                <div class="px-6 py-3 bg-blue-900/30 border border-blue-500/30 text-blue-200 rounded-xl text-sm flex items-center gap-2"><i class="ph-bold ph-calendar-check"></i> Certificado disponible el {{ $releaseDate->locale('es')->isoFormat('D [de] MMMM, YYYY') }}</div>
                            @endif
                            
                            <a href="{{ route('student.dashboard') }}" class="text-gray-400 hover:text-white underline text-sm mt-2">Volver al Dashboard</a>
                        </div>

                        <!-- Modal Alpine (Felicidades) -->
                        <div x-show="showCertModal" style="display: none;" class="fixed inset-0 z-[100] flex items-center justify-center px-4">
                            <div class="absolute inset-0 bg-black/80 backdrop-blur-sm" @click="showCertModal = false" x-transition.opacity></div>
                            <div class="bg-white rounded-3xl p-8 max-w-sm w-full relative z-10 text-center shadow-2xl" 
                                 x-transition:enter="transition ease-out duration-300"
                                 x-transition:enter-start="opacity-0 scale-90 translate-y-4"
                                 x-transition:enter-end="opacity-100 scale-100 translate-y-0">
                                <button @click="showCertModal = false" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                                    <i class="ph-bold ph-x text-xl"></i>
                                </button>
                                <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-5 animate-bounce-in">
                                    <i class="ph-duotone ph-confetti text-4xl text-green-600"></i>
                                </div>
                                <h3 class="text-2xl font-black text-[#213A57] mb-2">¡Felicidades!</h3>
                                <p class="text-gray-600 text-sm mb-6 leading-relaxed">
                                    Has completado el curso satisfactoriamente.
                                    <br>
                                    <span class="font-bold text-[#0AD1C8] text-lg block mt-2">{{ round($finalTotalScore) }} pts</span>
                                </p>
                                <div class="space-y-3">
                                    @if($canDownload)
                                        <a href="{{ $certUrl }}" target="_blank" class="block w-full py-3.5 bg-[#213A57] text-white font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                                            Ver Certificado Ahora
                                        </a>
                                    @else
                                        <div class="p-3 bg-blue-50 text-blue-800 text-xs rounded-lg border border-blue-100">
                                            Tu certificado estará disponible para descarga el día: <br>
                                            <b>{{ $releaseDate ? $releaseDate->locale('es')->isoFormat('D [de] MMMM, YYYY') : 'Fecha pendiente' }}</b>
                                        </div>
                                    @endif
                                    <button @click="showCertModal = false" class="block w-full py-3 text-gray-500 font-bold text-sm hover:text-gray-800 transition-colors">
                                        Cerrar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    
                    <!-- BLOQUE EXAMEN (SIN INTENTOS PREVIOS) -->
                    @if($isExamEnabled)
                        @php
                            $eData = $evalConfig['final_exam_data'] ?? [];
                            $examQuestions = $eData['questions'] ?? [];
                            $eStartDate = isset($eData['start_date']) && $eData['start_date'] ? \Carbon\Carbon::parse($eData['start_date']) : null;
                            $eEndDate = isset($eData['end_date']) && $eData['end_date'] ? \Carbon\Carbon::parse($eData['end_date']) : null;
                            $now = now()->subHours(4);
                            $eIsBefore = $eStartDate && $now->lessThan($eStartDate);
                            $eIsAfter = $eEndDate && $now->greaterThan($eEndDate);
                            $eIsEnabled = !$eIsBefore && !$eIsAfter;
                        @endphp
                        <div class="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden shadow-2xl" x-data="{ examStarted: false }">
                            <div x-show="!examStarted" class="transition-opacity duration-300">
                                <div class="bg-gradient-to-r from-purple-900 to-indigo-900 p-8 text-center">
                                    <div class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm border border-white/20">
                                        <i class="ph-duotone ph-exam text-3xl text-white"></i>
                                    </div>
                                    <h2 class="text-2xl font-bold text-white mb-2">Examen Final de Certificación</h2>
                                    <p class="text-gray-300 text-sm max-w-xl mx-auto">Cuestionario automático. Tienes <b>un solo intento</b>.</p>
                                </div>
                                <div class="p-8">
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                                        <div class="bg-gray-700/50 p-4 rounded-xl border border-gray-700 text-center">
                                            <p class="text-xs text-gray-400 uppercase font-bold mb-1">Apertura</p>
                                            <p class="text-white font-medium capitalize">{{ $eStartDate ? $eStartDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') : 'Ahora' }}</p>
                                        </div>
                                        <div class="bg-gray-700/50 p-4 rounded-xl border border-gray-700 text-center">
                                            <p class="text-xs text-gray-400 uppercase font-bold mb-1">Cierre</p>
                                            <p class="text-white font-medium capitalize">{{ $eEndDate ? $eEndDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') : 'Sin límite' }}</p>
                                        </div>
                                    </div>
                                    <div class="flex justify-center">
                                        @if($eIsEnabled)
                                            <button @click="examStarted = true" class="px-8 py-3 bg-[#0AD1C8] hover:bg-[#0B6477] text-[#0f172a] font-bold rounded-xl transition-all shadow-lg flex items-center gap-2">
                                                Comenzar Examen <i class="ph-bold ph-arrow-right"></i>
                                            </button>
                                        @elseif($eIsBefore)
                                            <div class="p-4 bg-amber-900/20 border border-amber-800 rounded-xl text-amber-500">Examen disponible el {{ $eStartDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') }}</div>
                                        @elseif($eIsAfter)
                                            <div class="p-4 bg-red-900/20 border border-red-800 rounded-xl text-red-400">El examen ha finalizado.</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div x-show="examStarted" x-cloak class="bg-gray-800 transition-opacity duration-300">
                                <div class="bg-gray-900/50 p-6 border-b border-gray-700 flex justify-between items-center">
                                    <h3 class="font-bold text-white text-lg"><i class="ph-bold ph-pencil-circle text-purple-500"></i> Preguntas</h3>
                                    <span class="bg-gray-700 text-white text-xs font-bold px-3 py-1 rounded-full">{{ count($examQuestions) }} Preguntas</span>
                                </div>
                                <form action="{{ route('classroom.final.exam', $course->slug) }}" method="POST" class="p-8 space-y-10">
                                    @csrf
                                    @foreach($examQuestions as $index => $q)
                                        <div class="space-y-4">
                                            <p class="text-white font-medium text-base">
                                                <span class="text-[#0AD1C8] font-bold">{{ $index + 1 }}.</span> {{ $q['title'] ?? $q['text'] }}
                                                <span class="text-xs text-gray-500">({{ $q['points'] ?? 0 }} pts)</span>
                                            </p>
                                            <div class="ml-6 space-y-2">
                                                @if(in_array($q['type'], ['single', 'multiple']))
                                                    @foreach(explode(',', $q['options']) as $opt)
                                                        <label class="flex items-center gap-3 p-4 rounded-xl border border-gray-700 bg-gray-800 hover:bg-gray-700 cursor-pointer transition-colors group">
                                                            <input type="{{ $q['type'] === 'single' ? 'radio' : 'checkbox' }}" name="q_{{ $index }}{{ $q['type'] === 'multiple' ? '[]' : '' }}" value="{{ trim($opt) }}" class="text-purple-600 focus:ring-purple-600 bg-gray-900 border-gray-600 w-5 h-5">
                                                            <span class="text-sm text-gray-300 group-hover:text-white font-medium">{{ trim($opt) }}</span>
                                                        </label>
                                                    @endforeach
                                                @else
                                                    <textarea name="q_{{ $index }}" rows="3" class="w-full bg-gray-900 border border-gray-700 rounded-xl p-4 text-white"></textarea>
                                                @endif
                                            </div>
                                        </div>
                                        @if(!$loop->last) <div class="border-t border-gray-700/50"></div> @endif
                                    @endforeach
                                    <div class="pt-8 border-t border-gray-700 flex justify-end gap-4">
                                        <button type="submit" class="px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-xl shadow-lg">Finalizar y Enviar</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    @endif

                    <!-- BLOQUE TRABAJO FINAL (SIN INTENTOS PREVIOS) -->
                    @if($isProjectEnabled)
                        @php
                            $pData = $evalConfig['final_project_data'] ?? [];
                            $pStartDate = isset($pData['start_date']) && $pData['start_date'] ? \Carbon\Carbon::parse($pData['start_date']) : null;
                            $pEndDate = isset($pData['end_date']) && $pData['end_date'] ? \Carbon\Carbon::parse($pData['end_date']) : null;
                            $now = now()->subHours(4);
                            $pIsBefore = $pStartDate && $now->lessThan($pStartDate);
                            $pIsAfter = $pEndDate && $now->greaterThan($pEndDate);
                            $pIsEnabled = !$pIsBefore && !$pIsAfter;
                            $maxFiles = $pData['max_files'] ?? 1;
                            $maxSize = $pData['max_file_size'] ?? 5;
                            $fileTypes = $pData['file_types'] ?? [];
                            $accept = '';
                            if(in_array('pdf', $fileTypes)) $accept .= '.pdf,';
                            if(in_array('images', $fileTypes)) $accept .= 'image/*,';
                            if(in_array('zip', $fileTypes)) $accept .= '.zip,.rar,';
                            if(in_array('docx', $fileTypes)) $accept .= '.doc,.docx,';
                        @endphp

                        <div class="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden shadow-2xl mt-8">
                            <div class="bg-gradient-to-r from-orange-900 to-red-900 p-8 text-center">
                                <div class="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm border border-white/20">
                                    <i class="ph-duotone ph-briefcase text-3xl text-white"></i>
                                </div>
                                <h2 class="text-2xl font-bold text-white mb-2">Trabajo Final Práctico</h2>
                                <p class="text-gray-300 text-sm max-w-xl mx-auto">Sube los archivos requeridos para la evaluación de tu proyecto.</p>
                            </div>

                            <div class="p-8">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                                    <div class="bg-gray-700/50 p-4 rounded-xl border border-gray-700 flex items-center justify-between">
                                        <div><p class="text-xs text-gray-400 uppercase font-bold mb-1">Inicio</p><p class="text-white font-medium capitalize">{{ $pStartDate ? $pStartDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') : 'Ahora' }}</p></div>
                                        <i class="ph-bold ph-calendar-check text-orange-500 text-xl"></i>
                                    </div>
                                    <div class="bg-gray-700/50 p-4 rounded-xl border border-gray-700 flex items-center justify-between">
                                        <div><p class="text-xs text-gray-400 uppercase font-bold mb-1">Límite</p><p class="text-white font-medium capitalize">{{ $pEndDate ? $pEndDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') : 'Sin límite' }}</p></div>
                                        <i class="ph-bold ph-calendar-x text-orange-500 text-xl"></i>
                                    </div>
                                </div>

                                <div class="bg-gray-900/50 rounded-xl p-6 border border-gray-700 mb-8">
                                    <h4 class="font-bold text-orange-400 mb-4 flex items-center gap-2"><i class="ph-bold ph-info"></i> Instrucciones</h4>
                                    <div class="prose prose-invert prose-sm max-w-none text-gray-300">{!! $pData['instructions'] ?? 'No hay instrucciones específicas.' !!}</div>
                                    @if(isset($evalConfig['project_file']))
                                        @php 
                                            $guidePath = str_replace('storage/', '', $evalConfig['project_file']);
                                            $guideUrl = route('media.show', ['filename' => $guidePath]);
                                        @endphp
                                        <div class="mt-6 pt-4 border-t border-gray-700">
                                            <a href="{{ $guideUrl }}" target="_blank" class="inline-flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-orange-400 text-sm font-bold rounded-lg transition-colors border border-orange-500/30">
                                                <i class="ph-bold ph-file-doc"></i> Descargar Guía / Material Base
                                            </a>
                                        </div>
                                    @endif
                                </div>

                                @if($pIsEnabled)
                                    <form action="{{ route('classroom.final.project', $course->slug) }}" method="POST" enctype="multipart/form-data" class="bg-gray-900 rounded-xl p-6 border border-gray-700">
                                        @csrf
                                        <label class="block text-sm font-bold text-gray-300 mb-4 flex items-center gap-2">
                                            <i class="ph-bold ph-upload-simple text-orange-500"></i> Sube tu trabajo aquí
                                        </label>
                                        <div class="relative group">
                                            <input type="file" name="files[]" 
                                                   class="block w-full text-sm text-gray-400 file:mr-4 file:py-3 file:px-6 file:rounded-lg file:border-0 file:text-sm file:font-bold file:bg-orange-600 file:text-white hover:file:bg-orange-700 cursor-pointer border border-gray-600 rounded-xl bg-gray-800 focus:outline-none focus:border-orange-500 transition-all"
                                                   {{ $maxFiles > 1 ? 'multiple' : '' }}
                                                   accept="{{ $accept }}">
                                        </div>
                                        <div class="mt-4 p-3 bg-gray-800 rounded-lg flex flex-wrap gap-4 text-xs text-gray-500 border border-gray-700">
                                            <span class="flex items-center gap-1"><i class="ph-bold ph-files"></i> Máx: {{ $maxFiles }} archivo(s)</span>
                                            <span class="flex items-center gap-1"><i class="ph-bold ph-hard-drives"></i> Máx: {{ $maxSize }}MB</span>
                                            <span class="flex items-center gap-1"><i class="ph-bold ph-file-text"></i> Tipos: {{ empty($fileTypes) ? 'Todos' : implode(', ', $fileTypes) }}</span>
                                        </div>
                                        <div class="mt-6 flex justify-end">
                                            <button type="submit" class="px-8 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-xl shadow-lg transition-all flex items-center gap-2 hover:scale-105 transform">
                                                <i class="ph-bold ph-paper-plane-right"></i> Enviar Trabajo Final
                                            </button>
                                        </div>
                                    </form>
                                @elseif($pIsBefore)
                                    <div class="p-6 bg-amber-900/20 border border-amber-800 rounded-xl text-amber-500 text-center"><i class="ph-bold ph-clock text-2xl mb-2 block"></i> La entrega estará habilitada el {{ $pStartDate->locale('es')->isoFormat('D [de] MMMM YYYY [a las] h:mm a') }}.</div>
                                @elseif($pIsAfter)
                                    <div class="p-6 bg-red-900/20 border border-red-800 rounded-xl text-red-400 text-center"><i class="ph-bold ph-x-circle text-2xl mb-2 block"></i> El plazo de entrega ha finalizado.</div>
                                @endif
                            </div>
                        </div>
                    @endif

                @endif
            </div>

        <!-- --- MODO: VIDEO --- -->
        @elseif($currentLesson->type === 'video')
             <div class="max-w-6xl mx-auto mb-8">
                <div class="bg-black w-full aspect-video rounded-xl shadow-2xl relative overflow-hidden border border-gray-800 group">
                    @if($currentLesson->video_url)
                        @php
                            $videoId = Str::afterLast($currentLesson->video_url, '/');
                            if(Str::contains($videoId, 'watch?v=')) $videoId = Str::after($videoId, 'watch?v=');
                        @endphp
                        <iframe class="w-full h-full" src="https://www.youtube.com/embed/{{ $videoId }}?rel=0&modestbranding=1" title="Video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    @else
                        <div class="w-full h-full flex items-center justify-center text-gray-500"><p>Video no disponible</p></div>
                    @endif
                </div>
                <div class="mt-4 flex justify-end">
                    @php $isLessonCompleted = in_array($currentLesson->id, $completedLessonIds ?? []); @endphp
                    @if($isLessonCompleted)
                         <span class="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 border border-green-500/20 rounded-lg text-sm font-bold"><i class="ph-bold ph-check-circle text-lg"></i> Completada</span>
                    @else
                         <span class="inline-flex items-center gap-2 px-4 py-2 bg-gray-800 text-gray-500 border border-gray-700 rounded-lg text-sm font-bold opacity-60 cursor-help"><i class="ph-bold ph-clock text-lg"></i> Pendiente</span>
                    @endif
                </div>
            </div>
            <div class="max-w-6xl mx-auto">
                <div class="border-b border-gray-800 mb-6"><button class="pb-3 border-b-2 border-[#0AD1C8] text-[#0AD1C8] font-bold text-sm uppercase tracking-wider">Descripción</button></div>
                <div class="prose prose-invert prose-sm max-w-none text-gray-300">{!! $currentLesson->content !!}</div>
            </div>

        <!-- --- MODO: QUIZ --- -->
        @elseif($currentLesson->type === 'quiz')
            @php
                $quizData = $currentLesson->attachments ?? [];
                $questions = $quizData['questions'] ?? [];
            @endphp
            <div class="max-w-3xl mx-auto">
                <div class="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden shadow-xl">
                    <div class="bg-gray-900/50 p-6 border-b border-gray-700 flex justify-between items-center">
                        <h3 class="font-bold text-white text-lg"><i class="ph-bold ph-list-checks text-[#0AD1C8]"></i> Quiz del Módulo</h3>
                        <span class="bg-gray-700 text-white text-xs font-bold px-3 py-1 rounded-full">{{ count($questions) }} Preguntas</span>
                    </div>
                    <form action="{{ route('classroom.quiz.submit', [$course->slug, $currentLesson->slug ?? $currentLesson->id]) }}" method="POST" class="p-6 space-y-8">
                        @csrf
                        @foreach($questions as $index => $q)
                            <div class="space-y-3">
                                <p class="text-white font-medium text-sm flex gap-2">
                                    <span class="text-[#0AD1C8] font-bold">{{ $index + 1 }}.</span> {{ $q['title'] ?? $q['text'] }}
                                </p>
                                <div class="ml-6 space-y-2">
                                    @if(in_array($q['type'], ['single', 'multiple']))
                                        @foreach(explode(',', $q['options']) as $opt)
                                            <label class="flex items-center gap-3 p-3 rounded-lg border border-gray-700 bg-gray-800/50 hover:bg-gray-700 cursor-pointer">
                                                <input type="{{ $q['type'] === 'single' ? 'radio' : 'checkbox' }}" name="q_{{ $index }}[]" value="{{ trim($opt) }}" class="text-[#0AD1C8] bg-gray-900 border-gray-600">
                                                <span class="text-sm text-gray-300">{{ trim($opt) }}</span>
                                            </label>
                                        @endforeach
                                    @else
                                        <textarea name="q_{{ $index }}" rows="3" class="w-full bg-gray-900 border border-gray-700 rounded-xl p-3 text-white"></textarea>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                        <div class="pt-6 border-t border-gray-700 flex justify-end">
                            <button type="submit" class="px-8 py-3 bg-[#0AD1C8] hover:bg-[#0B6477] text-[#0f172a] font-bold rounded-xl shadow-lg">Enviar Respuestas</button>
                        </div>
                    </form>
                </div>
            </div>
        @endif
    </div>

    <!-- 3. SIDEBAR -->
    <x-slot name="sidebar">
        <div class="p-5 border-b border-gray-800 bg-[#0f172a] sticky top-0 z-20">
            <h4 class="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Tu Progreso</h4>
            <div class="flex items-center justify-between text-white text-xs font-bold mb-1">
                <span>{{ $progress }}%</span>
                <span class="text-[#0AD1C8]">En curso</span>
            </div>
            <div class="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden mb-4">
                <div class="h-full bg-[#0AD1C8]" style="width: {{ $progress }}%"></div>
            </div>
            
            <div class="grid grid-cols-2 gap-2">
                @php
                    $matLink = $course->resources['materials'] ?? '#';
                    $presLink = $course->resources['presentations'] ?? '#';
                    $hasMat = !empty($course->resources['materials']);
                    $hasPres = !empty($course->resources['presentations']);
                @endphp
                <a href="{{ $hasMat ? $matLink : '#' }}" target="_blank" class="flex flex-col items-center justify-center gap-1 p-3 rounded-lg border {{ $hasMat ? 'border-gray-700 bg-[#1e293b] hover:bg-[#334155] text-gray-300 hover:text-white cursor-pointer' : 'border-gray-800 bg-gray-900 text-gray-600 cursor-not-allowed' }} transition-all text-xs font-bold text-center">
                    <i class="ph-fill ph-folder-open text-[#0AD1C8] text-xl mb-1"></i> Materiales
                </a>
                <a href="{{ $hasPres ? $presLink : '#' }}" target="_blank" class="flex flex-col items-center justify-center gap-1 p-3 rounded-lg border {{ $hasPres ? 'border-gray-700 bg-[#1e293b] hover:bg-[#334155] text-gray-300 hover:text-white cursor-pointer' : 'border-gray-800 bg-gray-900 text-gray-600 cursor-not-allowed' }} transition-all text-xs font-bold text-center">
                    <i class="ph-fill ph-presentation-chart text-purple-400 text-xl mb-1"></i> Presentaciones
                </a>
            </div>
        </div>

        <div class="overflow-y-auto h-full pb-32 custom-scrollbar" x-data="{ activeTopic: {{ $currentLesson->topic_id ?? 'null' }} }">
            @php $isPlanning = request('mode') === 'planning' || (!request('lesson') && request('mode') !== 'final'); @endphp
            <a href="?mode=planning" class="flex items-center gap-3 p-4 border-b border-gray-800/50 transition-colors {{ $isPlanning ? 'bg-[#1e293b] border-l-4 border-l-[#0AD1C8]' : 'hover:bg-[#1e293b] border-l-4 border-l-transparent' }}">
                <div class="shrink-0"><i class="ph-fill ph-house {{ $isPlanning ? 'text-[#0AD1C8]' : 'text-gray-500' }} text-xl"></i></div>
                <div class="flex-1"><p class="text-xs font-bold uppercase tracking-wide {{ $isPlanning ? 'text-white' : 'text-gray-400' }}">Inicio & Planificación</p><p class="text-[10px] text-gray-600">Bienvenida y Grupo</p></div>
            </a>

            @foreach($course->topics as $topic)
                <div class="border-b border-gray-800/50" x-data="{ open: true }">
                    <button type="button" @click="open = !open" class="w-full flex items-center justify-between p-4 bg-[#111827] hover:bg-[#1f2937] text-gray-200 text-xs font-bold transition-colors text-left group focus:outline-none">
                        <span class="uppercase tracking-wide line-clamp-1 pr-2">{{ $topic->title }}</span>
                        <i class="ph-bold ph-caret-down text-gray-500 transition-transform duration-200" :class="{ 'rotate-180 text-white': open }"></i>
                    </button>
                    <div x-show="open" x-collapse class="bg-[#0f172a]">
                        @foreach($topic->lessons as $lesson)
                            @php
                                $isActive = !$isPlanning && ($lesson->id === $currentLesson->id && request('mode') !== 'final');
                                $isLessonCompleted = in_array($lesson->id, $completedLessonIds ?? []);
                                $url = route('classroom.show', ['course' => $course->slug, 'lesson' => $lesson->slug ?? $lesson->id]);
                            @endphp
                            <a href="{{ $url }}" class="flex items-center justify-between p-3 border-b border-gray-800/30 transition-all group/item {{ $isActive ? 'bg-[#1e293b] border-l-4 border-l-[#0AD1C8]' : 'hover:bg-[#1e293b] border-l-4 border-l-transparent' }}">
                                <div class="flex items-center gap-3 overflow-hidden">
                                    <div class="shrink-0"><i class="ph-fill {{ $lesson->type == 'quiz' ? 'ph-list-checks' : 'ph-play-circle' }} {{ $isActive ? 'text-[#0AD1C8]' : 'text-gray-600 group-hover/item:text-gray-400' }} text-lg"></i></div>
                                    <div class="flex-1 min-w-0"><p class="text-xs font-medium leading-snug truncate {{ $isActive ? 'text-white' : 'text-gray-400 group-hover/item:text-gray-200' }}">{{ $lesson->title }}</p><span class="text-[10px] text-gray-600 block mt-0.5">{{ $lesson->type == 'quiz' ? 'Evaluación' : $lesson->duration_minutes . ' min' }}</span></div>
                                </div>
                                @if($isLessonCompleted) <div class="shrink-0 text-green-500"><i class="ph-fill ph-check-circle text-base"></i></div> @endif
                            </a>
                        @endforeach
                    </div>
                </div>
            @endforeach
            
            @if($hasExam)
                <div class="border-t border-gray-800 mt-2">
                    @php 
                        $isFinalActive = request('mode') === 'final'; 
                        $finalTitle = ($isExamEnabled && !$isProjectEnabled) ? 'Examen Final' : ((!$isExamEnabled && $isProjectEnabled) ? 'Trabajo Final' : 'Evaluación Final');
                        
                        // Icono dinámico en sidebar: Aprobado (Verde) o Reprobado (Rojo)
                        $sidebarStatusIcon = '';
                        if ($hasAttempted) {
                            if ($passedScore) {
                                $sidebarStatusIcon = '<div class="shrink-0 text-green-500" title="Aprobado"><i class="ph-fill ph-check-circle text-xl"></i></div>';
                            } else {
                                $sidebarStatusIcon = '<div class="shrink-0 text-red-500" title="Reprobado"><i class="ph-fill ph-x-circle text-xl"></i></div>';
                            }
                        }
                    @endphp
                    <a href="?mode=final" class="flex items-center justify-between p-4 {{ $isFinalActive ? 'bg-purple-900/20 border-l-4 border-purple-500' : 'hover:bg-[#1e293b] border-l-4 border-transparent' }} transition-colors">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center text-white shrink-0 shadow-lg"><i class="ph-fill ph-trophy"></i></div>
                            <div><p class="text-sm font-bold text-gray-200">{{ $finalTitle }}</p><p class="text-[10px] text-gray-500 uppercase">Obligatorio</p></div>
                        </div>
                        {!! $sidebarStatusIcon !!}
                    </a>
                </div>
            @endif
        </div>
    </x-slot>
</x-layouts.classroom>