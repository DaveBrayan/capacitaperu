<x-layouts.guest>
    <!-- LIBRERÍAS (Phosphor Icons) -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>

    <!-- HEADER / HERO SECTION (Fondo Oscuro) -->
    <div class="relative bg-[#213A57] text-white pt-32 pb-24 overflow-hidden">
        <!-- Decoración de fondo -->
        <div class="absolute inset-0 overflow-hidden pointer-events-none">
            <div class="absolute top-0 right-0 w-[600px] h-[600px] bg-[#0AD1C8] opacity-5 rounded-full blur-[150px]"></div>
            <div class="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#45DFB1] opacity-5 rounded-full blur-[100px]"></div>
            <!-- Imagen de fondo dinámica -->
            @php
                $coverImage = $course->cover_image ? asset($course->cover_image) : 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=2000&auto=format&fit=crop';
            @endphp
            <img src="{{ $coverImage }}" class="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-overlay">
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="flex flex-col lg:flex-row gap-12">
                
                <!-- Columna Izquierda (Info del Curso) -->
                <div class="lg:w-2/3">
                    <!-- Breadcrumb -->
                    <div class="flex items-center gap-2 text-sm text-gray-400 mb-6 font-medium">
                        <a href="{{ route('home') }}" class="hover:text-[#0AD1C8] transition-colors">Inicio</a>
                        <i class="ph-bold ph-caret-right text-xs"></i>
                        <a href="{{ route('catalog') }}" class="hover:text-[#0AD1C8] transition-colors">Catálogo</a>
                        <i class="ph-bold ph-caret-right text-xs"></i>
                        <span class="text-[#45DFB1]">{{ $course->categories->first()->name ?? 'Curso Especializado' }}</span>
                    </div>

                    <h1 class="text-3xl md:text-5xl font-extrabold mb-6 leading-tight">
                        {{ $course->title }}
                    </h1>

                    <div class="text-lg text-gray-300 mb-8 leading-relaxed max-w-2xl">
                        {!! $course->short_description ?? 'Potencia tus habilidades profesionales con nuestra metodología de enseñanza de vanguardia.' !!}
                    </div>

                    <!-- Meta Datos -->
                    <div class="flex flex-wrap gap-6 text-sm mb-8">
                        <div class="flex items-center gap-2 text-[#F59E0B]">
                            <div class="flex text-lg">
                                @php $rating = $course->rating ?? 5; @endphp
                                @for($i = 1; $i <= 5; $i++)
                                    <i class="ph-fill ph-star {{ $i <= $rating ? '' : 'text-gray-600' }}"></i>
                                @endfor
                            </div>
                            <span class="font-bold text-white">{{ $rating }}</span>
                            <span class="text-gray-400">({{ $course->reviews_count ?? '0' }} valoraciones)</span>
                        </div>
                        
                        <div class="flex items-center gap-2 text-gray-300">
                            <i class="ph-fill ph-clock text-[#0AD1C8] text-lg"></i>
                            <span>Actualizado: {{ $course->updated_at->locale('es')->translatedFormat('M Y') }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- CONTENIDO PRINCIPAL -->
    <div class="bg-gray-50 min-h-screen py-12 relative">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col lg:flex-row gap-12">

                <!-- COLUMNA IZQUIERDA (Detalles) -->
                <div class="lg:w-2/3 space-y-12">
                    
                    <!-- Lo que aprenderás -->
                    @if($course->learning_outcomes)
                    <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 class="text-2xl font-bold text-[#213A57] mb-6">Lo que aprenderás</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @php 
                                $outcomes = is_array($course->learning_outcomes) ? $course->learning_outcomes : json_decode($course->learning_outcomes, true);
                            @endphp
                            @if($outcomes)
                                @foreach($outcomes as $outcome)
                                <div class="flex gap-3">
                                    <i class="ph-bold ph-check text-[#0AD1C8] text-xl mt-0.5"></i>
                                    <span class="text-gray-600 text-sm">{{ $outcome }}</span>
                                </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                    @endif

                    <!-- Descripción extendida -->
                    <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 class="text-2xl font-bold text-[#213A57] mb-6">Descripción</h3>
                        <div class="prose prose-slate max-w-none text-gray-600 leading-relaxed">
                            {!! $course->description !!}
                        </div>
                    </div>

                    <!-- Temario (Acordeón) -->
                    <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 class="text-2xl font-bold text-[#213A57] mb-6">Contenido del Curso</h3>
                        
                        <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                            <span>{{ $course->modules->count() }} Módulos • {{ $course->lessons_count ?? '0' }} Clases</span>
                        </div>

                        <div class="space-y-4">
                            @foreach($course->modules as $index => $module)
                            <details class="group border border-gray-200 rounded-xl overflow-hidden {{ $index === 0 ? 'open' : '' }} transition-colors">
                                <summary class="flex items-center justify-between p-4 cursor-pointer bg-white group-open:bg-gray-50 hover:bg-gray-50 transition-colors list-none">
                                    <div class="flex items-center gap-4">
                                        <i class="ph-bold ph-caret-down transform group-open:rotate-180 transition-transform text-gray-400"></i>
                                        <span class="font-bold text-[#213A57]">{{ $module->title }}</span>
                                    </div>
                                    <span class="text-sm text-gray-500">{{ $module->lessons->count() }} clases</span>
                                </summary>
                                <div class="px-4 pb-4 pt-2 border-t border-gray-200/50 bg-white">
                                    <ul class="space-y-3">
                                        @foreach($module->lessons as $lesson)
                                        <li class="flex items-center justify-between text-sm text-gray-600">
                                            <div class="flex items-center gap-3">
                                                <i class="ph-fill ph-play-circle text-[#0AD1C8]"></i>
                                                <span>{{ $lesson->title }}</span>
                                            </div>
                                            @if($lesson->duration)
                                                <span class="text-gray-400">{{ $lesson->duration }} min</span>
                                            @endif
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </details>
                            @endforeach
                        </div>
                    </div>

                    <!-- NUEVA SECCIÓN: BENEFICIOS DEL CURSO -->
                    @if($course->benefits)
                    <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 class="text-2xl font-bold text-[#213A57] mb-6">Beneficios del Curso</h3>
                        <!-- AQUI ESTA EL CAMBIO: Agregamos la clase 'wysiwyg-content' -->
                        <div class="wysiwyg-content prose prose-slate max-w-none text-gray-600 leading-relaxed">
                            {!! $course->benefits !!}
                        </div>
                    </div>
                    @endif

                    <!-- Instructor Detalle -->
                    @if($course->instructor)
                    <div class="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
                        <h3 class="text-2xl font-bold text-[#213A57] mb-6">Tu Instructor</h3>
                        <div class="flex flex-col sm:flex-row gap-6">
                            <img src="{{ $course->instructor->avatar_url ? asset($course->instructor->avatar_url) : 'https://ui-avatars.com/api/?name='.urlencode($course->instructor->name).'&background=0AD1C8&color=fff&size=128' }}" class="w-24 h-24 rounded-full border-4 border-gray-50 object-cover">
                            <div>
                                <h4 class="text-xl font-bold text-[#213A57]">{{ $course->instructor->name }}</h4>
                                <p class="text-[#0B6477] font-medium text-sm mb-3">{{ $course->instructor->specialty ?? 'Especialista Senior' }}</p>
                                <p class="text-gray-600 text-sm leading-relaxed">
                                    {{ $course->instructor->bio ?? 'Profesional experto dedicado a la capacitación técnica y formación de competencias industriales.' }}
                                </p>
                            </div>
                        </div>
                    </div>
                    @endif
                </div>

                <!-- COLUMNA DERECHA (SIDEBAR COMPRA) -->
                <div class="lg:w-1/3 relative z-20">
                    <div class="sticky top-24 space-y-6 lg:-mt-64">
                        
                        <div class="bg-white rounded-3xl shadow-2xl overflow-hidden border border-gray-200">
                            <div class="relative h-56 bg-gray-900 overflow-hidden">
                                <img src="{{ $coverImage }}" class="w-full h-full object-cover opacity-60">
                                <div class="absolute inset-0 flex items-center justify-center">
                                    <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg">
                                        <i class="ph-fill ph-play text-[#213A57] text-3xl ml-1"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="p-6">
                                <!-- Lógica de WhatsApp y Precios -->
                                @php
                                    $whatsappNumber = "59162529911";
                                    $startDateLabel = isset($course->metadata['start_date']) ? \Carbon\Carbon::parse($course->metadata['start_date'])->locale('es')->translatedFormat('d \d\e F, Y') : 'Inmediato';
                                    
                                    $waMessage = "¡Hola YATI Academy! Me gustaría inscribirme en el curso: " . $course->title . 
                                                 ".\n\n*Precio:* Bs " . number_format($course->discount_price > 0 ? $course->discount_price : $course->price, 0) . 
                                                 "\n*Inicio:* " . $startDateLabel . 
                                                 "\n*Link:* " . route('course.show', $course->slug);
                                    
                                    $waUrl = "https://wa.me/" . $whatsappNumber . "?text=" . urlencode($waMessage);
                                @endphp

                                <div class="flex items-end gap-3 mb-6">
                                    @if($course->discount_price && $course->discount_price > 0)
                                        <span class="text-4xl font-extrabold text-[#213A57]">Bs {{ number_format($course->discount_price) }}</span>
                                        <span class="text-gray-400 line-through text-lg mb-1.5">Bs {{ number_format($course->price) }}</span>
                                    @else
                                        <span class="text-4xl font-extrabold text-[#213A57]">Bs {{ number_format($course->price) }}</span>
                                    @endif
                                </div>

                                <!-- Botones de Acción -->
                                <div class="space-y-3 mb-6">
                                    <a href="{{ route('cart') }}" class="block w-full text-center py-3.5 bg-white border border-[#213A57] text-[#213A57] font-bold rounded-xl hover:bg-gray-50 transition-colors text-lg">
                                        Añadir al Carrito
                                    </a>
                                    <!-- Botón Inscribirme (WhatsApp + Color de iconos) -->
                                    <a href="{{ $waUrl }}" target="_blank" class="block w-full text-center py-3.5 bg-[#0AD1C8] text-white font-bold rounded-xl shadow-lg hover:bg-[#0B6477] hover:-translate-y-0.5 transition-all text-lg flex items-center justify-center gap-2">
                                        <i class="ph-fill ph-whatsapp-logo text-2xl"></i>
                                        Inscribirme
                                    </a>
                                </div>

                                <!-- INFORMACIÓN ADICIONAL (Fecha y Modalidad) -->
                                <div class="grid grid-cols-1 gap-3 p-4 bg-gray-50 rounded-2xl border border-gray-100 mb-6">
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-[#0AD1C8]">
                                            <i class="ph-bold ph-calendar-check text-xl"></i>
                                        </div>
                                        <div>
                                            <p class="text-[10px] text-gray-400 uppercase font-bold leading-none">Inicio del Curso</p>
                                            <p class="text-sm font-bold text-[#213A57]">{{ $startDateLabel }}</p>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3">
                                        <div class="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center text-[#0AD1C8]">
                                            <i class="ph-bold ph-video-camera text-xl"></i>
                                        </div>
                                        <div>
                                            <p class="text-[10px] text-gray-400 uppercase font-bold leading-none">Modalidad</p>
                                            <p class="text-sm font-bold text-[#213A57]">{{ $course->metadata['modality'] ?? 'Virtual' }}</p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Beneficios Incluidos -->
                                <div class="space-y-4 pt-6 border-t border-gray-100">
                                    <h4 class="font-bold text-[#213A57] text-sm">Este curso incluye:</h4>
                                    <ul class="space-y-3 text-sm text-gray-600">
                                        <li class="flex items-center gap-3">
                                            <i class="ph-bold ph-clock text-[#0AD1C8] text-lg"></i>
                                            <span><strong>{{ $course->duration ?? '40' }} Horas Académicas</strong></span>
                                        </li>
                                        <li class="flex items-center gap-3">
                                            <i class="ph-bold ph-folder-open text-[#0AD1C8] text-lg"></i>
                                            <span>Acceso a material y presentaciones</span>
                                        </li>
                                        <li class="flex items-center gap-3">
                                            <i class="ph-bold ph-device-mobile text-[#0AD1C8] text-lg"></i>
                                            <span>Plataforma disponible 24/7</span>
                                        </li>
                                        <li class="flex items-center gap-3">
                                            <i class="ph-bold ph-certificate text-[#0AD1C8] text-lg"></i>
                                            <span>Certificado con validación QR</span>
                                        </li>
                                    </ul>
                                </div>

                                <!-- SECCIÓN RESALTADA: Capacitación Corporativa -->
                                <div class="mt-8 p-5 bg-gradient-to-br from-[#E0F9F6] to-white rounded-2xl border border-[#0AD1C8]/20 shadow-sm">
                                    <div class="flex items-center gap-2 mb-2">
                                        <i class="ph-bold ph-buildings text-[#0B6477] text-xl"></i>
                                        <h5 class="text-[#213A57] font-bold text-sm">¿Buscas capacitar a tu empresa?</h5>
                                    </div>
                                    <p class="text-xs text-gray-600 mb-4 leading-relaxed">
                                        Ofrecemos planes grupales, seguimiento personalizado y facturación para empresas. Impulsa el talento de tu equipo.
                                    </p>
                                    <a href="{{ route('contact') }}" class="flex items-center justify-center gap-2 w-full py-2.5 bg-[#213A57] text-white text-xs font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-md">
                                        <i class="ph-bold ph-chat-centered-dots"></i>
                                        Contáctanos
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    
    <!-- ESTILOS ESPECÍFICOS PARA LISTAS (WYSIWYG) -->
    <style>
        .wysiwyg-content ul {
            list-style-type: disc !important;
            padding-left: 1.5rem !important;
            margin-bottom: 1rem !important;
        }
        .wysiwyg-content ol {
            list-style-type: decimal !important;
            padding-left: 1.5rem !important;
            margin-bottom: 1rem !important;
        }
        .wysiwyg-content li {
            margin-bottom: 0.25rem !important;
            padding-left: 0.25rem !important;
        }
        .wysiwyg-content p {
            margin-bottom: 0.75rem !important;
        }
        /* Ajuste de color para los puntos */
        .wysiwyg-content ul li::marker {
            color: #0AD1C8; /* Tu color accent */
        }
    </style>
</x-layouts.guest>