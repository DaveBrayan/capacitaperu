<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Validación de Certificado - {{ config('app.name') }}</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,600,800|great-vibes:400|merriweather:400,700|montserrat:400,700|open-sans:400,700|pinyon-script:400|lato:400,700" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/phosphor-icons"></script>
    
    <!-- Librerías para Generar PDF (html2canvas + jsPDF) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <style>
        /* === ESTILOS UNIFICADOS (COPIA EXACTA DEL ADMIN) === */
        
        #preview-wrapper {
            width: 100%;
            min-height: 500px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            background-color: #cbd5e1;
            padding: 40px;
            overflow: hidden;
            border-radius: 12px;
        }

        #cert-canvas {
            width: 1123px;
            height: 794px;
            background-color: white;
            position: relative;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            flex-shrink: 0;
            transform-origin: top center;
            
            /* RESETEO CRÍTICO DE ESTILOS HEREDADOS */
            line-height: 1.15 !important;
            text-align: left;
            color: black;
            font-size: 16px;
            letter-spacing: normal;
        }

        /* Reset interno */
        #cert-canvas * {
            box-sizing: border-box !important;
            margin: 0 !important;
            padding: 0 !important;
            border: 0 !important;
        }

        /* Elementos */
        .cert-element {
            position: absolute;
            user-select: none;
            display: flex;
            flex-direction: column;
            z-index: 10;
        }

        /* Imágenes */
        #cert-canvas img {
            display: block;
            pointer-events: none;
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        
        /* Fuentes */
        .font-lato { font-family: 'Lato', sans-serif; }
        .font-merriweather { font-family: 'Merriweather', serif; }
        .font-pinyon { font-family: 'Pinyon Script', cursive; }
        .font-greatvibes { font-family: 'Great Vibes', cursive; }
        .font-montserrat { font-family: 'Montserrat', sans-serif; }
        .font-opensans { font-family: 'Open Sans', sans-serif; }

        /* === ESTILOS DE IMPRESIÓN (BACKUP POR SI ACASO) === */
        @media print {
            @page { size: landscape; margin: 0; }
            body, html { margin: 0; padding: 0; background: white; width: 100%; height: 100%; }
            nav, .lg\:col-span-3, .lg\:col-span-9 > div { display: none !important; }
            #preview-wrapper {
                display: block !important; background: none !important; padding: 0 !important; margin: 0 !important;
                width: 100% !important; height: 100% !important; overflow: visible !important; border-radius: 0 !important;
            }
            #cert-canvas {
                transform: scale(1) !important; box-shadow: none !important; margin: 0 !important;
                position: absolute !important; top: 0 !important; left: 0 !important;
                width: 1123px !important; height: 794px !important;
                print-color-adjust: exact; -webkit-print-color-adjust: exact;
            }
            main { padding: 0 !important; max-width: none !important; }
            .grid { display: block !important; }
            .lg\:col-span-9 { width: 100% !important; }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen font-['Inter'] text-slate-800">

    <nav class="bg-[#0f172a] text-white py-4 px-6 shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="font-bold text-xl tracking-tight flex items-center gap-2">
                <i class="ph-fill ph-certificate text-[#0AD1C8]"></i>
                Validación Oficial
            </div>
            <a href="/" class="text-sm text-gray-400 hover:text-white transition-colors">Inicio</a>
        </div>
    </nav>

    <main class="max-w-[1600px] mx-auto p-4 lg:p-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <!-- IZQUIERDA: VISUALIZADOR -->
            <div class="lg:col-span-9 w-full">
                <div id="preview-wrapper">
                    <div id="cert-canvas">
                        <!-- Fondo Absoluto -->
                        <img id="cert-background" src="" style="position: absolute; top:0; left:0; width:100%; height:100%; object-fit:fill; z-index:0; display:none;">
                        <!-- Capa de Elementos -->
                        <div id="elements-layer" style="position: absolute; inset:0; z-index:10; width:100%; height:100%;"></div>
                    </div>
                </div>
            </div>

            <!-- DERECHA: DATOS -->
            <div class="lg:col-span-3 space-y-4">
                 <!-- Tarjeta de Validación -->
                 <div class="bg-white rounded-xl shadow-sm border border-green-200 p-5">
                    <h2 class="text-xl font-bold text-slate-800 mb-2 flex items-center gap-2">
                        <i class="ph-fill ph-check-circle text-green-500"></i> Válido
                    </h2>
                    <p class="text-sm border-b border-gray-100 pb-2 mb-2"><strong>Estudiante:</strong><br> {{ $certificate->student->name }}</p>
                    <p class="text-sm border-b border-gray-100 pb-2 mb-2"><strong>Curso:</strong><br> {{ $certificate->course->title }}</p>
                    <p class="text-xs text-gray-500">UUID: {{ $certificate->uuid }}</p>
                 </div>
                 
                 <!-- Botón Descargar PDF Directo -->
                 <button onclick="downloadPDF()" id="btn-download" class="w-full py-4 bg-[#0AD1C8] text-[#0f172a] font-bold rounded-xl shadow-lg hover:bg-[#0B6477] hover:text-white transition-colors flex items-center justify-center gap-2 transform hover:-translate-y-0.5">
                    <i class="ph-bold ph-download-simple text-xl"></i> 
                    <span id="btn-text">Descargar PDF</span>
                 </button>

                 <!-- INFORMACIÓN DE LA EMPRESA (BARRA LATERAL) -->
                 <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mt-4">
                    <div class="bg-slate-50 p-4 border-b border-gray-100 text-center">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Realizado por</p>
                        <h3 class="text-[#213A57] font-extrabold text-lg mt-1">PACHABOL S.R.L.</h3>
                    </div>
                    
                    <div class="p-5 space-y-4 text-sm text-slate-600">
                        <div class="flex items-start gap-3">
                            <div class="mt-0.5 text-[#0AD1C8] shrink-0">
                                <i class="ph-fill ph-map-pin text-xl"></i>
                            </div>
                            <div>
                                <span class="block text-[10px] font-bold text-slate-400 uppercase mb-0.5">Casa Matriz</span>
                                <p class="leading-snug text-xs">
                                    Av. Raúl Salmon N°26, Edif. Victoria Planta baja Of. N°7, Z. 12 de Octubre. <br>
                                    <span class="font-semibold text-slate-700">El Alto, Bolivia.</span>
                                </p>
                            </div>
                        </div>

                        <div class="grid grid-cols-2 gap-2 pt-3 border-t border-gray-100">
                            <div>
                                <span class="block text-[10px] font-bold text-slate-400 uppercase">NIT</span>
                                <span class="font-mono text-xs font-bold text-slate-700">409968027</span>
                            </div>
                            <div>
                                <span class="block text-[10px] font-bold text-slate-400 uppercase">SEPREC</span>
                                <span class="font-mono text-xs font-bold text-slate-700">409968027</span>
                            </div>
                        </div>

                        <div class="pt-3 border-t border-gray-100 text-center">
                            <a href="https://www.pachabol.com" target="_blank" class="inline-flex items-center gap-1.5 text-[#0AD1C8] hover:text-[#08b8b0] font-bold text-sm transition-colors group">
                                <i class="ph-bold ph-globe"></i> 
                                <span class="group-hover:underline">www.pachabol.com</span>
                            </a>
                        </div>
                    </div>
                 </div>

            </div>
        </div>
    </main>

    <script>
        const templateData = @json($certificate->course->certificate_template ?? []);
        
        const realData = {
            student_name: @json($certificate->student->name),
            course_title: @json($certificate->course->title),
            instructor_name: @json($certificate->course->instructor->name ?? ''),
            date: @json($certificate->issued_at->format('d \d\e F \d\e Y')),
            verification_url: @json(route('certificate.verify', $certificate->uuid)),
            instructor_signature: @json(!empty($certificate->course->instructor->signature_url) ? asset($certificate->course->instructor->signature_url) : null)
        };

        function fixUrl(url) {
            if (!url || url.startsWith('data:')) return url;
            if (url.includes('/storage/')) {
                const parts = url.split('/storage/');
                return "{{ asset('storage') }}/" + parts[1];
            }
            if (url.startsWith('http')) return url;
            return "{{ asset('storage') }}/" + url.replace(/^\//, '');
        }

        document.addEventListener("DOMContentLoaded", () => {
            renderCertificate();
            fitCertificate();
            window.addEventListener('resize', fitCertificate);
        });

        // --- FUNCIÓN DE DESCARGA PDF ---
        async function downloadPDF() {
            const { jsPDF } = window.jspdf;
            const element = document.getElementById('cert-canvas');
            const btn = document.getElementById('btn-download');
            const btnText = document.getElementById('btn-text');
            
            // Estado visual: Cargando
            const originalText = btnText.innerText;
            btnText.innerText = "Generando PDF...";
            btn.disabled = true;
            btn.classList.add('opacity-75', 'cursor-wait');

            try {
                // 1. Guardar escala actual y poner a 100% para captura limpia
                const originalTransform = element.style.transform;
                element.style.transform = 'scale(1)';
                
                // 2. Capturar con html2canvas
                const canvas = await html2canvas(element, {
                    scale: 2, // 2x para mejor calidad
                    useCORS: true, // Permitir imágenes externas/locales
                    logging: false,
                    backgroundColor: '#ffffff'
                });

                // 3. Restaurar escala visual
                element.style.transform = originalTransform;

                // 4. Crear PDF A4 Horizontal
                const imgData = canvas.toDataURL('image/jpeg', 0.95); // JPEG 95% calidad
                const pdf = new jsPDF({
                    orientation: 'landscape',
                    unit: 'mm',
                    format: 'a4'
                });

                const pdfWidth = pdf.internal.pageSize.getWidth();
                const pdfHeight = pdf.internal.pageSize.getHeight();
                
                // Ajustar imagen al PDF
                pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);
                
                // 5. Descargar
                pdf.save(`Certificado-${realData.student_name}.pdf`);
                
            } catch (error) {
                console.error("Error PDF:", error);
                alert("Hubo un error generando el PDF directo. Se abrirá la opción de imprimir como respaldo.");
                window.print();
            } finally {
                // Restaurar botón
                btnText.innerText = originalText;
                btn.disabled = false;
                btn.classList.remove('opacity-75', 'cursor-wait');
            }
        }

        function renderCertificate() {
            const bgImg = document.getElementById('cert-background');
            const layer = document.getElementById('elements-layer');

            if (templateData.background) {
                bgImg.src = fixUrl(templateData.background);
                bgImg.style.display = 'block';
            }

            layer.innerHTML = '';

            (templateData.elements || []).forEach(el => {
                const div = document.createElement('div');
                div.className = 'cert-element';
                div.style.left = el.x + 'px';
                div.style.top = el.y + 'px';
                
                if (el.style) {
                    div.style.fontFamily = getFontFamily(el.style.fontFamily);
                    div.style.fontSize = el.style.fontSize;
                    div.style.color = el.style.color;
                    div.style.fontWeight = el.style.fontWeight;
                    
                    // Alineación Horizontal (del texto)
                    if (el.style.textAlign === 'center') div.style.alignItems = 'center';
                    else if (el.style.textAlign === 'right') div.style.alignItems = 'flex-end';
                    else div.style.alignItems = 'flex-start';

                    // Dimensiones y Alineación Vertical (del bloque)
                    if (el.style.width && el.style.width !== 'auto') {
                        div.style.width = el.style.width;
                        // CORRECCIÓN: Agregar altura para que el centrado vertical funcione
                        if (el.style.height) div.style.height = el.style.height;
                        div.style.whiteSpace = 'normal';
                        // CORRECCIÓN: Centrado vertical dentro de la caja
                        div.style.justifyContent = 'center'; 
                    }
                }

                if (el.type === 'qr') {
                    const w = el.style.width || '100px';
                    const link = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(realData.verification_url)}`;
                    div.innerHTML = `<img src="${link}">`;
                    div.style.width = w; div.style.height = w;
                }
                else if (el.type === 'signature' || el.type === 'manager_signature') {
                    div.style.width = 'auto'; 
                    div.style.height = 'auto';
                    div.style.whiteSpace = 'nowrap'; 
                    div.style.alignItems = 'center'; 
                    div.style.justifyContent = 'flex-end';
                    
                    let sigUrl = null;
                    if (el.type === 'signature') {
                        sigUrl = realData.instructor_signature;
                        if(sigUrl) sigUrl = fixUrl(sigUrl); 
                    }
                    else if (el.content?.signature_img) {
                        sigUrl = fixUrl(el.content.signature_img);
                    }

                    const size = el.content.size || 100;
                    const imgHtml = sigUrl 
                        ? `<img src="${sigUrl}" style="height:${size}px; max-width:200px; object-fit:contain;">` 
                        : `<div style="height:${size}px"></div>`;

                    const ns = el.content.nameStyle || {};
                    const rs = el.content.roleStyle || {};
                    const name = el.type === 'signature' ? realData.instructor_name : el.content.name;
                    
                    const nsStr = `font-family:${getFontFamily(ns.fontFamily)}; font-size:${ns.fontSize}; color:${ns.color}; font-weight:${ns.fontWeight}; margin-top:4px; line-height:1.2; text-align:center;`;
                    const rsStr = `font-family:${getFontFamily(rs.fontFamily)}; font-size:${rs.fontSize}; color:${rs.color}; line-height:1.2; text-align:center;`;

                    // CORRECCIÓN: ELIMINADO EL BLOQUE DE PACHABOL DE AQUÍ DENTRO
                    div.innerHTML = `
                        ${imgHtml}
                        <div style="border-top:1px solid ${ns.color}; width:100%; height:0; margin:2px 0;"></div>
                        <div style="${nsStr}">${name}</div>
                        <div style="${rsStr}">${el.content.role}</div>
                    `;
                }
                else {
                    if (el.type === 'student_name') div.textContent = realData.student_name;
                    else if (el.type === 'course_title') div.textContent = realData.course_title;
                    else if (el.type === 'text') div.innerHTML = (el.content || '').replace('{date}', realData.date);
                    
                    if (['image', 'seal'].includes(el.type)) {
                        const src = fixUrl(el.src);
                        div.innerHTML = `<img src="${src}" style="width:100%; height:100%; object-fit:contain;">`;
                    }
                }

                layer.appendChild(div);
            });
        }

        function fitCertificate() {
            const wrapper = document.getElementById('preview-wrapper');
            const canvas = document.getElementById('cert-canvas');
            const availableW = wrapper.clientWidth - 80; 
            const scale = Math.min(1, availableW / 1123);
            canvas.style.transform = `scale(${scale})`;
            wrapper.style.height = (794 * scale + 80) + 'px';
        }

        function getFontFamily(k) {
            const f = { 'font-lato': "'Lato', sans-serif", 'font-merriweather': "'Merriweather', serif", 'font-pinyon': "'Pinyon Script', cursive", 'font-greatvibes': "'Great Vibes', cursive", 'font-montserrat': "'Montserrat', sans-serif", 'font-opensans': "'Open Sans', sans-serif" };
            return f[k] || 'sans-serif';
        }
    </script>
</body>
</html>