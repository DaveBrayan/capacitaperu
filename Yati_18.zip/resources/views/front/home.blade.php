<x-layouts.guest>

    <!-- HERO SECTION PREMIUM (Imagen de Fondo + Tarjeta de Curso Destacado) -->
    <div class="relative min-h-screen flex items-center pt-20 pb-20 overflow-hidden">
        
        <!-- FONDO: Imagen Real + Overlay Degradado -->
        <div class="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?q=80&w=2000&auto=format&fit=crop" 
                 alt="Ingenieros en obra" 
                 class="w-full h-full object-cover">
            <!-- Overlay Azul Corporativo con opacidad ajustada -->
            <div class="absolute inset-0 bg-[#213A57]/90 mix-blend-multiply"></div>
            <!-- Degradado extra para dar profundidad desde abajo -->
            <div class="absolute inset-0 bg-gradient-to-t from-[#213A57] via-transparent to-[#213A57]/50"></div>
        </div>

        <!-- CONTENIDO HERO -->
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                
                <!-- COLUMNA IZQUIERDA: Texto Principal -->
                <div class="text-center lg:text-left pt-10 lg:pt-0">
                    <div class="inline-flex items-center gap-2 py-1 px-3 rounded-full bg-[#0AD1C8]/10 border border-[#0AD1C8]/30 backdrop-blur-md mb-6 fade-in-up">
                        <span class="flex h-2 w-2 relative">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#45DFB1] opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-2 w-2 bg-[#0AD1C8]"></span>
                        </span>
                        <span class="text-[#45DFB1] text-xs font-bold tracking-widest uppercase">Plataforma Educativa</span>
                    </div>

                    <h1 class="text-4xl lg:text-6xl font-extrabold text-white mb-6 leading-tight fade-in-up delay-100 drop-shadow-xl">
                        Potencia tu perfil profesional con <br>
                        <span class="text-transparent bg-clip-text bg-gradient-to-r from-[#0AD1C8] to-[#45DFB1]">Certificación Verificable.</span>
                    </h1>

                    <p class="text-lg text-gray-200 mb-8 max-w-2xl mx-auto lg:mx-0 fade-in-up delay-200 font-light leading-relaxed">
                        Cursos prácticos en Seguridad Industrial y Normas ISO, junto con áreas clave como Agropecuarios e Inocuidad Alimentaria. Valida tu aprendizaje con certificados digitales verificables mediante código QR.
                    </p>

                    <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start fade-in-up delay-300">
                        <a href="#cursos" class="btn-primary text-white px-8 py-4 rounded-full font-bold text-lg shadow-[0_0_20px_rgba(10,209,200,0.4)] hover:shadow-[0_0_30px_rgba(10,209,200,0.6)] flex items-center justify-center gap-2 group transition-all transform hover:-translate-y-1">
                            Ver Cursos Disponibles
                            <i class="ph-bold ph-arrow-right group-hover:translate-x-1 transition-transform"></i>
                        </a>
                        <a href="#certificaciones" class="bg-white/5 backdrop-blur-md text-white border border-white/20 hover:bg-white/10 px-8 py-4 rounded-full font-bold text-lg transition-all flex items-center justify-center gap-2">
                            Validar un Certificado
                        </a>
                    </div>
                    
                    <!-- Stats Mini -->
                    <div class="mt-10 pt-8 border-t border-white/10 flex gap-8 justify-center lg:justify-start fade-in-up delay-300">
                        <div>
                            <p class="text-2xl font-bold text-white">+10k</p>
                            <p class="text-xs text-[#0AD1C8]">Alumnos</p>
                        </div>
                        <div>
                            <p class="text-2xl font-bold text-white">98%</p>
                            <p class="text-xs text-[#0AD1C8]">Aprobados</p>
                        </div>
                        <div>
                            <p class="text-2xl font-bold text-white">24/7</p>
                            <p class="text-xs text-[#0AD1C8]">Acceso</p>
                        </div>
                    </div>
                </div>

                <!-- COLUMNA DERECHA: Último Curso Destacado (DINÁMICO) -->
                <div class="hidden lg:block relative fade-in-up delay-300">
                    <!-- Decoración detrás de la tarjeta -->
                    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-[#0AD1C8]/20 rounded-full blur-[80px]"></div>
                    
                    <!-- Tarjeta Glassmorphism -->
                    @if(isset($heroCourse) && $heroCourse)
                    <div class="relative bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-2xl transform rotate-3 hover:rotate-0 transition-all duration-500">
                        
                        <!-- BADGE DESCUENTO HERO -->
                        @if($heroCourse->discount_price > 0 && $heroCourse->discount_price < $heroCourse->price)
                            @php
                                $heroDiscountPercent = round((($heroCourse->price - $heroCourse->discount_price) / $heroCourse->price) * 100);
                            @endphp
                            <div class="absolute -top-4 -right-4 bg-[#F59E0B] text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg animate-bounce z-20">
                                🔥 -{{ $heroDiscountPercent }}% DCTO
                            </div>
                        @else
                            <div class="absolute -top-4 -right-4 bg-[#F59E0B] text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg animate-bounce z-20">
                                🔥 NUEVO LANZAMIENTO
                            </div>
                        @endif
                        
                        <div class="h-48 rounded-2xl overflow-hidden mb-5 relative group">
                            <img src="{{ $heroCourse->cover_image ? asset($heroCourse->cover_image) : 'https://images.unsplash.com/photo-1531973576160-7125cd663d86?q=80&w=800&auto=format&fit=crop' }}" 
                                 class="w-full h-full object-cover">
                            <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <a href="{{ route('course.show', $heroCourse->slug) }}" class="bg-white/20 backdrop-blur px-4 py-2 rounded-full text-white text-sm font-bold">Vista Previa</a>
                            </div>
                        </div>

                        <div class="space-y-3">
                            <div class="flex justify-between items-start">
                                <h3 class="text-2xl font-bold text-white leading-tight line-clamp-2" title="{{ $heroCourse->title }}">{{ $heroCourse->title }}</h3>
                                @if($heroCourse->discount_price > 0 && $heroCourse->discount_price < $heroCourse->price)
                                    <div class="text-right">
                                        <span class="block bg-[#0AD1C8] text-[#213A57] text-xs font-bold px-2 py-1 rounded whitespace-nowrap">Bs {{ number_format($heroCourse->discount_price, 0) }}</span>
                                        <span class="block text-[10px] text-gray-300 line-through mt-0.5">Bs {{ number_format($heroCourse->price, 0) }}</span>
                                    </div>
                                @else
                                    <span class="bg-[#0AD1C8] text-[#213A57] text-xs font-bold px-2 py-1 rounded whitespace-nowrap">Bs {{ number_format($heroCourse->price, 0) }}</span>
                                @endif
                            </div>
                            <p class="text-gray-300 text-sm line-clamp-2">{{ $heroCourse->short_description }}</p>
                            
                            <div class="flex items-center gap-2 text-sm text-[#45DFB1] font-medium pt-2">
                                <i class="ph-fill ph-certificate"></i> Certificado con QR
                                <span class="text-gray-400">•</span>
                                <i class="ph-fill ph-video"></i> {{ $heroCourse->lessons_count ?? 'Múltiples' }} Lecciones
                            </div>

                            <a href="{{ route('course.show', $heroCourse->slug) }}" class="block w-full mt-4 bg-white text-[#213A57] py-3 rounded-xl font-bold hover:bg-[#0AD1C8] transition-colors shadow-lg text-center">
                                Inscribirse Ahora
                            </a>
                        </div>
                    </div>
                    @else
                        <!-- Fallback si no hay cursos -->
                        <div class="relative bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 shadow-2xl">
                            <p class="text-white text-center">Próximamente nuevos cursos.</p>
                        </div>
                    @endif
                </div>

            </div>
        </div>
    </div>

    <!-- SECCIÓN: SOBRE NOSOTROS (Breve) -->
    <div class="bg-white py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row gap-12 items-center">
                <div class="w-full md:w-1/2 relative">
                    <div class="absolute -top-4 -left-4 w-20 h-20 bg-[#0AD1C8]/10 rounded-full blur-xl"></div>
                    <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=800&auto=format&fit=crop" class="rounded-3xl shadow-2xl relative z-10 w-full transform -rotate-2 hover:rotate-0 transition-transform duration-500">
                    <div class="absolute -bottom-6 -right-6 bg-[#213A57] p-6 rounded-2xl shadow-xl z-20 text-white max-w-xs">
                        <p class="font-bold text-lg">"Ofrecemos rutas de aprendizaje para el crecimiento profesional"</p>
                        <p class="text-xs text-[#0AD1C8] mt-2">— Ing. Reynaldo Sirpa CEO de PACHABOL</p>
                    </div>
                </div>
                <div class="w-full md:w-1/2">
                    <span class="text-[#0B6477] font-bold tracking-widest text-xs uppercase mb-2 block">Sobre YATI</span>
                    <h2 class="text-3xl md:text-4xl font-bold text-[#213A57] mb-6">Expertos en Formación Técnica Industrial</h2>
                    <p class="text-gray-600 mb-6 leading-relaxed">
                        YATI es la plataforma de educación de Pachabol SRL, creada para ofrecer formación accesible y de calidad en Bolivia y América Latina. Te preparamos con habilidades prácticas y certificables, alineadas con las demandas del mercado laboral.
                    </p>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- SECCIÓN: CERTIFICACIONES Y BENEFICIOS (Dark Mode) -->
    <div id="certificaciones" class="bg-[#213A57] py-24 relative overflow-hidden">
        <!-- Decoración Fondo -->
        <div class="absolute top-0 right-0 w-[600px] h-[600px] bg-[#0AD1C8] opacity-5 rounded-full blur-[150px] pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#45DFB1] opacity-5 rounded-full blur-[100px] pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center max-w-3xl mx-auto mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-white mb-4">Certificaciones que <span class="text-[#45DFB1]">valen la pena</span></h2>
                <p class="text-gray-300">
                    Certificados digitales verificables. Que tu esfuerzo sea reconocido a nivel global.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Beneficio 1: QR -->
                <div class="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group">
                    <div class="w-14 h-14 rounded-2xl bg-[#0AD1C8] flex items-center justify-center text-[#213A57] text-2xl mb-6 shadow-lg shadow-[#0AD1C8]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-qr-code"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Código QR Único</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        Cada certificado cuenta con un código QR único e infalsificable. Cualquier empresa o institución puede escanearlo y verificar tu aprobación en tiempo real en nuestra base de datos.
                    </p>
                </div>

                <!-- Beneficio 2: Respaldo -->
                <div class="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group">
                    <div class="w-14 h-14 rounded-2xl bg-[#45DFB1] flex items-center justify-center text-[#213A57] text-2xl mb-6 shadow-lg shadow-[#45DFB1]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-seal-check"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Respaldo Institucional</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        Nuestros cursos están alineados con normativas nacionales e internacionales, contando con profesionales acreditados para garantizar su validez curricular.
                    </p>
                </div>

                <!-- Beneficio 3: Digital -->
                <div class="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group">
                    <div class="w-14 h-14 rounded-2xl bg-[#80ED99] flex items-center justify-center text-[#213A57] text-2xl mb-6 shadow-lg shadow-[#80ED99]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-cloud-arrow-down"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Siempre Disponible</h3>
                    <p class="text-gray-400 text-sm leading-relaxed">
                        Descarga tu certificado en alta resolución (PDF) cuantas veces quieras. Nunca perderás tu constancia de estudios.
                    </p>
                </div>
            </div>

            <!-- Visualización del Certificado (Mockup) -->
            <div class="mt-20 bg-white/5 rounded-3xl p-8 md:p-12 border border-white/10 flex flex-col md:flex-row items-center gap-10">
                <div class="w-full md:w-1/2">
                    <h3 class="text-2xl font-bold text-white mb-4">Tu certificado personalizado incluirá:</h3>
                    <ul class="space-y-4 mb-8">
                        <li class="flex items-center gap-3 text-gray-300">
                            <i class="ph-fill ph-check-circle text-[#45DFB1] text-xl"></i>
                            <span>•	Nombre completo y C.I.</span>
                        </li>
                        <li class="flex items-center gap-3 text-gray-300">
                            <i class="ph-fill ph-check-circle text-[#45DFB1] text-xl"></i>
                            <span>•	Horas académicas detalladas</span>
                        </li>
                        <li class="flex items-center gap-3 text-gray-300">
                            <i class="ph-fill ph-check-circle text-[#45DFB1] text-xl"></i>
                            <span>•	Firmas digitales de instructores expertos</span>
                        </li>
                    </ul>
                </div>
                <div class="w-full md:w-1/2 relative">
                    <!-- Simulación de Certificado -->
                    <div class="bg-white p-4 rounded-lg shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
                        <div class="border-4 border-[#213A57] p-6 text-center relative overflow-hidden">
                            <div class="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-[#0B6477]"></div>
                            <div class="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-[#0B6477]"></div>
                            
                            <h4 class="text-2xl font-serif font-bold text-[#213A57] mb-2">CERTIFICADO</h4>
                            <p class="text-xs text-gray-500 mb-4">DE APROBACIÓN</p>
                            <p class="text-sm text-gray-600">Otorgado a:</p>
                            <p class="text-xl font-bold text-[#0B6477] mb-4">JUAN PÉREZ</p>
                            <div class="w-20 h-20 bg-gray-100 mx-auto mb-2 flex items-center justify-center">
                                <i class="ph-fill ph-qr-code text-4xl text-black"></i>
                            </div>
                            <p class="text-[10px] text-gray-400">ID: 591-YATI-2025</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- SECCIÓN DE CURSOS (DINÁMICO) -->
    <div id="cursos" class="py-24 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <span class="text-[#0B6477] font-bold tracking-widest text-xs uppercase mb-2 block">Explora</span>
                <h2 class="text-3xl md:text-5xl font-bold text--[#213A57] mb-4">Nuestros cursos</h2>
                <p class="text-gray-500 max-w-2xl mx-auto">En áreas demandadas por las empresas, incluyendo Seguridad Industrial, Agropecuarios, y Emprendimiento.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                
                @forelse($latestCourses as $course)
                <div class="group bg-white rounded-3xl border border-gray-100 shadow-xl shadow-gray-200/50 hover:shadow-2xl hover:shadow-[#0AD1C8]/10 hover:-translate-y-2 transition-all duration-300 overflow-hidden cursor-pointer flex flex-col h-full relative">
                    
                    <!-- BADGE DESCUENTO LISTA -->
                    @if($course->discount_price > 0 && $course->discount_price < $course->price)
                        @php
                            $discountPercent = round((($course->price - $course->discount_price) / $course->price) * 100);
                        @endphp
                        <div class="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-md z-20 animate-pulse">
                            -{{ $discountPercent }}%
                        </div>
                    @endif

                    <div class="relative h-56 overflow-hidden">
                        <img src="{{ $course->cover_image ? asset($course->cover_image) : 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=800&auto=format&fit=crop' }}" 
                             class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                        <div class="absolute inset-0 bg-[#213A57]/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <a href="{{ route('course.show', $course->slug) }}" class="bg-[#0AD1C8] text-[#213A57] px-4 py-2 rounded-full font-bold text-sm transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">Ver Curso</a>
                        </div>
                        
                        <!-- Categoría dinámica -->
                        <div class="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-lg text-xs font-bold text-[#213A57] shadow-sm flex items-center gap-1 z-20">
                            <i class="ph-fill {{ $course->categories->first()->icon ?? 'ph-tag' }} text-[#0B6477]"></i> 
                            {{ $course->categories->first()->name ?? 'Curso' }}
                        </div>
                    </div>
                    <div class="p-8 flex-1 flex flex-col">
                        <h3 class="font-bold text-xl text-[#213A57] mb-3 group-hover:text-[#0B6477] transition-colors leading-tight line-clamp-2" title="{{ $course->title }}">
                            {{ $course->title }}
                        </h3>
                        <p class="text-sm text-gray-500 mb-6 line-clamp-2 leading-relaxed flex-1">
                            {{ $course->short_description ?? 'Sin descripción corta disponible.' }}
                        </p>
                        <div class="pt-6 border-t border-gray-50 flex justify-between items-center">
                            <div class="flex items-center gap-1 text-[#F59E0B] font-bold text-sm">
                                <i class="ph-fill ph-star"></i> {{ $course->rating ?? 5.0 }}
                            </div>
                            
                            @if($course->discount_price > 0 && $course->discount_price < $course->price)
                                <div class="text-right">
                                    <span class="block text-lg font-bold text-[#0B6477]">Bs {{ number_format($course->discount_price, 0) }}</span>
                                    <span class="block text-xs text-gray-400 line-through">Bs {{ number_format($course->price, 0) }}</span>
                                </div>
                            @else
                                <span class="text-lg font-bold text-[#0B6477]">Bs {{ number_format($course->price, 0) }}</span>
                            @endif
                        </div>
                    </div>
                </div>
                @empty
                <div class="col-span-3 text-center py-12 text-gray-400">
                    <p>No hay cursos publicados por el momento.</p>
                </div>
                @endforelse

            </div>
            
            <div class="mt-16 text-center">
                <a href="{{ route('catalog') }}" class="inline-flex items-center gap-2 text-[#213A57] font-bold border-b-2 border-[#0AD1C8] hover:text-[#0AD1C8] transition-colors pb-1 text-lg">
                    Ver todos los cursos disponibles <i class="ph-bold ph-arrow-right"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- CALL TO ACTION FINAL -->
    <div class="py-24 relative overflow-hidden bg-[#213A57]">
        <div class="absolute inset-0">
             <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?q=80&w=2000&auto=format&fit=crop" class="w-full h-full object-cover opacity-10 mix-blend-overlay">
        </div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-[#0AD1C8] opacity-10 rounded-full blur-[100px]"></div>

        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h2 class="text-3xl md:text-5xl font-bold text-white mb-6">Comienza hoy tu camino hacia el éxito profesional</h2>
            <p class="text-gray-300 text-lg mb-10 leading-relaxed max-w-2xl mx-auto">
                Aprovecha las oportunidades laborales con las certificaciones que las empresas más buscan.
            </p>
            
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://wa.me/59162529911" target="_blank" class="bg-[#0AD1C8] hover:bg-[#45DFB1] text-[#213A57] px-10 py-4 rounded-full font-bold text-lg transition-all shadow-[0_0_20px_rgba(10,209,200,0.3)] hover:shadow-[0_0_30px_rgba(10,209,200,0.5)] transform hover:-translate-y-1">
                    Contactar por WhatsApp
                </a>
            </div>
        </div>
    </div>

</x-layouts.guest>