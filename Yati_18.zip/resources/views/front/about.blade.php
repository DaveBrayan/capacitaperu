<x-layouts.guest>

    <!-- HERO SECTION (Identidad) -->
    <div class="relative bg-[#213A57] py-24 overflow-hidden">
        <!-- Decoración Fondo -->
        <div class="absolute inset-0">
            <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2000&auto=format&fit=crop" class="w-full h-full object-cover opacity-10 mix-blend-overlay">
            <div class="absolute inset-0 bg-gradient-to-t from-[#213A57] via-transparent to-transparent"></div>
        </div>
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-[#0AD1C8] opacity-5 rounded-full blur-[150px]"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <span class="text-[#0AD1C8] font-bold tracking-[0.2em] text-xs uppercase mb-4 block fade-in-up">Nuestra Esencia</span>
            <h1 class="text-4xl md:text-6xl font-extrabold text-white mb-6 fade-in-up delay-100">
                Democratizando la <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-[#0AD1C8] to-[#45DFB1]">Educación Técnica de Calidad</span>
            </h1>
            <p class="text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed fade-in-up delay-200">
                Nacimos con una convicción: el talento técnico en Latinoamérica es inmenso, pero le faltan herramientas modernas para certificarse y brillar.
            </p>
        </div>
    </div>

    <!-- HISTORIA Y MISIÓN -->
    <div class="bg-white py-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                
                <!-- Imágenes Collage -->
                <div class="relative">
                    <div class="absolute -top-4 -left-4 w-24 h-24 bg-[#0AD1C8]/10 rounded-full blur-xl"></div>
                    <div class="grid grid-cols-2 gap-4">
                        <img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=800&auto=format&fit=crop" class="rounded-2xl shadow-lg transform translate-y-8">
                        <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=800&auto=format&fit=crop" class="rounded-2xl shadow-lg">
                    </div>
                    <!-- Stats Flotante -->
                    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white p-6 rounded-2xl shadow-2xl border border-gray-100 text-center w-48">
                        <p class="text-4xl font-bold text-[#213A57]">3+</p>
                        <p class="text-xs text-gray-500 uppercase tracking-widest mt-1">Años de Experiencia</p>
                    </div>
                </div>

                <!-- Texto -->
                <div>
                    <h2 class="text-3xl font-bold text-[#213A57] mb-6">Más que una plataforma, un puente al empleo.</h2>
                    <div class="space-y-6 text-gray-600 leading-relaxed">
                        <p>
                            YATI (del aymara <em>"Saber"</em>) nació en 2022 en La Paz, Bolivia, como respuesta a una necesidad crítica en la industria: la falta de capacitación especializada accesible.
                        </p>
                        <p>
                            Mientras las universidades ofrecen teoría, la industria exige práctica y normativa actualizada. Nosotros llenamos ese vacío conectando a ingenieros expertos con estudiantes que buscan algo más que un título: buscan <strong>competencia real</strong>.
                        </p>
                    </div>

                    <div class="mt-8 grid grid-cols-2 gap-6">
                        <div class="pl-4 border-l-4 border-[#0AD1C8]">
                            <h4 class="font-bold text-[#213A57] text-lg">Misión</h4>
                            <p class="text-sm text-gray-500 mt-1">Formar técnicos de élite capaces de liderar la seguridad y productividad industrial.</p>
                        </div>
                        <div class="pl-4 border-l-4 border-[#45DFB1]">
                            <h4 class="font-bold text-[#213A57] text-lg">Visión</h4>
                            <p class="text-sm text-gray-500 mt-1">Ser el estándar de certificación técnica digital en toda la región andina.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- VALORES (Dark Section) -->
    <div class="bg-[#213A57] py-24 relative overflow-hidden">
        <div class="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
        
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-white">Nuestros Pilares</h2>
                <p class="text-gray-400 mt-4">Lo que nos hace diferentes a cualquier otro curso online.</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Valor 1 -->
                <div class="bg-white/5 backdrop-blur border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group text-center">
                    <div class="w-16 h-16 mx-auto bg-[#0AD1C8] rounded-2xl flex items-center justify-center text-[#213A57] text-3xl mb-6 shadow-lg shadow-[#0AD1C8]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-medal"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Excelencia Técnica</h3>
                    <p class="text-gray-400 text-sm">
                        No vendemos cursos "fáciles". Nuestros contenidos son rigurosos y están auditados por colegios de ingenieros.
                    </p>
                </div>

                <!-- Valor 2 -->
                <div class="bg-white/5 backdrop-blur border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group text-center">
                    <div class="w-16 h-16 mx-auto bg-[#45DFB1] rounded-2xl flex items-center justify-center text-[#213A57] text-3xl mb-6 shadow-lg shadow-[#45DFB1]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-users-three"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Comunidad Real</h3>
                    <p class="text-gray-400 text-sm">
                        Fomentamos el networking. Nuestros estudiantes consiguen empleo gracias a las conexiones que hacen aquí.
                    </p>
                </div>

                <!-- Valor 3 -->
                <div class="bg-white/5 backdrop-blur border border-white/10 p-8 rounded-3xl hover:bg-white/10 transition-colors group text-center">
                    <div class="w-16 h-16 mx-auto bg-[#80ED99] rounded-2xl flex items-center justify-center text-[#213A57] text-3xl mb-6 shadow-lg shadow-[#80ED99]/20 group-hover:scale-110 transition-transform">
                        <i class="ph-bold ph-rocket-launch"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-3">Innovación Constante</h3>
                    <p class="text-gray-400 text-sm">
                        Usamos tecnología de punta (LMS propio, QR blockchain) para garantizar la mejor experiencia.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- EQUIPO -->
    <div class="bg-gray-50 py-24">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <span class="text-[#0B6477] font-bold tracking-widest text-xs uppercase mb-2 block">Mentes Brillantes</span>
                <h2 class="text-3xl font-bold text-[#213A57]">Conoce a los expertos</h2>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                
                <!-- Miembro 1 -->
                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center hover:shadow-xl transition-shadow group">
                    <div class="w-32 h-32 mx-auto rounded-full overflow-hidden mb-6 border-4 border-[#E0F9F6] group-hover:border-[#0AD1C8] transition-colors">
                        <img src="https://ui-avatars.com/api/?name=Deivid+Chipana&background=213A57&color=fff&size=256" class="w-full h-full object-cover">
                    </div>
                    <h3 class="font-bold text-lg text-[#213A57]">Ing. Deivid Chipana</h3>
                    <p class="text-xs text-[#0B6477] font-bold uppercase tracking-wider mb-3">Fundador & CEO</p>
                    <p class="text-gray-500 text-sm mb-4">Ingeniero de Sistemas apasionado por la educación tecnológica.</p>
                    <div class="flex justify-center gap-3">
                        <a href="#" class="text-gray-400 hover:text-[#0AD1C8]"><i class="ph-fill ph-linkedin-logo text-xl"></i></a>
                        <a href="#" class="text-gray-400 hover:text-[#0AD1C8]"><i class="ph-fill ph-twitter-logo text-xl"></i></a>
                    </div>
                </div>

                <!-- Miembro 2 -->
                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center hover:shadow-xl transition-shadow group">
                    <div class="w-32 h-32 mx-auto rounded-full overflow-hidden mb-6 border-4 border-[#E0F9F6] group-hover:border-[#0AD1C8] transition-colors">
                        <img src="https://ui-avatars.com/api/?name=Ana+Sola&background=random&size=256" class="w-full h-full object-cover">
                    </div>
                    <h3 class="font-bold text-lg text-[#213A57]">Ing. Ana Sola</h3>
                    <p class="text-xs text-[#0B6477] font-bold uppercase tracking-wider mb-3">Directora Académica</p>
                    <p class="text-gray-500 text-sm mb-4">Especialista en Seguridad Industrial con 15 años en campo.</p>
                    <div class="flex justify-center gap-3">
                        <a href="#" class="text-gray-400 hover:text-[#0AD1C8]"><i class="ph-fill ph-linkedin-logo text-xl"></i></a>
                    </div>
                </div>

                <!-- Miembro 3 -->
                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center hover:shadow-xl transition-shadow group">
                    <div class="w-32 h-32 mx-auto rounded-full overflow-hidden mb-6 border-4 border-[#E0F9F6] group-hover:border-[#0AD1C8] transition-colors">
                        <img src="https://ui-avatars.com/api/?name=Carlos+V&background=random&size=256" class="w-full h-full object-cover">
                    </div>
                    <h3 class="font-bold text-lg text-[#213A57]">Ing. Carlos V.</h3>
                    <p class="text-xs text-[#0B6477] font-bold uppercase tracking-wider mb-3">Jefe de Tecnología</p>
                    <p class="text-gray-500 text-sm mb-4">Arquitecto de Software y experto en plataformas LMS.</p>
                    <div class="flex justify-center gap-3">
                        <a href="#" class="text-gray-400 hover:text-[#0AD1C8]"><i class="ph-fill ph-linkedin-logo text-xl"></i></a>
                    </div>
                </div>

                <!-- Miembro 4 -->
                <div class="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 text-center hover:shadow-xl transition-shadow group">
                    <div class="w-32 h-32 mx-auto rounded-full overflow-hidden mb-6 border-4 border-[#E0F9F6] group-hover:border-[#0AD1C8] transition-colors">
                        <img src="https://ui-avatars.com/api/?name=Maria+L&background=random&size=256" class="w-full h-full object-cover">
                    </div>
                    <h3 class="font-bold text-lg text-[#213A57]">Lic. Maria L.</h3>
                    <p class="text-xs text-[#0B6477] font-bold uppercase tracking-wider mb-3">Coordinadora</p>
                    <p class="text-gray-500 text-sm mb-4">Encargada de éxito estudiantil y alianzas estratégicas.</p>
                    <div class="flex justify-center gap-3">
                        <a href="#" class="text-gray-400 hover:text-[#0AD1C8]"><i class="ph-fill ph-linkedin-logo text-xl"></i></a>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- LOGOS DE CONFIANZA -->
    <div class="py-16 bg-white border-t border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p class="text-sm font-bold text-gray-400 uppercase tracking-widest mb-8">Empresas que capacitan con nosotros</p>
            <div class="flex flex-wrap justify-center items-center gap-12 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                <!-- Logos Placeholders (Usando texto estilizado por ahora) -->
                <span class="text-2xl font-bold text-[#213A57]">YPFB</span>
                <span class="text-2xl font-bold text-[#213A57]">SOBOCE</span>
                <span class="text-2xl font-bold text-[#213A57]">CBN</span>
                <span class="text-2xl font-bold text-[#213A57]">TELEFÉRICO</span>
                <span class="text-2xl font-bold text-[#213A57]">MINERA SAN CRISTÓBAL</span>
            </div>
        </div>
    </div>

    <!-- CTA FINAL -->
    <div class="relative bg-[#0AD1C8] py-20 overflow-hidden">
        <div class="absolute inset-0 bg-[#213A57] opacity-10 pattern-dots"></div>
        <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
            <h2 class="text-3xl md:text-4xl font-bold text-[#213A57] mb-6">¿Quieres formar parte de la revolución educativa?</h2>
            <div class="flex justify-center gap-4">
                <a href="/catalogo" class="bg-[#213A57] text-white px-8 py-3 rounded-full font-bold shadow-lg hover:shadow-xl hover:bg-[#1a2e45] transition-all">Ver Cursos</a>
                <a href="#" class="bg-white text-[#213A57] px-8 py-3 rounded-full font-bold shadow-lg hover:shadow-xl hover:bg-gray-50 transition-all">Contactar</a>
            </div>
        </div>
    </div>

</x-layouts.guest>