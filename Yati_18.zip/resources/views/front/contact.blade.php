<x-layouts.guest>

    <!-- HEADER / HERO -->
    <div class="relative bg-[#213A57] pt-32 pb-32 overflow-hidden">
        <div class="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20">
            <div class="absolute top-[-10%] right-[-5%] w-96 h-96 bg-[#0AD1C8] rounded-full blur-[120px]"></div>
            <div class="absolute bottom-[-10%] left-[-5%] w-96 h-96 bg-[#45DFB1] rounded-full blur-[120px]"></div>
        </div>
        
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <span class="text-[#0AD1C8] font-bold tracking-[0.2em] text-xs uppercase mb-4 block fade-in-up">Estamos para ayudarte</span>
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-6 fade-in-up delay-100">¿Tienes alguna duda?</h1>
            <p class="text-gray-300 text-lg max-w-2xl mx-auto fade-in-up delay-200">
                Nuestro equipo de soporte está listo para responder tus consultas sobre cursos, certificaciones o alianzas corporativas.
            </p>
        </div>
    </div>

    <!-- SECCIÓN FORMULARIO Y CONTACTO -->
    <div class="bg-gray-50 pb-24 relative">
        <!-- Margen superior añadido (mt-16) para separar del header -->
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-20 mt-16">
            <div class="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col lg:flex-row">
                
                <!-- INFO SIDEBAR (Izquierda) -->
                <div class="lg:w-1/3 bg-[#213A57] p-10 text-white relative overflow-hidden">
                    <div class="absolute bottom-0 right-0 w-64 h-64 bg-[#0AD1C8] opacity-10 rounded-full blur-[80px] pointer-events-none"></div>
                    
                    <h3 class="text-2xl font-bold mb-8">Información de Contacto</h3>
                    
                    <div class="space-y-8 relative z-10">
                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                                <i class="ph-fill ph-map-pin text-[#0AD1C8] text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-sm mb-1">Oficina Central</h4>
                                <p class="text-gray-300 text-sm leading-relaxed">Av. Raul Salmon NRO. 26 Of. 7, Zona 12 de Octubre. Ciudad de El Alto. La Paz, Bolivia.</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                                <i class="ph-fill ph-envelope text-[#0AD1C8] text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-sm mb-1">Correo Electrónico</h4>
                                <p class="text-gray-300 text-sm">capacitaciones@pachabol.com</p>
                                <p class="text-gray-300 text-sm">contacto@pachabol.com</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                                <i class="ph-fill ph-whatsapp-logo text-[#0AD1C8] text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-sm mb-1">WhatsApp / Teléfono</h4>
                                <p class="text-gray-300 text-sm">+591 62529911</p>
                                <p class="text-gray-500 text-xs mt-1">Lunes a Viernes, 8:00 - 17:00</p>
                            </div>
                        </div>
                    </div>

                    <!-- Redes Sociales -->
                    <div class="mt-12 pt-8 border-t border-white/10 flex gap-4">
                        <a href="https://www.facebook.com/pachaconsultingbolivia" class="w-10 h-10 rounded-full bg-white/5 hover:bg-[#0AD1C8] hover:text-[#213A57] flex items-center justify-center transition-all"><i class="ph-fill ph-facebook-logo text-xl"></i></a>
                        <a href="https://www.youtube.com/@pachaboloficial" class="w-10 h-10 rounded-full bg-white/5 hover:bg-[#0AD1C8] hover:text-[#213A57] flex items-center justify-center transition-all"><i class="ph-fill ph-youtube-logo text-xl"></i></a>
                        <a href="https://www.instagram.com/pachaconsultingbolivia/" class="w-10 h-10 rounded-full bg-white/5 hover:bg-[#0AD1C8] hover:text-[#213A57] flex items-center justify-center transition-all"><i class="ph-fill ph-instagram-logo text-xl"></i></a>
                    </div>
                </div>

                <!-- FORMULARIO (Derecha) -->
                <div class="lg:w-2/3 p-10 lg:p-16">
                    <form id="contactForm" class="space-y-6" onsubmit="sendToWhatsapp(event)">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Nombre Completo</label>
                                <input type="text" id="formName" class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:bg-white focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-[#213A57]" placeholder="Juan Pérez" required>
                            </div>
                            <div class="space-y-2">
                                <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Correo Electrónico</label>
                                <input type="email" id="formEmail" class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:bg-white focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-[#213A57]" placeholder="juan@ejemplo.com" required>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Asunto</label>
                            <select id="formSubject" class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:bg-white focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-[#213A57]">
                                <option>Información sobre cursos</option>
                                <option>Soporte técnico</option>
                                <option>Facturación</option>
                                <option>Alianzas / Empresas</option>
                            </select>
                        </div>

                        <div class="space-y-2">
                            <label class="text-xs font-bold text-gray-500 uppercase tracking-wider">Mensaje</label>
                            <textarea id="formMessage" rows="4" class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:bg-white focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none transition-all text-[#213A57]" placeholder="¿En qué podemos ayudarte?" required></textarea>
                        </div>

                        <button type="submit" class="px-8 py-4 bg-[#213A57] hover:bg-[#0B6477] text-white font-bold rounded-xl shadow-lg shadow-[#213A57]/20 transition-all transform hover:-translate-y-1 flex items-center gap-2">
                            Enviar Mensaje <i class="ph-bold ph-whatsapp-logo text-xl"></i>
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <!-- PREGUNTAS FRECUENTES (FAQ) -->
    <div class="py-24 bg-white">
        <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-3xl font-bold text-[#213A57] text-center mb-12">Preguntas Frecuentes</h2>
            
            <div class="space-y-4">
                <!-- FAQ 1 -->
                <details class="group bg-gray-50 rounded-2xl p-6 cursor-pointer open:bg-white open:shadow-lg open:border-gray-100 transition-all duration-300 border border-transparent">
                    <summary class="flex justify-between items-center font-bold text-[#213A57] list-none">
                        <span>¿Los certificados tienen validez oficial?</span>
                        <span class="bg-white group-open:bg-[#0AD1C8] group-open:text-white w-8 h-8 rounded-full flex items-center justify-center text-[#213A57] transition-colors"><i class="ph-bold ph-caret-down group-open:rotate-180 transition-transform"></i></span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed text-sm">
                        Sí, todos nuestros cursos técnicos están avalados por el colegio de ingenieros y cumplen con la normativa nacional vigente. Cada certificado incluye un código QR único para su validación instantánea.
                    </p>
                </details>

                <!-- FAQ 2 -->
                <details class="group bg-gray-50 rounded-2xl p-6 cursor-pointer open:bg-white open:shadow-lg open:border-gray-100 transition-all duration-300 border border-transparent">
                    <summary class="flex justify-between items-center font-bold text-[#213A57] list-none">
                        <span>¿Cuáles son los métodos de pago?</span>
                        <span class="bg-white group-open:bg-[#0AD1C8] group-open:text-white w-8 h-8 rounded-full flex items-center justify-center text-[#213A57] transition-colors"><i class="ph-bold ph-caret-down group-open:rotate-180 transition-transform"></i></span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed text-sm">
                        Aceptamos transferencias bancarias, pagos por QR simple y tarjetas de débito/crédito habilitadas para compras por internet.
                    </p>
                </details>

                <!-- FAQ 3 -->
                <details class="group bg-gray-50 rounded-2xl p-6 cursor-pointer open:bg-white open:shadow-lg open:border-gray-100 transition-all duration-300 border border-transparent">
                    <summary class="flex justify-between items-center font-bold text-[#213A57] list-none">
                        <span>¿El acceso a los cursos caduca?</span>
                        <span class="bg-white group-open:bg-[#0AD1C8] group-open:text-white w-8 h-8 rounded-full flex items-center justify-center text-[#213A57] transition-colors"><i class="ph-bold ph-caret-down group-open:rotate-180 transition-transform"></i></span>
                    </summary>
                    <p class="text-gray-600 mt-4 leading-relaxed text-sm">
                        No. Una vez compras un curso, tienes acceso de por vida al contenido y a sus futuras actualizaciones sin costo adicional.
                    </p>
                </details>
            </div>
        </div>
    </div>

    <!-- SCRIPT WHATSAPP -->
    <script>
    function sendToWhatsapp(e) {
        e.preventDefault();
        
        const name = document.getElementById('formName').value;
        const email = document.getElementById('formEmail').value;
        const subject = document.getElementById('formSubject').value;
        const message = document.getElementById('formMessage').value;
        
        const phone = "59162529911"; // Número de destino
        
        const text = `*HOLA YATI, TENGO UNA CONSULTA DESDE LA WEB*%0A%0A` +
                     `*Nombre:* ${name}%0A` +
                     `*Correo:* ${email}%0A` +
                     `*Asunto:* ${subject}%0A` +
                     `---------------------------------%0A` +
                     `*Mensaje:*%0A${message}`;
        
        window.open(`https://api.whatsapp.com/send?phone=${phone}&text=${text}`, '_blank');
    }
    </script>

</x-layouts.guest>