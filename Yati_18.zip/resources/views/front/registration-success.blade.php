<x-layouts.guest>
    <div class="min-h-screen pt-32 pb-20 bg-gray-50 flex items-center justify-center">
        <div class="max-w-lg w-full px-4 text-center">
            
            <div class="bg-white rounded-[2.5rem] shadow-2xl shadow-[#213A57]/10 p-10 relative overflow-hidden border border-gray-100">
                <!-- Decoración de fondo -->
                <div class="absolute -top-24 -right-24 w-48 h-48 bg-[#80ED99]/20 rounded-full blur-3xl"></div>
                
                <!-- Icono de Éxito Animado -->
                <div class="mb-8 relative inline-block">
                    <div class="absolute inset-0 bg-[#0AD1C8]/20 rounded-full animate-ping scale-150 opacity-20"></div>
                    <div class="relative w-24 h-24 bg-gradient-to-tr from-[#0B6477] to-[#0AD1C8] rounded-full flex items-center justify-center text-white shadow-xl shadow-[#0AD1C8]/30">
                        <i class="ph-fill ph-check-circle text-5xl"></i>
                    </div>
                </div>

                <h1 class="text-3xl font-extrabold text-[#213A57] mb-4">¡Registro Exitoso!</h1>
                
                <p class="text-gray-600 mb-6 leading-relaxed">
                    Hola <span class="font-bold text-[#0B6477]">{{ $data['name'] }}</span>, tu cuenta ha sido creada correctamente. 
                    Hemos recibido tu comprobante para el curso <br> 
                    <strong class="text-[#213A57] italic">"{{ $data['course'] }}"</strong>.
                </p>

                <div class="bg-[#F0FDFD] border border-[#0AD1C8]/20 rounded-2xl p-6 mb-8 text-left space-y-4">
                    <div class="flex gap-4">
                        <i class="ph-bold ph-shield-check text-[#0AD1C8] text-2xl shrink-0"></i>
                        <div>
                            <p class="text-sm font-bold text-[#213A57]">Pago en Revisión</p>
                            <p class="text-xs text-gray-500">Nuestro equipo validará tu boleta en un plazo máximo de 24 horas.</p>
                        </div>
                    </div>
                    <div class="flex gap-4">
                        <i class="ph-bold ph-user-circle text-[#0AD1C8] text-2xl shrink-0"></i>
                        <div>
                            <p class="text-sm font-bold text-[#213A57]">Perfil Activo</p>
                            <p class="text-xs text-gray-500">Ya puedes ingresar a la plataforma y configurar tu perfil de estudiante.</p>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col gap-3">
                    <a href="{{ route('login') }}" class="w-full py-4 bg-[#213A57] text-white font-bold rounded-2xl shadow-lg shadow-[#213A57]/20 hover:bg-[#0B6477] transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 text-lg">
                        Ir al Inicio de Sesión
                        <i class="ph-bold ph-sign-in"></i>
                    </a>
                </div>

                <p class="mt-8 text-xs text-gray-400">
                    ¿Tienes dudas? <a href="{{ route('contact') }}" class="text-[#0AD1C8] font-bold hover:underline">Contáctanos vía WhatsApp</a>
                </p>
            </div>
            
            <p class="mt-6 text-sm text-gray-400 font-medium">YATI Academy • Aprende sin límites</p>
        </div>
    </div>
</x-layouts.guest>