<div id="catalog-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    @forelse($courses as $course)
    @php
        // --- LÓGICA DE PRECIOS Y DESCUENTOS ---
        $originalPrice = floatval($course->price);
        $finalPrice = $originalPrice;
        $hasDiscount = false;
        $discountPercent = 0;

        // 1. Verificar atributo directo
        if (!empty($course->discount_price) && $course->discount_price > 0 && $course->discount_price < $originalPrice) {
            $finalPrice = floatval($course->discount_price);
            $hasDiscount = true;
        }
        // 2. Fallback: Verificar promoción y EXCLUSIONES
        elseif ($course->promotion) {
             $promo = $course->promotion;
             
             // --- CORRECCIÓN EXCLUSIONES (Decodificar JSON) ---
             $exceptions = $promo->exception_ids;
             if (is_string($exceptions)) {
                 $exceptions = json_decode($exceptions, true);
             }
             if (!is_array($exceptions)) {
                 $exceptions = [];
             }

             // Si el ID está en excepciones, NO aplicar descuento
             if (!in_array($course->id, $exceptions)) {
                 $now = now();
                 $start = $promo->start_date ? \Carbon\Carbon::parse($promo->start_date) : null;
                 $end = $promo->end_date ? \Carbon\Carbon::parse($promo->end_date) : null;
                 $isActive = true;

                 if ($start && $now->lt($start)) $isActive = false;
                 if ($end && $now->gt($end)) $isActive = false;

                 if($isActive) {
                     if($promo->discount_type == 'percent') {
                         $finalPrice = $originalPrice - ($originalPrice * ($promo->value / 100));
                         $hasDiscount = true;
                     } elseif($promo->discount_type == 'fixed') {
                         $finalPrice = $originalPrice - $promo->value;
                         $hasDiscount = true;
                     }
                 }
             }
        }

        // Calcular porcentaje
        if ($hasDiscount && $originalPrice > 0) {
            $discountPercent = round((($originalPrice - $finalPrice) / $originalPrice) * 100);
            if ($discountPercent < 1) $hasDiscount = false;
        }

        // --- PREPARAR WHATSAPP ---
        $whatsappNumber = "59162529911"; 
        $startDate = isset($course->metadata['start_date']) ? \Carbon\Carbon::parse($course->metadata['start_date'])->locale('es')->translatedFormat('d M, Y') : 'Inmediato';
        $courseUrl = route('course.show', $course->slug);
        $displayPrice = $hasDiscount ? $finalPrice : $originalPrice;
        $waMessage = "¡Hola YATI Academy! Me gustaría inscribirme en el curso: " . $course->title . 
                     ".\n\n*Precio:* Bs " . number_format($displayPrice, 0) . 
                     "\n*Link:* " . $courseUrl;
        $waUrl = "https://wa.me/" . $whatsappNumber . "?text=" . urlencode($waMessage);
    @endphp

    <!-- Tarjeta de curso -->
    <div class="fade-in-up group bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-[#0AD1C8]/10 hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col h-full relative">

        <!-- Imagen y Badge -->
        <div class="relative h-44 overflow-hidden bg-gray-200">
            <img src="{{ $course->cover_image ? asset($course->cover_image) : 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=600' }}"
                 class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
            
            <div class="absolute top-3 left-3 z-10">
                <span class="bg-[#213A57]/90 backdrop-blur text-white text-[9px] font-bold px-2 py-1 rounded shadow-sm flex items-center gap-1 uppercase tracking-wider">
                    <i class="ph-fill ph-certificate text-[#0AD1C8]"></i> Certificado QR
                </span>
            </div>

            <!-- Badge Descuento -->
            @if($hasDiscount)
            <div class="absolute top-3 right-3 z-10">
                <span class="bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm uppercase tracking-wider animate-pulse">
                    -{{ $discountPercent }}%
                </span>
            </div>
            @endif
        </div>

        <!-- Contenido -->
        <div class="p-5 flex-1 flex flex-col">
            <div class="mb-2">
                <span class="text-[10px] font-bold text-[#0B6477] uppercase tracking-wider bg-[#E0F9F6] px-2 py-0.5 rounded">
                    {{ $course->categories->first()->name ?? 'Especialidad' }}
                </span>
            </div>

            <h3 class="font-bold text-[#213A57] text-md leading-tight mb-4 group-hover:text-[#0B6477] transition-colors min-h-[2.5rem] line-clamp-2">
                {{ $course->title }}
            </h3>

            <!-- Información Clave -->
            <div class="space-y-2 mb-4 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <div class="flex items-center gap-2 text-xs text-gray-600">
                    <i class="ph-bold ph-calendar text-[#0AD1C8]"></i>
                    <span class="font-medium">Inicio: </span>
                    <span class="text-[#213A57] font-bold">{{ $startDate }}</span>
                </div>
                <div class="flex items-center gap-2 text-xs text-gray-600">
                    <i class="ph-bold ph-video-camera text-[#0AD1C8]"></i>
                    <span class="font-medium">Modalidad: </span>
                    <span class="text-[#213A57] font-bold">{{ $course->metadata['modality'] ?? 'Virtual' }}</span>
                </div>
            </div>

            <div class="flex flex-col gap-3 mt-auto">
                <div class="flex items-center justify-between border-b border-gray-50 pb-3">
                    <span class="text-[10px] text-gray-400 uppercase font-bold">Precio</span>
                    <div class="text-right">
                        @if($hasDiscount)
                            <span class="block text-xs text-gray-400 line-through">Bs {{ number_format($originalPrice, 0) }}</span>
                            <span class="text-xl font-extrabold text-[#0AD1C8]">Bs {{ number_format($finalPrice, 0) }}</span>
                        @else
                            <span class="text-xl font-extrabold text-[#213A57]">Bs {{ number_format($originalPrice, 0) }}</span>
                        @endif
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-2">
                    <a href="{{ $waUrl }}" target="_blank" class="bg-[#0AD1C8] text-white text-center py-2.5 rounded-xl font-bold text-xs hover:bg-[#0B6477] transition-all shadow-md flex items-center justify-center gap-1 group/wa">
                        <i class="ph-fill ph-whatsapp-logo text-lg"></i> Inscribirme
                    </a>
                    <a href="{{ route('course.show', $course->slug) }}" class="bg-[#213A57] text-white text-center py-2.5 rounded-xl font-bold text-xs hover:bg-[#1a2e45] transition-all shadow-md flex items-center justify-center gap-1">
                        <i class="ph-bold ph-eye text-lg"></i> Ver Detalles
                    </a>
                </div>
            </div>
        </div>
        <div class="h-1 bg-[#0AD1C8] w-0 group-hover:w-full transition-all duration-500"></div>
    </div>
    @empty
        <div class="col-span-full text-center py-20">
            <i class="ph-bold ph-magnifying-glass text-5xl text-gray-200 mb-4"></i>
            <p class="text-gray-400">No se encontraron cursos disponibles.</p>
        </div>
    @endforelse
</div>

<!-- Conteo oculto para actualizar vía JS -->
<span id="js-course-count-value" class="hidden">{{ $courses->total() }}</span>