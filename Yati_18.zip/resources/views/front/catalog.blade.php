<x-layouts.guest>

    <!-- CABECERA DE PÁGINA -->
    <div class="relative bg-[#213A57] pt-32 pb-16 overflow-hidden">
        <div class="absolute inset-0 z-0">
            <div class="absolute top-0 right-0 w-[500px] h-[600px] bg-[#0AD1C8] opacity-10 rounded-full blur-[120px] pointer-events-none"></div>
            <div class="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[#45DFB1] opacity-5 rounded-full blur-[80px] pointer-events-none"></div>
            <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3N2Zz4=')] opacity-20"></div>
        </div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h1 class="text-3xl md:text-5xl font-bold text-white mb-4 fade-in-up">Catálogo de Cursos</h1>
            <p class="text-gray-300 text-lg max-w-2xl mx-auto fade-in-up delay-100">
                Explora nuestra oferta académica y encuentra la especialización que impulsará tu carrera profesional.
            </p>
        </div>
    </div>

    <!-- SECCIÓN PRINCIPAL -->
    <div class="bg-gray-50 min-h-screen py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col lg:flex-row gap-10">
                
                <!-- BARRA LATERAL DE FILTROS -->
                <aside class="w-full lg:w-1/4 space-y-8 fade-in-up delay-200">
                    <form id="filter-form" method="GET" action="{{ route('catalog') }}">
                        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                            <h3 class="font-bold text-[#213A57] mb-4 flex items-center gap-2">
                                <i class="ph-fill ph-squares-four text-[#0AD1C8]"></i> Categorías
                            </h3>
                            <div class="space-y-3">
                                <label class="flex items-center gap-3 cursor-pointer group">
                                    <div class="relative flex items-center">
                                        <input type="checkbox" id="check-all" class="peer h-5 w-5 cursor-pointer appearance-none rounded-md border border-gray-300 transition-all checked:border-[#0AD1C8] checked:bg-[#0AD1C8]" {{ !request()->has('categories') ? 'checked' : '' }}>
                                        <i class="ph-bold ph-check absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white opacity-0 peer-checked:opacity-100 text-xs"></i>
                                    </div>
                                    <span class="text-gray-600 group-hover:text-[#0B6477] transition-colors text-sm">Todas las áreas</span>
                                </label>

                                @foreach($categories as $category)
                                    <label class="flex items-center gap-3 cursor-pointer group">
                                        <div class="relative flex items-center">
                                            <input type="checkbox" name="categories[]" value="{{ $category->id }}" class="category-checkbox peer h-5 w-5 cursor-pointer appearance-none rounded-md border border-gray-300 transition-all checked:border-[#0AD1C8] checked:bg-[#0AD1C8]" {{ in_array($category->id, request()->get('categories', [])) ? 'checked' : '' }}>
                                            <i class="ph-bold ph-check absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white opacity-0 peer-checked:opacity-100 text-xs"></i>
                                        </div>
                                        <span class="text-gray-600 group-hover:text-[#0B6477] transition-colors text-sm">{{ $category->name }}</span>
                                        <span class="ml-auto text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{{ $category->courses_count }}</span>
                                    </label>
                                @endforeach
                            </div>
                        </div>
                    </form>
                </aside>

                <!-- CUADRÍCULA DE CURSOS -->
                <div class="w-full lg:w-3/4">
                    <div class="flex flex-col md:flex-row justify-between items-center mb-8 gap-4 fade-in-up delay-200">
                        <p class="text-gray-500 text-sm">
                            <span id="course-count" class="font-bold text-[#213A57]">{{ $courses->total() }}</span> cursos encontrados
                        </p>
                        
                        <div class="flex gap-4 w-full md:w-auto">
                            <div class="relative w-full md:w-64">
                                <i class="ph-bold ph-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                <input type="text" id="search-input" name="search" value="{{ request('search') }}" placeholder="Buscar curso..." class="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:border-[#0AD1C8] focus:ring-2 focus:ring-[#0AD1C8]/20 outline-none text-sm transition-all">
                            </div>
                        </div>
                    </div>

                    <div id="catalog-container" class="relative min-h-[400px]">
                        @include('front.partials.catalog-grid')
                        
                        <!-- Pantalla de carga -->
                        <div id="grid-loader" class="hidden absolute inset-0 bg-white/50 backdrop-blur-[1px] z-30 flex items-center justify-center rounded-2xl">
                            <div class="flex flex-col items-center gap-2">
                                <div class="animate-spin rounded-full h-10 w-10 border-b-2 border-[#0AD1C8]"></div>
                                <span class="text-xs font-bold text-[#213A57] uppercase tracking-widest">Filtrando resultados...</span>
                            </div>
                        </div>
                    </div>

                    <!-- PAGINACIÓN -->
                    <div id="pagination-container" class="mt-12 flex justify-center">
                        {{ $courses->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('filter-form');
        const searchInput = document.getElementById('search-input');
        const container = document.getElementById('catalog-container');
        const loader = document.getElementById('grid-loader');
        const countDisplay = document.getElementById('course-count');
        const checkAll = document.getElementById('check-all');
        const categoryChecks = document.querySelectorAll('.category-checkbox');
        
        let timeout = null;

        // Proceso AJAX para actualizar el contenido sin recargar la página
        const updateCatalog = (url = null) => {
            if(loader) loader.classList.remove('hidden');
            
            if (!url) {
                const formData = new FormData(form);
                if (searchInput) formData.append('search', searchInput.value);
                const params = new URLSearchParams(formData);
                url = `{{ route('catalog') }}?${params.toString()}`;
            }
            
            fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.text())
            .then(html => {
                container.innerHTML = html;
                const newCount = document.getElementById('js-course-count-value');
                if(newCount) countDisplay.innerText = newCount.innerText;
                
                if(loader) loader.classList.add('hidden');
            })
            .catch(err => {
                console.error('Error al actualizar el catálogo:', err);
                if(loader) loader.classList.add('hidden');
            });
        };

        // Búsqueda de cursos (Debounce para evitar peticiones excesivas)
        if(searchInput) {
            searchInput.addEventListener('input', () => {
                clearTimeout(timeout);
                timeout = setTimeout(() => updateCatalog(), 500);
            });
        }

        // Selección de categorías
        categoryChecks.forEach(check => {
            check.addEventListener('change', () => {
                if (check.checked) checkAll.checked = false;
                const anyChecked = Array.from(categoryChecks).some(c => c.checked);
                if (!anyChecked) checkAll.checked = true;
                updateCatalog();
            });
        });

        // Opción "Todas las áreas"
        checkAll.addEventListener('change', () => {
            if (checkAll.checked) {
                categoryChecks.forEach(c => c.checked = false);
                updateCatalog();
            }
        });

        // Intercepción de clicks en la paginación para usar AJAX
        document.addEventListener('click', (e) => {
            const link = e.target.closest('#pagination-container a, .pagination a');
            if (link) {
                e.preventDefault();
                updateCatalog(link.href);
                window.scrollTo({ top: 300, behavior: 'smooth' });
            }
        });
    });
    </script>
</x-layouts.guest>