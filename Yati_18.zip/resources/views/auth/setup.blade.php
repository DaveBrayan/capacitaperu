<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Perfil - YATI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .floating-input:focus ~ label, .floating-input:not(:placeholder-shown) ~ label {
            transform: translateY(-24px) scale(0.85); color: #0AD1C8;
        }
        .animate-gradient { background-size: 200% 200%; animation: gradientMove 6s ease infinite; }
        @keyframes gradientMove { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        /* Estilo para avatar seleccionado */
        .avatar-option.selected { border-color: #0AD1C8; background-color: #E0F9F6; }
        .avatar-option.selected img { transform: scale(0.9); }
    </style>
</head>
<body class="bg-gray-50 h-screen w-full overflow-hidden flex">

    {{-- LÓGICA INTELIGENTE DE ESTADO --}}
    @php
        $user = Auth::user();
        $isStudent = Auth::guard('student')->check();
        
        // 1. ¿Faltan datos de perfil? (Solo estudiantes)
        $missingProfile = $isStudent && (empty($user->ci_nit) || empty($user->phone));
        
        // 2. ¿Falta PIN? (Usuario nuevo o Reset de PIN)
        $missingPin = is_null($user->pin);
        
        // 3. DETERMINAR QUÉ MOSTRAR
        $showProfile = $missingProfile;
        
        // Mostrar PIN si falta
        $showPin = $missingPin;
        
        // Mostrar Password SI: 
        // A) Es usuario nuevo (falta perfil) -> Pide todo.
        // B) O el PIN NO falta (significa que solo se reseteó la contraseña).
        // C) Si solo se reseteó el PIN ($missingPin=true y perfil ok), NO muestra password.
        $showPassword = $missingProfile || !$missingPin;

        // Textos Dinámicos
        $titleText = "Configura tu cuenta";
        $subtitleText = "Actualiza tus credenciales para continuar.";
        
        if ($showProfile) {
            $titleText = "Completa tu Perfil";
            $subtitleText = "Elige tu avatar y valida tus datos.";
        } elseif ($showPin && !$showPassword) {
            $titleText = "Configura tu PIN";
            $subtitleText = "Crea un nuevo código de seguridad.";
        } elseif ($showPassword && !$showPin) {
            $titleText = "Cambia tu Contraseña";
            $subtitleText = "Establece una nueva contraseña segura.";
        }
    @endphp

    <!-- Lado Izquierdo (Imagen/Info) -->
    <div class="hidden lg:flex lg:w-5/12 relative bg-[#213A57] items-center justify-center overflow-hidden">
        <div class="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=2000&auto=format&fit=crop" class="w-full h-full object-cover opacity-40 mix-blend-overlay">
            <div class="absolute inset-0 bg-gradient-to-br from-[#213A57] to-[#0B6477] opacity-90"></div>
        </div>
        <div class="relative z-10 p-12 text-white max-w-lg">
            <div class="flex items-center gap-3 mb-8">
                <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#0AD1C8] to-[#45DFB1] flex items-center justify-center text-[#213A57] shadow-lg">
                    <i class="ph-bold ph-student text-2xl"></i>
                </div>
                <span class="font-bold text-3xl tracking-wide">YATI</span>
            </div>
            
            <h2 class="text-4xl font-bold mb-6 leading-tight">{!! str_replace(['Perfil', 'Seguridad', 'PIN', 'Contraseña'], ['<span class="text-[#0AD1C8]">Perfil</span>', '<span class="text-[#0AD1C8]">Seguridad</span>', '<span class="text-[#0AD1C8]">PIN</span>', '<span class="text-[#0AD1C8]">Contraseña</span>'], $titleText) !!}</h2>
            <p class="text-gray-300 text-lg font-light">{{ $subtitleText }}</p>
        </div>
    </div>

    <!-- Lado Derecho (Formulario) -->
    <div class="w-full lg:w-7/12 flex items-center justify-center p-4 lg:p-8 relative h-full overflow-y-auto no-scrollbar">
        <div class="w-full max-w-2xl bg-white rounded-[2rem] shadow-xl p-8 md:p-10 relative z-10 my-auto border border-gray-100">
            
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold text-[#213A57] mb-2">¡Hola, {{ explode(' ', Auth::user()->name)[0] }}! 👋</h3>
                <p class="text-gray-500 text-sm">
                    @if($showProfile) Vamos a configurar tu cuenta.
                    @elseif($showPin && !$showPassword) Solo necesitamos restablecer tu PIN.
                    @elseif($showPassword && !$showPin) Solo necesitamos restablecer tu contraseña.
                    @else Actualiza tus credenciales. @endif
                </p>
            </div>

            @if ($errors->any())
                <div class="mb-6 p-4 rounded-xl bg-red-50 border border-red-100 flex items-start gap-3 text-red-600 text-sm">
                    <i class="ph-fill ph-warning-circle text-xl shrink-0 mt-0.5"></i>
                    <ul class="list-disc list-inside">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('auth.setup.store') }}" method="POST">
                @csrf

                <!-- SECCIÓN 1: DATOS DEL PERFIL (Solo si faltan) -->
                @if($showProfile)
                <div class="mb-8 animate-fade-in-up">
                    <div class="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
                        <i class="ph-fill ph-user-circle text-[#0AD1C8] text-xl"></i>
                        <h4 class="font-bold text-[#213A57]">Elige tu Avatar</h4>
                    </div>

                    <!-- Grid de Avatares Locales -->
                    <div class="grid grid-cols-4 sm:grid-cols-6 gap-4 mb-8">
                        <input type="hidden" name="avatar" id="selected_avatar_input">
                        @if(isset($localAvatars) && count($localAvatars) > 0)
                            @foreach($localAvatars as $path)
                                <div onclick="selectAvatar('{{ asset($path) }}', this)" 
                                     class="avatar-option cursor-pointer aspect-square rounded-full border-2 border-transparent p-1 transition-all hover:scale-105">
                                    <img src="{{ asset($path) }}" class="w-full h-full rounded-full object-cover bg-gray-100 shadow-sm pointer-events-none">
                                </div>
                            @endforeach
                        @else
                            <p class="col-span-full text-center text-sm text-gray-400 italic">No hay avatares disponibles.</p>
                        @endif
                    </div>

                    <div class="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
                        <i class="ph-fill ph-identification-card text-[#0AD1C8] text-xl"></i>
                        <h4 class="font-bold text-[#213A57]">Datos Personales</h4>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5 w-full">
                        <div class="relative group">
                            <input type="text" name="ci_nit" value="{{ old('ci_nit') }}" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="CI / DNI" required>
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">CI / DNI</label>
                        </div>

                        <!-- PAÍS -->
                        <div class="relative group">
                            <select name="country" id="country_select" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all appearance-none" required onchange="handleCountryChange()">
                                <option value="" disabled selected>Cargando países...</option>
                            </select>
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1 transform -translate-y-6 scale-75 origin-[0]">País</label>
                            <i class="ph-bold ph-globe-hemisphere-west absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"></i>
                        </div>

                        <!-- ESTADO / DEPARTAMENTO -->
                        <div class="relative group">
                            <select name="city" id="state_select" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all appearance-none" required disabled>
                                <option value="" disabled selected>Selecciona primero un país</option>
                            </select>
                            <input type="text" id="state_input" class="hidden floating-input w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Escribe tu departamento">
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1 transform -translate-y-6 scale-75 origin-[0]">Departamento / Estado</label>
                            <i class="ph-bold ph-caret-down absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" id="state_icon"></i>
                        </div>

                         <div class="relative group">
                            <input type="text" name="phone" id="phone_input" value="{{ old('phone') }}" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Celular" required>
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">Celular / WhatsApp</label>
                        </div>
                    </div>
                </div>
                @endif

                <!-- SECCIÓN 2: SEGURIDAD (Condicional) -->
                @if($showPin || $showPassword)
                <div class="animate-fade-in-up" style="animation-delay: 0.1s">
                    <div class="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
                        <i class="ph-fill ph-lock-key text-[#0AD1C8] text-xl"></i>
                        <h4 class="font-bold text-[#213A57]">Seguridad de Acceso</h4>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        
                        <!-- PIN (Solo si falta) -->
                        @if($showPin)
                        <div class="relative group md:col-span-2">
                            <div class="flex items-center justify-between mb-2">
                                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider">PIN de Acceso Rápido</p>
                                <span class="text-[10px] text-[#0AD1C8] bg-[#E0F9F6] px-2 py-0.5 rounded-md font-bold">4 Dígitos</span>
                            </div>
                            <div class="relative">
                                <input type="password" name="pin" maxlength="4" class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all tracking-[1em] text-center font-bold text-lg" placeholder="----" required oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                                <i class="ph-bold ph-numpad absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-xl"></i>
                            </div>
                        </div>
                        @endif

                        <!-- PASSWORD (Solo si corresponde) -->
                        @if($showPassword)
                        <div class="relative group">
                            <input type="password" name="password" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Pass" required>
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">Nueva Contraseña</label>
                        </div>

                        <div class="relative group">
                            <input type="password" name="password_confirmation" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Confirm" required>
                            <label class="absolute left-4 top-3 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">Repetir Contraseña</label>
                        </div>
                        @endif
                    </div>
                </div>
                @endif

                <button type="submit" class="w-full py-4 rounded-xl font-bold text-white text-lg shadow-xl shadow-[#0AD1C8]/30 hover:shadow-[#0AD1C8]/50 hover:-translate-y-1 transition-all bg-gradient-to-r from-[#0B6477] via-[#0AD1C8] to-[#0B6477] bg-[length:200%_auto] animate-gradient mt-8 flex items-center justify-center gap-2">
                    <span>Guardar y Acceder</span>
                    <i class="ph-bold ph-arrow-right"></i>
                </button>
            </form>
        </div>
    </div>

    <script>
        function selectAvatar(url, element) {
            const urlObj = new URL(url);
            const relativePath = urlObj.pathname.substring(1); 
            document.getElementById('selected_avatar_input').value = relativePath;
            document.querySelectorAll('.avatar-option').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
        }

        // --- LÓGICA ROBUSTA DE PAÍSES ---
        const fallbackCountries = [
            { name: "Bolivia", dial_code: "+591" },
            { name: "Argentina", dial_code: "+54" },
            { name: "Chile", dial_code: "+56" },
            { name: "Perú", dial_code: "+51" },
            { name: "Colombia", dial_code: "+57" },
            { name: "México", dial_code: "+52" },
            { name: "España", dial_code: "+34" },
            { name: "Ecuador", dial_code: "+593" },
            { name: "Estados Unidos", dial_code: "+1" }
        ];

        document.addEventListener('DOMContentLoaded', async () => {
            const select = document.getElementById('country_select');
            if (select) { // Solo ejecutar si se está mostrando el perfil
                await initLocationLogic(select);
            }
        });

        async function initLocationLogic(select) {
            try {
                const response = await fetch('https://countriesnow.space/api/v0.1/countries/codes');
                const data = await response.json();
                if(!data.error && data.data) populateCountries(data.data, select);
                else throw new Error("API Error");
            } catch (error) {
                console.warn("API Countries falló, usando fallback.");
                populateCountries(fallbackCountries, select);
            }
            await detectUserCountry(select);
        }

        function populateCountries(countriesData, select) {
            select.innerHTML = '<option value="" disabled selected>Selecciona tu país</option>';
            const bolivia = countriesData.find(c => c.name.toLowerCase().includes('bolivia'));
            if(bolivia) createOption(select, bolivia, 'Bolivia');
            const sorted = countriesData.sort((a, b) => a.name.localeCompare(b.name));
            sorted.forEach(c => { if(!c.name.toLowerCase().includes('bolivia')) createOption(select, c); });
            const other = document.createElement('option');
            other.value = 'Otro'; other.innerText = 'Otro / No está en la lista';
            select.appendChild(other);
        }

        function createOption(select, data, overrideName = null) {
            const opt = document.createElement('option');
            opt.value = overrideName || data.name;
            opt.innerText = overrideName || data.name;
            opt.setAttribute('data-dial', data.dial_code);
            select.appendChild(opt);
        }

        async function detectUserCountry(select) {
            try {
                const response = await fetch('https://ipapi.co/json/');
                const data = await response.json();
                let countryName = data.country_name || 'Bolivia';
                if(countryName.includes('Bolivia')) countryName = 'Bolivia';
                let exists = [...select.options].some(o => o.value === countryName);
                select.value = exists ? countryName : 'Bolivia';
                handleCountryChange();
            } catch (e) {
                select.value = 'Bolivia';
                handleCountryChange();
            }
        }

        async function handleCountryChange() {
            const countrySelect = document.getElementById('country_select');
            const stateSelect = document.getElementById('state_select');
            const phoneInput = document.getElementById('phone_input');
            const country = countrySelect.value;
            const selectedOpt = countrySelect.options[countrySelect.selectedIndex];

            if(selectedOpt && selectedOpt.getAttribute('data-dial')) {
                const code = selectedOpt.getAttribute('data-dial');
                if(!phoneInput.value || phoneInput.value.startsWith('+')) phoneInput.value = code + ' ';
            }

            if (country === 'Otro') { toggleManualInput(true); return; }

            toggleManualInput(false);
            stateSelect.disabled = true;
            stateSelect.innerHTML = '<option disabled selected>Cargando...</option>';

            try {
                const response = await fetch('https://countriesnow.space/api/v0.1/countries/states', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ country: country })
                });
                const data = await response.json();
                stateSelect.innerHTML = '<option value="" disabled selected>Selecciona Departamento</option>';
                stateSelect.disabled = false;

                if (!data.error && data.data.states.length > 0) {
                    data.data.states.forEach(s => {
                        const opt = document.createElement('option');
                        let name = s.name.replace(' Department', '').replace(' Province', '');
                        opt.value = name; opt.innerText = name;
                        stateSelect.appendChild(opt);
                    });
                } else { toggleManualInput(true); }
            } catch (e) { toggleManualInput(true); }
        }

        function toggleManualInput(isManual) {
            const stateSelect = document.getElementById('state_select');
            const stateInput = document.getElementById('state_input');
            const icon = document.getElementById('state_icon');

            if (isManual) {
                stateSelect.classList.add('hidden'); stateSelect.removeAttribute('name'); stateSelect.removeAttribute('required');
                stateInput.classList.remove('hidden'); stateInput.setAttribute('name', 'city'); stateInput.setAttribute('required', 'required'); stateInput.placeholder = "Escribe tu departamento/ciudad";
                icon.classList.add('hidden');
            } else {
                stateSelect.classList.remove('hidden'); stateSelect.setAttribute('name', 'city'); stateSelect.setAttribute('required', 'required');
                stateInput.classList.add('hidden'); stateInput.removeAttribute('name'); stateInput.removeAttribute('required');
                icon.classList.remove('hidden');
            }
        }
    </script>
</body>
</html>