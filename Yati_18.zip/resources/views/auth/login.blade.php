<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - YATI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .floating-input:focus ~ label, .floating-input:not(:placeholder-shown) ~ label {
            transform: translateY(-24px) scale(0.85); color: #0AD1C8;
        }
        .animate-gradient { background-size: 200% 200%; animation: gradientMove 6s ease infinite; }
        @keyframes gradientMove { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        
        /* Animación de Tabs */
        .tab-content { display: none; animation: fadeIn 0.3s ease-out; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-gray-50 h-screen w-full overflow-hidden flex">

    <!-- Lado Izquierdo (Igual) -->
    <div class="hidden lg:flex lg:w-1/2 relative bg-[#213A57] items-center justify-center overflow-hidden">
        <div class="absolute inset-0 z-0">
            <img src="https://images.unsplash.com/photo-1581094794329-cd1361dca68f?q=80&w=2000&auto=format&fit=crop" class="w-full h-full object-cover opacity-40 mix-blend-overlay">
            <div class="absolute inset-0 bg-gradient-to-br from-[#213A57] to-[#0B6477] opacity-90"></div>
        </div>
        <div class="relative z-10 p-12 text-white max-w-lg">
            <div class="flex items-center gap-3 mb-8">
                <div class="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#0AD1C8] to-[#45DFB1] flex items-center justify-center text-[#213A57] shadow-lg">
                    <i class="ph-bold ph-student text-2xl"></i>
                </div>
                <span class="font-bold text-3xl tracking-wide">YATI</span>
            </div>
            <h2 class="text-4xl font-bold mb-6 leading-tight">Accede a tu <span class="text-[#0AD1C8]">espacio profesional.</span></h2>
            <p class="text-gray-300 text-lg font-light">Gestiona tus cursos, certificaciones y progreso en un solo lugar.</p>
        </div>
    </div>

    <!-- Lado Derecho (Formulario) -->
    <div class="w-full lg:w-1/2 flex items-center justify-center p-8 relative">
        <div class="w-full max-w-md bg-white rounded-[2rem] shadow-2xl p-8 md:p-12 relative z-10">
            
            <div class="text-center mb-8">
                <h3 class="text-2xl font-bold text-[#213A57] mb-2">¡Bienvenido! 👋</h3>
                <p class="text-gray-500 text-sm">Elige cómo quieres ingresar.</p>
            </div>

            <!-- TABS -->
            <div class="flex p-1 bg-gray-100 rounded-xl mb-8 relative">
                <!-- Fondo animado del tab activo -->
                <div id="tab-bg" class="absolute left-1 top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-lg shadow-sm transition-all duration-300 ease-out"></div>
                
                <button onclick="switchTab('password')" class="flex-1 py-2 text-sm font-bold text-[#213A57] relative z-10 transition-colors" id="btn-password">
                    Contraseña
                </button>
                <button onclick="switchTab('pin')" class="flex-1 py-2 text-sm font-medium text-gray-500 relative z-10 transition-colors" id="btn-pin">
                    PIN Rápido
                </button>
            </div>

            @if ($errors->any())
                <div class="mb-6 p-3 rounded-lg bg-red-50 border border-red-100 flex gap-2 text-red-600 text-sm">
                    <i class="ph-fill ph-warning-circle text-lg"></i>
                    <div>{{ $errors->first() }}</div>
                </div>
            @endif

            <form action="{{ route('login.post') }}" method="POST" class="space-y-6">
                @csrf
                <!-- Campo oculto que cambia según el tab -->
                <input type="hidden" name="login_type" id="login_type" value="password">

                <!-- Email (Común para ambos) -->
                <div class="relative group">
                    <input type="email" name="email" value="{{ old('email') }}" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3.5 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Email" required>
                    <label class="absolute left-4 top-3.5 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3.5 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">Correo Electrónico</label>
                    <i class="ph-bold ph-envelope absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                </div>

                <!-- CONTRASEÑA -->
                <div id="tab-password" class="tab-content active relative group">
                    <input type="password" id="input-password" name="password" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3.5 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent" placeholder="Pass">
                    <label class="absolute left-4 top-3.5 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3.5 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">Contraseña</label>
                    <i class="ph-bold ph-lock-key absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                </div>

                <!-- PIN (Oculto al inicio) -->
                <div id="tab-pin" class="tab-content relative group">
                    <input type="password" id="input-pin" maxlength="4" class="floating-input peer w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3.5 text-[#213A57] focus:outline-none focus:ring-2 focus:ring-[#0AD1C8] transition-all placeholder-transparent tracking-[1em] text-center font-bold text-xl" placeholder="PIN">
                    <label class="absolute left-4 top-3.5 text-gray-400 text-sm transition-all pointer-events-none peer-placeholder-shown:text-base peer-placeholder-shown:top-3.5 peer-focus:-top-2 peer-focus:text-xs peer-focus:text-[#0AD1C8] bg-white px-1">PIN de 4 dígitos</label>
                    <i class="ph-bold ph-numpad absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                </div>

                <div class="flex justify-between items-center text-sm">
                    <label class="flex items-center gap-2 cursor-pointer text-gray-500">
                        <input type="checkbox" name="remember" class="w-4 h-4 text-[#0AD1C8] border-gray-300 rounded focus:ring-[#0AD1C8]"> Recordarme
                    </label>
                    <a href="#" class="text-[#0AD1C8] font-bold hover:underline">¿Ayuda?</a>
                </div>

                <button type="submit" class="w-full py-4 rounded-xl font-bold text-white text-lg shadow-xl shadow-[#0AD1C8]/30 hover:shadow-[#0AD1C8]/50 hover:-translate-y-1 transition-all bg-gradient-to-r from-[#0B6477] via-[#0AD1C8] to-[#0B6477] bg-[length:200%_auto] animate-gradient">
                    Ingresar
                </button>
            </form>
        </div>
    </div>

    <script>
        function switchTab(type) {
            // Actualizar input oculto
            document.getElementById('login_type').value = type;
            
            // Mover fondo
            const bg = document.getElementById('tab-bg');
            bg.style.transform = type === 'password' ? 'translateX(0)' : 'translateX(100%)'; // Mueve 100% de su ancho + gap

            // Estilos de texto
            const btnPass = document.getElementById('btn-password');
            const btnPin = document.getElementById('btn-pin');
            
            if(type === 'password') {
                btnPass.classList.add('font-bold', 'text-[#213A57]');
                btnPass.classList.remove('font-medium', 'text-gray-500');
                btnPin.classList.add('font-medium', 'text-gray-500');
                btnPin.classList.remove('font-bold', 'text-[#213A57]');
                
                // Mostrar inputs
                document.getElementById('tab-password').classList.add('active');
                document.getElementById('tab-pin').classList.remove('active');
                
                // Gestionar 'name' attribute para que el request envíe el correcto
                document.getElementById('input-password').name = 'password';
                document.getElementById('input-pin').name = ''; // Quitar name al oculto
                document.getElementById('input-password').required = true;
                document.getElementById('input-pin').required = false;
            } else {
                btnPin.classList.add('font-bold', 'text-[#213A57]');
                btnPin.classList.remove('font-medium', 'text-gray-500');
                btnPass.classList.add('font-medium', 'text-gray-500');
                btnPass.classList.remove('font-bold', 'text-[#213A57]');
                
                document.getElementById('tab-pin').classList.add('active');
                document.getElementById('tab-password').classList.remove('active');
                
                document.getElementById('input-pin').name = 'password'; // Usamos 'password' como nombre genérico para el controlador
                document.getElementById('input-password').name = '';
                document.getElementById('input-pin').required = true;
                document.getElementById('input-password').required = false;
            }
        }
    </script>
</body>
</html>