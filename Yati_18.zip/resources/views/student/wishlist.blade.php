<x-layouts.student>
    <x-slot name="title">Lista de Deseos - YATI</x-slot>
    <x-slot name="header">Cursos Guardados</x-slot>

    <!-- Header con resumen -->
    <div class="flex items-center justify-between mb-8 fade-in-up">
        <div>
            <h1 class="text-3xl font-bold text-[#213A57]">Tu Lista de Deseos ❤️</h1>
            <p class="text-gray-500 mt-1">Cursos que has guardado para después.</p>
        </div>
        <button class="text-sm font-bold text-[#0AD1C8] hover:text-[#0B6477] transition-colors">
            Borrar todo
        </button>
    </div>

    <!-- GRID DE WISHLIST -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        
        <!-- CARD 1 -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group relative fade-in-up" style="animation-delay: 0.1s">
            <!-- Botón Eliminar (X) -->
            <button class="absolute top-3 right-3 z-20 w-8 h-8 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors shadow-sm" title="Eliminar de la lista">
                <i class="ph-bold ph-x"></i>
            </button>

            <div class="relative h-48 overflow-hidden">
                <img src="https://images.unsplash.com/photo-1497436072909-60f360e1d4b0?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                <!-- Overlay Precio -->
                <div class="absolute bottom-3 left-3 bg-[#213A57]/90 backdrop-blur px-3 py-1 rounded-lg text-white font-bold text-sm shadow-lg">
                    Bs 600
                </div>
            </div>
            
            <div class="p-5 flex-1 flex flex-col">
                <span class="text-[#0B6477] text-[10px] font-bold uppercase tracking-wider mb-2 bg-[#E0F9F6] w-fit px-2 py-0.5 rounded">Medio Ambiente</span>
                <h3 class="font-bold text-[#213A57] text-lg mb-2 leading-tight group-hover:text-[#0B6477] transition-colors">Auditor Interno ISO 14001:2015</h3>
                
                <div class="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <div class="flex text-[#F59E0B]"><i class="ph-fill ph-star"></i><span class="text-gray-600 ml-1 font-bold">5.0</span></div>
                    <span>•</span>
                    <span>60 Horas</span>
                </div>

                <button class="w-full py-3 bg-[#213A57] hover:bg-[#0B6477] text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#213A57]/20 group/btn mt-auto">
                    <i class="ph-bold ph-shopping-cart text-lg"></i>
                    Añadir al Carrito
                </button>
            </div>
        </div>

        <!-- CARD 2 -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group relative fade-in-up" style="animation-delay: 0.2s">
            <button class="absolute top-3 right-3 z-20 w-8 h-8 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors shadow-sm">
                <i class="ph-bold ph-x"></i>
            </button>

            <div class="relative h-48 overflow-hidden">
                <img src="https://images.unsplash.com/photo-1581092921461-eab62e97a780?q=80&w=600&auto=format&fit=crop" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700">
                <div class="absolute bottom-3 left-3 bg-[#213A57]/90 backdrop-blur px-3 py-1 rounded-lg text-white font-bold text-sm shadow-lg">
                    Bs 450
                </div>
            </div>
            
            <div class="p-5 flex-1 flex flex-col">
                <span class="text-[#0B6477] text-[10px] font-bold uppercase tracking-wider mb-2 bg-[#E0F9F6] w-fit px-2 py-0.5 rounded">Mantenimiento</span>
                <h3 class="font-bold text-[#213A57] text-lg mb-2 leading-tight group-hover:text-[#0B6477] transition-colors">Jefe de Mantenimiento Industrial</h3>
                
                <div class="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <div class="flex text-[#F59E0B]"><i class="ph-fill ph-star"></i><span class="text-gray-600 ml-1 font-bold">4.8</span></div>
                    <span>•</span>
                    <span>30 Horas</span>
                </div>

                <button class="w-full py-3 bg-[#213A57] hover:bg-[#0B6477] text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#213A57]/20 group/btn mt-auto">
                    <i class="ph-bold ph-shopping-cart text-lg"></i>
                    Añadir al Carrito
                </button>
            </div>
        </div>

        <!-- EMPTY STATE (Ejemplo visual de espacio vacío para futuras implementaciones) -->
        <!-- 
        <div class="col-span-full flex flex-col items-center justify-center py-20 text-center">
            <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center text-gray-300 mb-4">
                <i class="ph-fill ph-heart-break text-4xl"></i>
            </div>
            <h3 class="text-xl font-bold text-[#213A57]">Tu lista está vacía</h3>
            <p class="text-gray-500 mb-6">Explora el catálogo y guarda lo que te interesa.</p>
            <a href="/catalogo" class="px-6 py-2 bg-[#0AD1C8] text-white font-bold rounded-lg shadow-lg hover:bg-[#0B6477] transition-colors">Ir al Catálogo</a>
        </div> 
        -->

    </div>

    <!-- Sugerencias -->
    <div class="mt-16 pt-10 border-t border-gray-200">
        <h3 class="font-bold text-xl text-[#213A57] mb-6">Porque te interesó "Seguridad Industrial"</h3>
        <!-- Aquí iría un slider de recomendaciones -->
        <p class="text-sm text-gray-500 italic">Recomendaciones personalizadas pronto...</p>
    </div>

</x-layouts.student>