<x-layouts.student>
    <x-slot name="title">Mi Perfil - YATI</x-slot>
    <x-slot name="header">Configuración de Cuenta</x-slot>

    <style>
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .avatar-option.selected { border-color: #0AD1C8; transform: scale(1.1); background-color: #E0F9F6; box-shadow: 0 4px 12px rgba(10, 209, 200, 0.2); }
        .glass-card { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); }
    </style>

    <!-- MENSAJES FLASH FLOTANTES -->
    @if(session('success'))
        <div class="fixed top-24 right-8 z-50 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-4 rounded-2xl shadow-xl flex items-center gap-3 animate-bounce-in border border-white/20">
            <div class="bg-white/20 p-2 rounded-full"><i class="ph-bold ph-check text-xl"></i></div>
            <div>
                <p class="font-bold text-sm">¡Éxito!</p>
                <p class="text-xs text-white/90">{{ session('success') }}</p>
            </div>
        </div>
    @endif

    @if($errors->any())
        <div class="mb-6 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-600 text-sm flex gap-3 shadow-sm">
            <i class="ph-fill ph-warning-circle text-xl shrink-0 mt-0.5"></i>
            <ul class="list-disc list-inside space-y-1">
                @foreach($errors->all() as $error) <li>{{ $error }}</li> @endforeach
            </ul>
        </div>
    @endif

    <!-- CONTENEDOR PRINCIPAL -->
    <div class="h-[calc(100vh-140px)] flex flex-col xl:flex-row gap-6">
        
        <!-- 1. TARJETA DE RESUMEN (IZQUIERDA) -->
        <div class="xl:w-1/4 bg-white rounded-[2rem] p-0 shadow-lg shadow-gray-100/50 border border-gray-100 flex flex-col h-full overflow-hidden relative group">
            
            <!-- Fondo Decorativo -->
            <div class="absolute top-0 w-full h-32 bg-gradient-to-br from-[#213A57] to-[#0B6477]"></div>
            <div class="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -mr-10 -mt-10"></div>
            
            <!-- Contenido Scrollable -->
            <div class="flex-1 overflow-y-auto no-scrollbar relative z-10 flex flex-col p-6 pt-16 items-center">
                
                <!-- Avatar -->
                <div class="relative group/avatar cursor-pointer mb-4" onclick="openAvatarModal()">
                    <div class="w-36 h-36 rounded-full p-1.5 bg-white shadow-xl overflow-hidden mx-auto relative z-10">
                        <div class="w-full h-full rounded-full overflow-hidden border-4 border-[#E0F9F6]">
                            <img src="{{ Str::startsWith($student->avatar_url, 'http') ? $student->avatar_url : asset($student->avatar_url) }}" class="w-full h-full object-cover transition-transform duration-500 group-hover/avatar:scale-110">
                        </div>
                    </div>
                    <div class="absolute bottom-2 right-2 z-20 bg-[#0AD1C8] text-white p-2.5 rounded-full shadow-lg hover:bg-[#08b3ab] transition-all transform hover:scale-110 border-2 border-white">
                        <i class="ph-bold ph-camera text-lg"></i>
                    </div>
                </div>
                
                <h2 class="text-2xl font-bold text-[#213A57] leading-tight mb-1">{{ $student->name }}</h2>
                <span class="px-3 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold uppercase tracking-wider rounded-full border border-blue-100 mb-6">Estudiante Activo</span>
                
                <!-- Estadísticas -->
                <div class="w-full grid grid-cols-2 gap-3 mb-8">
                    <div class="bg-gradient-to-br from-[#E0F9F6] to-white p-4 rounded-2xl border border-[#E0F9F6] shadow-sm text-center">
                        <span class="block text-3xl font-bold text-[#0B6477] mb-1">{{ $student->enrollments->count() }}</span>
                        <span class="text-[10px] text-gray-400 uppercase font-bold tracking-wide">Cursos</span>
                    </div>
                    <div class="bg-gradient-to-br from-purple-50 to-white p-4 rounded-2xl border border-purple-50 shadow-sm text-center">
                        <span class="block text-3xl font-bold text-purple-600 mb-1">0</span>
                        <span class="text-[10px] text-gray-400 uppercase font-bold tracking-wide">Certificados</span>
                    </div>
                </div>

                <!-- Lista de Datos Rápidos -->
                <div class="w-full space-y-4">
                    <h4 class="text-xs font-bold text-gray-400 uppercase tracking-wider ml-1 mb-2">Información de Contacto</h4>
                    
                    <div class="group/item flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                        <div class="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                            <i class="ph-fill ph-envelope-simple text-lg"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-[10px] text-gray-400 uppercase font-bold">Correo</p>
                            <p class="font-medium text-[#213A57] text-sm truncate" title="{{ $student->email }}">{{ $student->email }}</p>
                        </div>
                    </div>

                    <div class="group/item flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                        <div class="w-10 h-10 rounded-full bg-green-50 text-green-600 flex items-center justify-center shrink-0">
                            <i class="ph-fill ph-whatsapp-logo text-lg"></i>
                        </div>
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase font-bold">Celular</p>
                            <p class="font-medium text-[#213A57] text-sm">{{ $student->phone ?? '--' }}</p>
                        </div>
                    </div>

                    <div class="group/item flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                        <div class="w-10 h-10 rounded-full bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
                            <i class="ph-fill ph-identification-card text-lg"></i>
                        </div>
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase font-bold">CI / DNI</p>
                            <p class="font-medium text-[#213A57] text-sm">{{ $student->ci_nit ?? '--' }}</p>
                        </div>
                    </div>

                    <div class="group/item flex items-center gap-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                        <div class="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                            <i class="ph-fill ph-map-pin text-lg"></i>
                        </div>
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase font-bold">Ubicación</p>
                            <p class="font-medium text-[#213A57] text-sm">{{ $student->city ?? 'No definida' }}, {{ $student->country ?? 'Bolivia' }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. DATOS PERSONALES (CENTRO) -->
        <div class="xl:w-2/5 bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100 flex flex-col h-full relative overflow-hidden">
            <div class="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-[#213A57] via-[#0AD1C8] to-[#0B6477]"></div>
            
            <div class="flex justify-between items-end mb-8">
                <div>
                    <h3 class="text-2xl font-bold text-[#213A57] flex items-center gap-2">
                        <i class="ph-duotone ph-user-gear text-[#0AD1C8]"></i> Editar Perfil
                    </h3>
                    <p class="text-sm text-gray-400 mt-1">Actualiza tu información personal</p>
                </div>
            </div>

            <form id="personalForm" action="{{ route('student.profile.update') }}" method="POST" class="flex-1 flex flex-col gap-6 overflow-y-auto pr-2 custom-scrollbar">
                @csrf
                @method('PUT')
                <input type="hidden" name="avatar" id="avatar_input_hidden">

                <!-- Nombre -->
                <div class="group">
                    <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">Nombre Completo</label>
                    <div class="relative">
                        <i class="ph-bold ph-user absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0AD1C8] transition-colors"></i>
                        <input type="text" name="name" value="{{ old('name', $student->name) }}" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57]">
                    </div>
                </div>

                <!-- Grid 2 cols -->
                <div class="grid grid-cols-2 gap-5">
                    <!-- CI / DNI -->
                    <div class="group">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">CI / DNI</label>
                        <div class="relative">
                            <i class="ph-bold ph-identification-badge absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0AD1C8] transition-colors"></i>
                            <input type="text" name="ci_nit" value="{{ old('ci_nit', $student->ci_nit) }}" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57]">
                        </div>
                    </div>

                    <!-- Teléfono -->
                    <div class="group">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">Teléfono</label>
                        <div class="relative">
                            <i class="ph-bold ph-phone absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0AD1C8] transition-colors"></i>
                            <input type="text" name="phone" value="{{ old('phone', $student->phone) }}" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57]">
                        </div>
                    </div>
                </div>

                <!-- Grid 2 cols: País y Ciudad -->
                <div class="grid grid-cols-2 gap-5">
                    <!-- País (Select simple por ahora, editable) -->
                    <div class="group">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">País</label>
                        <div class="relative">
                            <i class="ph-bold ph-globe-hemisphere-west absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0AD1C8] transition-colors"></i>
                            <input type="text" name="country" value="{{ old('country', $student->country ?? 'Bolivia') }}" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57]">
                        </div>
                    </div>

                    <!-- Ciudad -->
                    <div class="group">
                        <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">Ciudad</label>
                        <div class="relative">
                            <i class="ph-bold ph-buildings absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0AD1C8] transition-colors"></i>
                            <input type="text" name="city" value="{{ old('city', $student->city) }}" class="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57]" list="cities-list">
                            <datalist id="cities-list">
                                <option value="La Paz">
                                <option value="Cochabamba">
                                <option value="Santa Cruz">
                                <option value="Oruro">
                                <option value="Potosí">
                                <option value="Tarija">
                                <option value="Sucre">
                                <option value="Trinidad">
                                <option value="Cobija">
                            </datalist>
                        </div>
                    </div>
                </div>

                <!-- Biografía -->
                <div class="group">
                    <label class="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 block ml-1 group-focus-within:text-[#0AD1C8] transition-colors">Biografía</label>
                    <div class="relative">
                        <textarea name="bio" rows="4" class="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:border-[#0AD1C8] focus:ring-4 focus:ring-[#0AD1C8]/10 outline-none transition-all text-sm font-medium text-[#213A57] resize-none leading-relaxed" placeholder="Cuéntanos un poco sobre ti...">{{ old('bio', $student->bio) }}</textarea>
                        <div class="absolute bottom-3 right-3 text-gray-300 pointer-events-none"><i class="ph-bold ph-pencil-simple-line"></i></div>
                    </div>
                </div>

                <div class="mt-auto pt-4">
                    <button type="submit" class="w-full py-4 bg-[#213A57] text-white font-bold rounded-xl hover:bg-[#0B6477] transition-all shadow-lg hover:shadow-xl hover:-translate-y-1 text-sm flex items-center justify-center gap-2">
                        <i class="ph-bold ph-floppy-disk text-lg"></i>
                        Guardar Cambios
                    </button>
                </div>
            </form>
        </div>

        <!-- 3. SEGURIDAD (DERECHA) -->
        <div class="xl:w-1/3 flex flex-col gap-6 h-full overflow-y-auto no-scrollbar">
            
            <!-- Tarjeta Seguridad -->
            <div class="bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100 relative overflow-hidden">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-bold text-[#213A57] flex items-center gap-2">
                        <i class="ph-duotone ph-shield-check text-[#0AD1C8] text-2xl"></i> Seguridad
                    </h3>
                </div>

                <form action="{{ route('student.profile.security') }}" method="POST" class="flex flex-col gap-5">
                    @csrf
                    @method('PUT')

                    <!-- Cambio de Contraseña -->
                    <div class="bg-gray-50 p-5 rounded-2xl border border-gray-100 group focus-within:border-[#0AD1C8] focus-within:ring-1 focus-within:ring-[#0AD1C8] transition-all">
                        <h4 class="font-bold text-[#213A57] text-xs uppercase mb-3 flex items-center gap-2">
                            <i class="ph-bold ph-key text-gray-400"></i> Contraseña
                        </h4>
                        <div class="space-y-3">
                            <input type="password" name="current_password" placeholder="Contraseña Actual" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-[#0AD1C8] outline-none bg-white transition-all">
                            <input type="password" name="new_password" placeholder="Nueva Contraseña" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-[#0AD1C8] outline-none bg-white transition-all">
                            <input type="password" name="new_password_confirmation" placeholder="Repetir Nueva" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-[#0AD1C8] outline-none bg-white transition-all">
                        </div>
                    </div>

                    <!-- Cambio de PIN -->
                    <div class="bg-[#E0F9F6]/30 p-5 rounded-2xl border border-[#0AD1C8]/20 group focus-within:bg-[#E0F9F6]/50 transition-all">
                        <div class="flex justify-between items-start mb-2">
                            <div>
                                <h4 class="font-bold text-[#213A57] text-xs uppercase mb-1">PIN de Acceso</h4>
                                <span class="text-[10px] bg-white px-2 py-0.5 rounded border border-[#0AD1C8]/20 text-[#0B6477]">4 Dígitos</span>
                            </div>
                            <i class="ph-duotone ph-numpad text-2xl text-[#0AD1C8]"></i>
                        </div>
                        <input type="password" name="pin" maxlength="4" class="w-full px-4 py-3 rounded-xl border border-[#0AD1C8]/30 text-center font-mono text-xl tracking-[0.5em] text-[#213A57] focus:border-[#0AD1C8] outline-none bg-white placeholder-gray-300" placeholder="••••" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    </div>

                    <button type="submit" class="w-full py-3 bg-white border-2 border-[#213A57] text-[#213A57] hover:bg-[#213A57] hover:text-white font-bold rounded-xl transition-all text-sm flex items-center justify-center gap-2 group/btn">
                        <i class="ph-bold ph-arrows-clockwise group-hover/btn:rotate-180 transition-transform duration-500"></i>
                        Actualizar Credenciales
                    </button>
                </form>
            </div>

            <!-- INFO CARD SOBRE EL PIN (NUEVO) -->
            <div class="bg-gradient-to-br from-[#213A57] to-[#0B6477] rounded-[2rem] p-6 text-white relative overflow-hidden shadow-lg">
                <!-- Decoración -->
                <div class="absolute -right-4 -top-4 w-24 h-24 bg-white opacity-10 rounded-full blur-2xl"></div>
                <div class="absolute -left-4 -bottom-4 w-20 h-20 bg-[#0AD1C8] opacity-20 rounded-full blur-xl"></div>
                
                <div class="relative z-10">
                    <div class="flex items-center gap-3 mb-3">
                        <div class="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
                            <i class="ph-fill ph-info text-xl text-[#0AD1C8]"></i>
                        </div>
                        <h4 class="font-bold text-lg">¿Para qué sirve el PIN?</h4>
                    </div>
                    <p class="text-sm text-gray-200 leading-relaxed mb-4">
                        El PIN es tu llave rápida ⚡. Úsalo para:
                    </p>
                    <ul class="space-y-2 text-sm text-white/90">
                        <li class="flex items-center gap-2"><i class="ph-bold ph-check text-[#0AD1C8]"></i> Iniciar sesión sin escribir contraseña larga.</li>
                        <li class="flex items-center gap-2"><i class="ph-bold ph-check text-[#0AD1C8]"></i> Firmar digitalmente tu asistencia.</li>
                        <li class="flex items-center gap-2"><i class="ph-bold ph-check text-[#0AD1C8]"></i> Confirmar cambios importantes.</li>
                    </ul>
                </div>
            </div>

        </div>

    </div>

    <!-- MODAL SELECCIÓN DE AVATAR -->
    <div id="avatar-modal" class="fixed inset-0 z-50 hidden bg-[#213A57]/90 backdrop-blur-md flex items-center justify-center p-4 transition-opacity duration-300" onclick="closeAvatarModal(event)">
        <div class="bg-white rounded-[2rem] w-full max-w-3xl p-8 shadow-2xl relative transform transition-all scale-100" onclick="event.stopPropagation()">
            <div class="flex justify-between items-center mb-8 border-b border-gray-100 pb-4">
                <div>
                    <h3 class="text-2xl font-bold text-[#213A57]">Elige tu Avatar</h3>
                    <p class="text-gray-400 text-sm">Selecciona una imagen que te represente</p>
                </div>
                <button onclick="closeAvatarModal()" class="w-10 h-10 rounded-full bg-gray-100 hover:bg-red-50 text-gray-500 hover:text-red-500 flex items-center justify-center transition-colors">
                    <i class="ph-bold ph-x text-xl"></i>
                </button>
            </div>
            
            <div class="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-4 max-h-[50vh] overflow-y-auto p-2 custom-scrollbar">
                @if(isset($localAvatars) && count($localAvatars) > 0)
                    @foreach($localAvatars as $path)
                        <div onclick="selectAvatar('{{ asset($path) }}', this)" 
                             class="avatar-option cursor-pointer aspect-square rounded-full border-4 border-transparent p-1 transition-all hover:scale-110 hover:shadow-lg">
                            <img src="{{ asset($path) }}" class="w-full h-full rounded-full object-cover bg-gray-50 shadow-sm pointer-events-none">
                        </div>
                    @endforeach
                @else
                    <div class="col-span-full py-12 text-center flex flex-col items-center justify-center text-gray-400">
                        <i class="ph-duotone ph-image text-4xl mb-2"></i>
                        <p>No se encontraron avatares locales.</p>
                    </div>
                @endif
            </div>

            <div class="mt-8 flex justify-end pt-4 border-t border-gray-100">
                <button onclick="submitAvatarChange()" class="px-8 py-3 bg-[#213A57] text-white rounded-xl font-bold hover:bg-[#0B6477] transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 flex items-center gap-2">
                    <i class="ph-bold ph-check"></i>
                    Confirmar Cambio
                </button>
            </div>
        </div>
    </div>

    <script>
        // Modal Avatar
        function openAvatarModal() {
            document.getElementById('avatar-modal').classList.remove('hidden');
            // Animación simple de entrada
            setTimeout(() => {
                document.getElementById('avatar-modal').firstElementChild.classList.remove('opacity-0');
            }, 10);
        }
        
        function closeAvatarModal(e) {
            if (e && e.target !== e.currentTarget && e.target.closest('.bg-white')) return; 
            document.getElementById('avatar-modal').classList.add('hidden');
        }

        function selectAvatar(url, element) {
            // Visual
            document.querySelectorAll('.avatar-option').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');

            // Preparar el valor relativo para guardar en BD
            const urlObj = new URL(url);
            const relativePath = urlObj.pathname.substring(1); 
            document.getElementById('avatar_input_hidden').value = relativePath;
        }

        function submitAvatarChange() {
            // Enviar el formulario de datos personales que tiene el input hidden del avatar
            document.getElementById('personalForm').submit();
        }
    </script>
</x-layouts.student>