<x-layouts.student>
    <x-slot name="title">Mi Aprendizaje - YATI</x-slot>
    <x-slot name="header">Mis Cursos</x-slot>

    <script src="//unpkg.com/alpinejs" defer></script>
    <style>
        [x-cloak] { display: none !important; }
        /* Clase para el estado bloqueado */
        .course-locked { filter: grayscale(1); opacity: 0.6; pointer-events: none; }
    </style>

    <!-- MENSAJES FLASH -->
    @if(session('success'))
        <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative animate-bounce-in flex items-center gap-2" role="alert">
            <i class="ph-bold ph-check-circle text-xl"></i>
            <span class="block sm:inline">{{ session('success') }}</span>
        </div>
    @endif
    @if(session('warning'))
        <div class="mb-6 bg-amber-100 border border-amber-400 text-amber-700 px-4 py-3 rounded relative animate-bounce-in flex items-center gap-2" role="alert">
            <i class="ph-bold ph-warning text-xl"></i>
            <span class="block sm:inline">{{ session('warning') }}</span>
        </div>
    @endif
    @if(session('error'))
        <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative animate-bounce-in flex items-center gap-2" role="alert">
            <i class="ph-bold ph-x-circle text-xl"></i>
            <span class="block sm:inline">{{ session('error') }}</span>
        </div>
    @endif

    <div x-data="{ tab: 'all' }">

        <div class="mb-8 fade-in-up" style="animation-delay: 0.1s">
            <h1 class="text-3xl font-bold text-[#213A57]">
                ¡Hola, {{ explode(' ', $student->name)[0] }}! 👋
            </h1>
            <p class="text-gray-500 mt-2 flex items-center gap-2">
                <i class="ph-fill ph-chalkboard-teacher text-[#0AD1C8]"></i>
                @if($inProgressCount > 0)
                    Tienes <strong class="text-[#213A57]">{{ $inProgressCount }} cursos en progreso</strong>.
                @else
                    ¡Has completado todos tus cursos pendientes! 🎉
                @endif
            </p>
        </div>

        <!-- TABS -->
        <div class="flex gap-6 border-b border-gray-200 mb-8 fade-in-up" style="animation-delay: 0.2s">
            <button @click="tab = 'all'" :class="tab === 'all' ? 'border-[#0AD1C8] text-[#0AD1C8]' : 'border-transparent text-gray-400 hover:text-[#213A57]'" class="pb-3 border-b-2 font-bold text-sm px-2 transition-colors duration-300">Todo ({{ $enrollments->count() }})</button>
            <button @click="tab = 'progress'" :class="tab === 'progress' ? 'border-[#0AD1C8] text-[#0AD1C8]' : 'border-transparent text-gray-400 hover:text-[#213A57]'" class="pb-3 border-b-2 font-bold text-sm px-2 transition-colors duration-300">En Progreso ({{ $inProgressCount }})</button>
            <button @click="tab = 'completed'" :class="tab === 'completed' ? 'border-[#0AD1C8] text-[#0AD1C8]' : 'border-transparent text-gray-400 hover:text-[#213A57]'" class="pb-3 border-b-2 font-bold text-sm px-2 transition-colors duration-300">Completado ({{ $completedCount }})</button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-12">
            
            @forelse($enrollments as $enrollment)
                @php
                    $course = $enrollment->course;
                    $instructor = $course->instructor;
                    
                    // Lógica de validación de aprobación
                    $isPending = $enrollment->status === 'pending';
                    
                    // Redondeo de progreso
                    $progress = $enrollment->calculated_progress;
                    $isCompleted = round($progress) >= 100; 
                    
                    $completedLessons = $enrollment->completed_lessons_count;
                    $totalLessons = $enrollment->total_lessons_count;
                    $statusKey = $isCompleted ? 'completed' : 'progress';

                    // Buscar certificado existente
                    $myCertificate = \App\Models\Certificate::where('student_id', $student->id)
                                                        ->where('course_id', $course->id)
                                                        ->first();
                @endphp

                <div x-show="tab === 'all' || tab === '{{ $statusKey }}'" x-cloak
                     class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden transition-all duration-300 group fade-in-up {{ $isPending ? '' : 'hover:shadow-xl hover:border-[#0AD1C8]/30' }}">
                    
                    <!-- IMAGEN -->
                    <div class="relative h-56 overflow-hidden {{ $isPending ? 'grayscale opacity-70' : '' }}">
                        @if($course->cover_image)
                            <img src="{{ asset($course->cover_image) }}" class="w-full h-full object-cover {{ !$isPending ? 'group-hover:scale-110' : '' }} transition-transform duration-700">
                        @else
                            <div class="w-full h-full bg-gray-200 flex items-center justify-center"><i class="ph-duotone ph-image text-4xl text-gray-400"></i></div>
                        @endif
                        <div class="absolute inset-0 bg-gradient-to-t from-[#213A57]/90 via-[#213A57]/20 to-transparent"></div>
                        
                        @if($isPending)
                            <div class="absolute top-4 right-4 bg-amber-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1.5 animate-pulse">
                                <i class="ph-bold ph-hourglass-medium"></i> REVISIÓN PENDIENTE
                            </div>
                        @endif

                        <div class="absolute bottom-4 left-4 right-4">
                            <h3 class="text-white font-bold text-lg leading-tight line-clamp-2 {{ !$isPending ? 'group-hover:text-[#0AD1C8]' : '' }} transition-colors">{{ $course->title }}</h3>
                        </div>
                    </div>
                    
                    <div class="p-6">
                        @if($isPending)
                            <!-- VISTA PARA CURSO PENDIENTE -->
                            <div class="mb-6 p-4 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                                <p class="text-xs font-bold text-gray-500 uppercase mb-1">Inscripción en proceso</p>
                                <p class="text-[11px] text-gray-400 leading-tight">Tu comprobante está siendo validado. Te notificaremos cuando el acceso esté activo.</p>
                            </div>

                            <button disabled class="w-full py-3 bg-gray-100 text-gray-400 font-bold rounded-xl flex items-center justify-center gap-2 cursor-not-allowed border border-gray-200">
                                <i class="ph-bold ph-lock-key"></i>
                                Acceso restringido
                            </button>
                        @else
                            <!-- VISTA PARA CURSO APROBADO (TU CÓDIGO ORIGINAL) -->
                            <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                                <div class="flex items-center gap-2 overflow-hidden">
                                    @if($instructor)
                                        <img src="{{ $instructor->avatar_url ? asset($instructor->avatar_url) : 'https://ui-avatars.com/api/?name='.urlencode($instructor->name).'&background=random' }}" class="w-8 h-8 rounded-full object-cover border border-gray-200 shrink-0">
                                        <span class="font-medium text-[#213A57] leading-tight">{{ $instructor->name }}</span>
                                    @else
                                        <div class="w-8 h-8 rounded-full bg-gray-200 shrink-0"></div><span>Sin Instructor</span>
                                    @endif
                                </div>
                            </div>

                            <div class="mb-6">
                                <div class="flex justify-between text-xs font-bold mb-2">
                                    @if($isCompleted)
                                        <span class="text-green-600 flex items-center gap-1"><i class="ph-fill ph-check-circle"></i> Curso Completado</span>
                                        <span class="text-green-600">100%</span>
                                    @else
                                        <span class="text-[#213A57]">{{ $progress }}% Completado</span>
                                        <span class="text-[#0AD1C8]">{{ $completedLessons }}/{{ $totalLessons }}</span>
                                    @endif
                                </div>
                                <div class="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
                                    <div class="h-full rounded-full transition-all duration-1000 ease-out relative {{ $isCompleted ? 'bg-green-500' : 'bg-gradient-to-r from-[#0B6477] to-[#0AD1C8]' }}" style="width: {{ $progress }}%"></div>
                                </div>
                            </div>
                            
                            <!-- BOTONES DE ACCIÓN -->
                            @if($isCompleted)
                                @php
                                    $certConfig = $course->certificate_template ?? [];
                                    $releaseMode = $certConfig['release_mode'] ?? 'completion';
                                    $releaseDate = isset($certConfig['release_date']) ? \Carbon\Carbon::parse($certConfig['release_date']) : null;
                                    
                                    $isDateReleased = true;
                                    if ($releaseMode === 'scheduled' && $releaseDate) {
                                        $isDateReleased = now()->greaterThanOrEqualTo($releaseDate);
                                    }
                                @endphp

                                <div class="flex gap-2">
                                    <a href="{{ route('classroom.show', ['course' => $course->slug]) }}" class="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-600 font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-sm text-center">
                                        Repasar
                                    </a>
                                    
                                    @if(!$isDateReleased)
                                        <button disabled class="flex-1 py-2 bg-gray-50 border-2 border-gray-200 text-gray-400 font-bold rounded-xl cursor-not-allowed flex flex-col leading-tight items-center justify-center gap-0 text-sm" title="Disponible el {{ $releaseDate->format('d/m/Y') }}">
                                            <span class="flex items-center gap-1"><i class="ph-bold ph-lock-key"></i> Certificado</span>
                                            <span class="text-[10px] font-normal">Disponible: {{ $releaseDate->format('d/m') }}</span>
                                        </button>
                                    @elseif($myCertificate)
                                        <a href="{{ route('certificate.verify', $myCertificate->uuid) }}" target="_blank" class="flex-1 py-3 bg-green-50 border-2 border-green-500 text-green-600 hover:bg-green-100 font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-sm text-center">
                                            <i class="ph-bold ph-certificate text-lg"></i> Ver Certificado
                                        </a>
                                    @else
                                        <a href="{{ route('student.certificate.claim', $course->id) }}" class="flex-1 py-3 bg-blue-50 border-2 border-blue-500 text-blue-600 hover:bg-blue-100 font-bold rounded-xl transition-all flex items-center justify-center gap-2 text-sm text-center">
                                            <i class="ph-bold ph-certificate text-lg"></i> Ver Certificado
                                        </a>
                                    @endif
                                </div>
                            @else
                                <a href="{{ route('classroom.show', ['course' => $course->slug]) }}" class="w-full py-3 bg-[#213A57] hover:bg-[#0B6477] text-white font-bold rounded-xl transition-all shadow-lg shadow-[#213A57]/20 flex items-center justify-center gap-2 group/btn">
                                    {{ $progress > 0 ? 'Continuar' : 'Empezar' }}
                                    <i class="ph-bold ph-play-circle text-xl group-hover/btn:translate-x-1 transition-transform"></i>
                                </a>
                            @endif
                        @endif
                    </div>
                </div>
            @empty
                <div class="col-span-full py-16 text-center text-gray-400 bg-white rounded-3xl border-2 border-dashed border-gray-200">
                    <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4"><i class="ph-duotone ph-student text-4xl text-gray-300"></i></div>
                    <h3 class="text-xl font-bold text-[#213A57] mb-2">No tienes cursos activos</h3>
                    <a href="{{ route('catalog') }}" class="mt-4 inline-block px-6 py-2 bg-[#0AD1C8] text-white font-bold rounded-lg hover:bg-[#0B6477] transition-colors">Ver Catálogo</a>
                </div>
            @endforelse

        </div>
    </div>
</x-layouts.student>