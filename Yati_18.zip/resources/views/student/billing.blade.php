<x-layouts.student>
    <x-slot name="title">Mis Pagos - YATI</x-slot>
    <x-slot name="header">Historial de Pagos</x-slot>

    <!-- TABLA DE TRANSACCIONES -->
    <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden fade-in-up" style="animation-delay: 0.1s">
        <div class="p-6 border-b border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
            <h3 class="text-xl font-bold text-[#213A57]">Transacciones Recientes</h3>
            
            <!-- Filtros visuales (Funcionalidad pendiente si se requiere) -->
            <div class="flex gap-2">
                <span class="px-3 py-1 text-xs font-medium text-[#213A57] bg-blue-50 rounded-lg border border-blue-100">
                    Total Registros: {{ $payments->total() }}
                </span>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wider border-b border-gray-100">
                        <th class="px-6 py-4 font-semibold">ID Pedido</th>
                        <th class="px-6 py-4 font-semibold">Curso Adquirido</th>
                        <th class="px-6 py-4 font-semibold">Fecha</th>
                        <th class="px-6 py-4 font-semibold">Total</th>
                        <th class="px-6 py-4 font-semibold">Estado</th>
                        <th class="px-6 py-4 font-semibold text-right">Boleta de Pago</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    
                    @forelse($payments as $payment)
                    <tr class="hover:bg-[#F0FDFD] transition-colors group">
                        <!-- ID -->
                        <td class="px-6 py-4 font-mono text-[#0B6477]">
                            #ORD-{{ str_pad($payment->id, 5, '0', STR_PAD_LEFT) }}
                        </td>

                        <!-- CURSO -->
                        <td class="px-6 py-4">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 rounded bg-gray-200 overflow-hidden shrink-0">
                                    @if($payment->course->cover_image)
                                        <img src="{{ asset($payment->course->cover_image) }}" class="w-full h-full object-cover">
                                    @else
                                        <div class="w-full h-full flex items-center justify-center bg-gray-300 text-gray-500">
                                            <i class="ph-fill ph-image"></i>
                                        </div>
                                    @endif
                                </div>
                                <span class="font-medium text-[#213A57]">{{ $payment->course->title }}</span>
                            </div>
                        </td>

                        <!-- FECHA -->
                        <td class="px-6 py-4 text-gray-500">
                            {{ $payment->created_at->format('d M, Y') }}
                        </td>

                        <!-- TOTAL -->
                        <td class="px-6 py-4 font-bold text-[#213A57]">
                            Bs {{ number_format($payment->price_paid, 2) }}
                        </td>

                        <!-- ESTADO -->
                        <td class="px-6 py-4">
                            @if($payment->status === 'approved')
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-100">
                                    <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Aprobado
                                </span>
                            @elseif($payment->status === 'pending')
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-600 border border-amber-100">
                                    <span class="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span> Pendiente
                                </span>
                            @else
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-red-50 text-red-600 border border-red-100">
                                    Rechazado
                                </span>
                            @endif
                        </td>

                        <!-- ACCIÓN: VER BOLETA -->
                        <td class="px-6 py-4 text-right">
                            @if($payment->receipt_url)
                                <button onclick="verBoleta('{{ asset($payment->receipt_url) }}')" class="text-gray-400 hover:text-[#0AD1C8] transition-colors p-2 rounded-lg hover:bg-[#E0F9F6] flex items-center justify-end gap-2 ml-auto" title="Ver Boleta">
                                    <span class="text-xs font-medium">Ver Boleta</span>
                                    <i class="ph-bold ph-receipt text-lg"></i>
                                </button>
                            @else
                                <span class="text-xs text-gray-300 italic">No disponible</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                            <i class="ph-duotone ph-receipt text-4xl mb-2 text-gray-300"></i>
                            <p>No tienes transacciones registradas.</p>
                        </td>
                    </tr>
                    @endforelse

                </tbody>
            </table>
        </div>
        
        <!-- Paginación -->
        <div class="p-4 border-t border-gray-100">
            {{ $payments->links() }}
        </div>
    </div>

    <!-- MODAL VER BOLETA -->
    <div id="modal-boleta" class="fixed inset-0 z-[100] hidden bg-black/90 backdrop-blur-md flex items-center justify-center p-4 transition-opacity" onclick="closeBoleta()">
        <div class="relative max-w-2xl w-full" onclick="event.stopPropagation()">
            <img id="boleta-img" src="" class="w-full rounded-lg shadow-2xl border-4 border-white bg-white">
            <button onclick="closeBoleta()" class="absolute -top-12 right-0 text-white hover:text-gray-300 transition-colors">
                <i class="ph-bold ph-x text-3xl"></i>
            </button>
        </div>
    </div>

    <script>
        function verBoleta(url) {
            document.getElementById('boleta-img').src = url;
            document.getElementById('modal-boleta').classList.remove('hidden');
        }

        function closeBoleta() {
            document.getElementById('modal-boleta').classList.add('hidden');
        }
    </script>
</x-layouts.student>